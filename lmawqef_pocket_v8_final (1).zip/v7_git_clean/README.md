# Lmawqef Pocket - Version Finale v8

**Plateforme SaaS de mise en relation Client-Prestataire au Maroc**

---

## Fonctionnalités

### Core (existant)
- **Recherche multicritères** par ville, catégorie, prix, notation, disponibilité
- **Négociation de prix** jusqu'à 3 rounds
- **Double paiement** : Cash traçable + Wallet sécurisé avec escrow
- **Facturation PDF** automatique
- **Vérification KYC** avec badge "Vérifié"
- **Système d'avis** et notation
- **Multilingue** : Français, Arabe (RTL), Anglais
- **Dark mode** et UI responsive

### Axes d'amélioration implémentés (15 fonctionnalités)

| # | Fonctionnalité | Statut |
|---|---------------|--------|
| 1 | **PWA Offline** - Service Worker, cache, install button | ✅ |
| 2 | **Landing pages SEO** - /lp/ville/catégorie dynamiques | ✅ |
| 3 | **Parrainage** - Code unique, 50 DH par filleul | ✅ |
| 4 | **Chat enrichi** - Upload images, emoji picker | ✅ |
| 5 | **SMS simulés** - Notifications par templates | ✅ |
| 6 | **Calendrier interactif** - Disponibilités worker | ✅ |
| 7 | **Système de litige** - Preuves, arbitrage admin | ✅ |
| 8 | **Matching AI** - Score 0-100 pondéré | ✅ |
| 9 | **Analytics admin** - KPIs, graphiques, temps réel | ✅ |
| 10 | **Onboarding interactif** - 4 étapes pour nouveaux workers | ✅ |
| 11 | **Assistant virtuel** - Questionnaire → recommandations | ✅ |
| 12 | **Escrow milestones** - Paiement par étapes | ✅ |
| 13 | **KYC biométrique** - Selfie + CNI | ✅ |
| 14 | **2FA Admin** - TOTP avec QR code | ✅ |
| 15 | **Sitemap/Robots** - SEO automatique | ✅ |

---

## Stack Technique

| Couche | Technologie |
|--------|------------|
| Backend | Python 3.11 + Flask 2.3 |
| ORM | SQLAlchemy 2.0 + Flask-Migrate (Alembic) |
| Auth | Flask-Login + Werkzeug (bcrypt) |
| DB | SQLite (production: PostgreSQL) |
| Frontend | Tailwind CSS + Vanilla JS |
| i18n | Flask-Babel (gettext) |
| PDF | WeasyPrint |
| PWA | Service Worker + Manifest |

---

## Installation Rapide (2 minutes)

### Prérequis
- Python 3.11+
- pip

### 1. Cloner / Extraire le projet
```bash
cd v7_git_clean
```

### 2. Créer l'environnement virtuel
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. Installer les dépendances
```bash
pip install -r requirements.txt
```

### 4. Lancer l'application
```bash
python run.py
```

L'application sera accessible sur **http://localhost:5000**

---

## Structure du Projet

```
lmawqef_pocket/
├── app/
│   ├── __init__.py              # Factory Flask + blueprints
│   ├── models/                  # Modèles SQLAlchemy (16 tables)
│   ├── routes/                  # 11 blueprints (auth, bookings, payments, etc.)
│   ├── templates/               # Templates Jinja2
│   ├── static/                  # CSS, JS, images, icons
│   ├── utils/                   # Helpers, matching, SMS
│   └── translations/            # FR / EN / AR
├── migrations/                  # Alembic
├── instance/                    # SQLite DB + uploads
├── requirements.txt             # Dépendances
└── run.py                       # Point d'entrée
```

---

## Comptes de démo

Après le premier démarrage, des comptes de démo sont automatiquement créés :

| Email | Mot de passe | Rôle |
|-------|-------------|------|
| client@lmawqef.ma | client123 | Client |
| worker@lmawqef.ma | worker123 | Worker |
| admin@lmawqef.ma | admin123 | Administrateur |

---

## Déploiement Production

### Option A: VPS / Serveur dédié
```bash
# 1. Installer
pip install -r requirements.txt

# 2. Configurer les variables d'environnement
export SECRET_KEY="votre_cle_secrete"
export DATABASE_URL="postgresql://user:pass@localhost/lmawqef"
export ADMIN_PASSWORD_HASH="<hash>"

# 3. Exécuter les migrations
flask db upgrade

# 4. Lancer avec Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 "app:create_app()"
```

### Option B: Replit / Railway / Render
Le projet est compatible PaaS avec SQLite. Pour PostgreSQL, modifier `config.py`.

### Option C: Docker (optionnel)
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "run.py"]
```

---

## Configuration

Modifiez `app/config.py` pour adapter :

```python
class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-key-change-in-production')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///lmawqef.db')
    UPLOAD_FOLDER = os.path.join(basedir, '..', 'instance', 'uploads')
```

---

## API Endpoints

| Endpoint | Méthode | Description |
|----------|---------|-------------|
| `/api/search` | GET | Recherche JSON |
| `/api/workers` | GET | Liste workers |
| `/api/bookings` | GET | Réservations |
| `/api/messages/poll` | GET | Polling chat |
| `/api/assistant-results` | GET | Matching assistant |
| `/api/notifications` | GET | Notifications |
| `/api/wallet` | GET | Solde wallet |
| `/api/reviews` | GET | Avis |

---

## Commandes Utiles

```bash
# Créer une migration
flask db migrate -m "description"

# Appliquer les migrations
flask db upgrade

# Compiler les traductions
pybabel compile -d app/translations

# Exécuter les tests (si configurés)
pytest
```

---

## Contact & Support

- **Email**: contact@lmawqef.ma
- **Version**: v8.0 Final
- **Date**: Mai 2026
- **License**: Propriétaire

---

**Made in Morocco** | Lmawqef Pocket
