from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random, string
from app.extensions import db
from app.models import (
    User, Service, Booking, Payment, Invoice, Annonce, AnnonceOffer,
    Review, Message, Notification, SubscriptionPlan, AppConfig, Level, Badge, AdminRole
)

def generate_invoice_number():
    return 'FAC-' + datetime.utcnow().strftime('%Y%m%d') + '-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))




def create_default_data():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin', email='admin@lmawqef.ma',
            password_hash=generate_password_hash('admin123'),
            full_name='System Administrator', phone='0600000000',
            city='Rabat', user_type='client', is_admin=True
        )
        db.session.add(admin)
        role = AdminRole(user_id=1, can_manage_users=True, can_manage_services=True,
                        can_manage_bookings=True, can_manage_annonces=True,
                        can_manage_subscriptions=True, can_manage_payments=True,
                        can_manage_admins=True, can_edit_config=True, can_view_analytics=True)
        db.session.add(role)
        db.session.commit()
        print('Admin created: admin / admin123')
    plans = SubscriptionPlan.query.all()
    if not plans:
        default_plans = [
            SubscriptionPlan(name='Entreprise Premium', slug='entreprise-premium',
                           description='For workforce companies', price=500, duration_days=30,
                           annonce_limit=999, features='["Unlimited announces","Featured profile","Priority support","Analytics"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Entreprise Basic', slug='entreprise-basic',
                           description='Basic plan for companies', price=0, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Basic support"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Auto-Entrepreneur Pro', slug='auto-pro',
                           description='For self-employed professionals', price=150, duration_days=30,
                           annonce_limit=100, features='["100 announces/month","Portfolio showcase","Priority listing","Direct messages"]',
                           target_type='autoentrepreneur'),
            SubscriptionPlan(name='Freelance Starter', slug='freelance-starter',
                           description='For freelancers', price=0, duration_days=30,
                           annonce_limit=20, features='["20 announces/month","Basic profile"]',
                           target_type='freelance'),
            SubscriptionPlan(name='Freelance Pro', slug='freelance-pro',
                           description='Pro plan for freelancers', price=100, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Portfolio","Featured services"]',
                           target_type='freelance')
        ]
        for p in default_plans:
            db.session.add(p)
        db.session.commit()
        print('Subscription plans created')
    config = AppConfig.query.first()
    if not config:
        config = AppConfig()
        db.session.add(config)
        db.session.commit()
        print('App config created')
    # Create default levels
    levels = Level.query.all()
    if not levels:
        default_levels = [
            Level(name='Novice', min_points=0, max_points=99, icon='fa-seedling', color='#84cc16', benefits='Basic profile'),
            Level(name='Apprenti', min_points=100, max_points=499, icon='fa-leaf', color='#22c55e', benefits='Portfolio access'),
            Level(name='Professionnel', min_points=500, max_points=1999, icon='fa-star', color='#0d9488', benefits='Priority listing'),
            Level(name='Expert', min_points=2000, max_points=4999, icon='fa-gem', color='#3b82f6', benefits='Featured services'),
            Level(name='Maitre', min_points=5000, max_points=9999, icon='fa-crown', color='#f59e0b', benefits='Analytics dashboard'),
            Level(name='Legende', min_points=10000, max_points=None, icon='fa-trophy', color='#ef4444', benefits='All premium features')
        ]
        for l in default_levels:
            db.session.add(l)
        db.session.commit()
        print('Levels created')
    # Create default badges
    badges = Badge.query.all()
    if not badges:
        default_badges = [
            Badge(name='Premier Service', slug='first-service', description='Complete your first service',
                  icon='fa-handshake', color='#0d9488', condition_type='bookings_count', condition_value=1, points_reward=50),
            Badge(name='Worker Actif', slug='active-worker', description='Complete 10 services',
                  icon='fa-briefcase', color='#3b82f6', condition_type='bookings_count', condition_value=10, points_reward=200),
            Badge(name='Top Rated', slug='top-rated', description='Achieve 4.5+ average rating',
                  icon='fa-star', color='#f59e0b', condition_type='rating', condition_value=5, points_reward=300),
            Badge(name='Critique Acclame', slug='popular-reviews', description='Receive 25 reviews',
                  icon='fa-comments', color='#8b5cf6', condition_type='reviews_count', condition_value=25, points_reward=250),
            Badge(name='Portfolio Pro', slug='portfolio-pro', description='Add 5 portfolio items',
                  icon='fa-images', color='#ec4899', condition_type='services_count', condition_value=5, points_reward=150),
            Badge(name='Rapidite Flash', slug='flash-response', description='Respond within 1 hour average',
                  icon='fa-bolt', color='#eab308', condition_type='response_time', condition_value=60, points_reward=200),
        ]
        db.session.commit()
        print('Badges created')
    
    # ==================== RICH DEMO DATA ====================
    # Create 2 workers per region (city) with Fiverr-style profiles
    if User.query.filter_by(user_type='worker').count() < 10:
        worker_data = [
            # Casablanca
            {'username':'youssef.casa', 'full_name':'Youssef Benali', 'email':'youssef@casa.ma', 
             'password':'worker123', 'city':'Casablanca', 'profession_title':'Électricien Certifié | Installations Industrielles',
             'profession':'Électricien', 'skills':'Électricité, Installation tableau, Dépanange, Domotique',
             'description':'Électricien certifié avec 8 ans d\'expérience à Casablanca. Spécialisé en installations industrielles et domotique.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Intermédiaire',
             'education':'BTS Électrotechnique::ISTA Casablanca::2016',
             'certifications':'Certifié Électricien::ONEE::2019',
             'response_time_hours':3, 'phone':'0611111111', 'points':980, 'rating_avg':4.7},
            {'username':'fatima.casa', 'full_name':'Fatima Zahra', 'email':'fatima@casa.ma',
             'password':'worker123', 'city':'Casablanca', 'profession_title':'Peintre Décoratrice | Design Intérieur',
             'profession':'Peintre', 'skills':'Peinture, Décoration, Papier peint, Enduit',
             'description':'Peintre décoratrice passionnée. Transformez votre intérieur avec des couleurs harmonieuses et des finitions impeccables.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Peinture::CFP Casablanca::2017',
             'certifications':'Certificat Décoration::École des Beaux-Arts::2020',
             'response_time_hours':4, 'phone':'0622222222', 'points':750, 'rating_avg':4.5},
            # Rabat
            {'username':'omar.rabat', 'full_name':'Omar El Idrissi', 'email':'omar@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'profession_title':'Menuisier Ébéniste | Sur Mesure',
             'profession':'Menuisier', 'skills':'Menuiserie, Ébénisterie, Placard, Cuisine',
             'description':'Menuisier ébéniste spécialisé en meubles sur mesure. Qualité artisanale et finitions haut de gamme à Rabat.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'BTS Bois::OFPPT Rabat::2015',
             'certifications':'Maître Artisan::Chambre Artisanat Rabat::2018',
             'response_time_hours':5, 'phone':'0633333333', 'points':1100, 'rating_avg':4.8},
            {'username':'nadia.rabat', 'full_name':'Nadia Bennani', 'email':'nadia@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'profession_title':'Jardinière Paysagiste | Espaces Verts',
             'profession':'Jardinier', 'skills':'Jardinage, Paysagisme, Entretien, Arrosage automatique',
             'description':'Jardinière paysagiste créative. Conception et entretien de jardins résidentiels et espaces verts professionnels.',
             'languages':'Français:Natif, Arabe:Natif, Espagnol:Intermédiaire',
             'education':'Bac Pro Horticulture::Lycée Agricole Rabat::2018',
             'certifications':'Certificat Paysagisme::Institut Agronomique::2021',
             'response_time_hours':6, 'phone':'0644444444', 'points':620, 'rating_avg':4.6},
            # Marrakech
            {'username':'karim.marrakech', 'full_name':'Karim Alaoui', 'email':'karim@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'profession_title':'Plombier Traditionnel | Riads & Villas',
             'profession':'Plombier', 'skills':'Plomberie, Chauffe-eau, Zellige, Hammam',
             'description':'Plombier spécialisé dans les riads et villas de luxe à Marrakech. Expert en installations hammam traditionnel.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Plomberie::CFP Marrakech::2014',
             'certifications':'Expert Hammam::Association Plombiers Marrakech::2019',
             'response_time_hours':2, 'phone':'0655555555', 'points':1350, 'rating_avg':4.9},
            {'username':'amina.marrakech', 'full_name':'Amina Lamsyeh', 'email':'amina@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'profession_title':'Coiffeuse à Domicile | Mariages & Soirées',
             'profession':'Coiffeuse', 'skills':'Coiffure, Maquillage, Chignon, Tresse',
             'description':'Coiffeuse professionnelle à domicile. Spécialisée en chignons de mariage, maquillage et coiffures de soirée.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Coiffure::Salon Prestige Marrakech::2016',
             'certifications':'Maquillage Professionnel::École Beauté Marrakech::2019',
             'response_time_hours':4, 'phone':'0666666666', 'points':890, 'rating_avg':4.7},
            # Fès
            {'username':'hassan.fes', 'full_name':'Hassan El Amrani', 'email':'hassan@fes.ma',
             'password':'worker123', 'city':'Fes', 'profession_title':'Mosaïste Zellige | Art Traditionnel',
             'profession':'Mosaïste', 'skills':'Zellige, Mosaïque, Restauration, Décoration',
             'description':'Mosaïste maître artisan spécialisé en zellige traditionnel de Fès. Restauration de monuments historiques.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Formation Artisanale::Dar El Magana Fès::2010',
             'certifications':'Maître Zellige::UNESCO Patrimoine::2015',
             'response_time_hours':8, 'phone':'0677777777', 'points':1800, 'rating_avg':4.9},
            {'username':'samira.fes', 'full_name':'Samira Boudaoud', 'email':'samira@fes.ma',
             'password':'worker123', 'city':'Fes', 'profession_title':'Couturière | Caftans & Tenues Traditionnelles',
             'profession':'Couturière', 'skills':'Couture, Broderie, Caftan, Retouche',
             'description':'Couturière experte en caftans traditionnels de Fès. Broderie fine et créations sur mesure pour occasions spéciales.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Formation Couture::Maison Caftan Fès::2012',
             'certifications':'Brodeuse Professionnelle::Chambre Artisanat Fès::2017',
             'response_time_hours':5, 'phone':'0688888888', 'points':720, 'rating_avg':4.6},
            # Tanger
            {'username':'mehdi.tanger', 'full_name':'Mehdi Tahiri', 'email':'mehdi@tanger.ma',
             'password':'worker123', 'city':'Tangier', 'profession_title':'Informaticien | Dépannage & Réseaux',
             'profession':'Informaticien', 'skills':'Informatique, Réseau, Sécurité, Installation',
             'description':'Informaticien professionnel. Dépannage, installation réseaux, sécurité informatique pour entreprises et particuliers.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant, Espagnol:Intermédiaire',
             'education':'BTS Réseaux::ISTA Tanger::2017',
             'certifications':'Cisco CCNA::Cisco::2019',
             'response_time_hours':1, 'phone':'0699999999', 'points':1050, 'rating_avg':4.8},
            {'username':'laila.tanger', 'full_name':'Laila Rifai', 'email':'laila@tanger.ma',
             'password':'worker123', 'city':'Tangier', 'profession_title':'Nutritionniste à Domicile | Régimes Personnalisés',
             'profession':'Nutritionniste', 'skills':'Nutrition, Diététique, Coaching, Bien-être',
             'description':'Nutritionniste diplômée. Programmes alimentaires personnalisés, suivi régulier et coaching bien-être à Tanger.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'Licence Nutrition::Université Tanger::2018',
             'certifications':'Nutritionniste Agréée::Ministère Santé::2020',
             'response_time_hours':3, 'phone':'0600000001', 'points':580, 'rating_avg':4.5},
            # Agadir
            {'username':'brahim.agadir', 'full_name':'Brahim Oubaha', 'email':'brahim@agadir.ma',
             'password':'worker123', 'city':'Agadir', 'profession_title':'Bricoleur Tout-Faire | Rénovation Complète',
             'profession':'Bricoleur', 'skills':'Bricolage, Montage, Réparation, Peinture',
             'description':'Bricoleur polyvalent à Agadir. Montage meubles, petites réparations, travaux de peinture et rénovation rapide.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Bâtiment::CFP Agadir::2013',
             'certifications':'Bricoleur Certifié::Chambre Artisanat Agadir::2016',
             'response_time_hours':3, 'phone':'0600000002', 'points':450, 'rating_avg':4.4},
            {'username':'salma.agadir', 'full_name':'Salma El Fassi', 'email':'salma@agadir.ma',
             'password':'worker123', 'city':'Agadir', 'profession_title':'Déménageuse Professionnelle | Transport & Emballage',
             'profession':'Déménageur', 'skills':'Déménagement, Transport, Emballage, Stockage',
             'description':'Service de déménagement professionnel à Agadir et région. Transport sécurisé, emballage soigné et stockage disponible.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Formation Transport::CFP Agadir::2015',
             'certifications':'Transporteur Agréé::Ministère Transport::2018',
             'response_time_hours':4, 'phone':'0600000003', 'points':390, 'rating_avg':4.3},
        ]
        
        created_workers = []
        for wd in worker_data:
            w = User.query.filter_by(username=wd['username']).first()
            if not w:
                w = User(
                    username=wd['username'], full_name=wd['full_name'], email=wd['email'],
                    password_hash=generate_password_hash(wd['password']), user_type='worker',
                    city=wd['city'], profession_title=wd.get('profession_title'),
                    skills=wd.get('skills'),
                    description=wd.get('description'), languages=wd.get('languages'),
                    education=wd.get('education'), certifications=wd.get('certifications'),
                    response_time_hours=wd.get('response_time_hours', 24),
                    money_back_guarantee=True, phone=wd.get('phone'),
                    points=wd.get('points', 0),
                    is_active=True
                )
                db.session.add(w)
                db.session.flush()
                lvl = Level.query.filter(Level.min_points <= w.points).order_by(Level.min_points.desc()).first()
                if lvl: w.level_id = lvl.id
                created_workers.append(w)
        db.session.commit()
        print(f'{len(created_workers)} demo workers created')
        
        # Create 2 services per worker
        services_data = [
            ('youssef.casa', [
                {'title':'Installation Électrique Complète', 'description':'Installation tableau électrique, mise aux normes, éclairage LED pour appartements et villas.', 'price':2500, 'category':'Électricité', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':2, 'standard_price':2500, 'standard_delivery_days':3, 'premium_price':4000, 'premium_delivery_days':5},
                {'title':'Dépannage Électrique Urgent', 'description':'Intervention urgente 24/7 pour pannes électriques, court-circuit, fusibles grillés.', 'price':300, 'category':'Électricité', 'city':'Casablanca', 'is_urgent':True,
                 'basic_price':200, 'basic_delivery_days':1, 'standard_price':300, 'standard_delivery_days':1, 'premium_price':500, 'premium_delivery_days':1},
            ]),
            ('fatima.casa', [
                {'title':'Peinture Intérieure Complète', 'description':'Peinture intérieure appartement ou villa. Préparation, enduit, peinture premium.', 'price':3500, 'category':'Peinture', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':3, 'standard_price':3500, 'standard_delivery_days':5, 'premium_price':5500, 'premium_delivery_days':7},
                {'title':'Décoration Murale & Papier Peint', 'description':'Pose papier peint, stickers décoratifs, peinture artistique murale.', 'price':1500, 'category':'Peinture', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':800, 'basic_delivery_days':2, 'standard_price':1500, 'standard_delivery_days':3, 'premium_price':2500, 'premium_delivery_days':5},
            ]),
            ('omar.rabat', [
                {'title':'Cuisine sur Mesure', 'description':'Conception et fabrication de cuisine équipée sur mesure. Plans 3D inclus.', 'price':15000, 'category':'Menuiserie', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':10000, 'basic_delivery_days':10, 'standard_price':15000, 'standard_delivery_days':15, 'premium_price':22000, 'premium_delivery_days':20},
                {'title':'Placard & Dressing', 'description':'Placard et dressing sur mesure. Organisation optimale de l\'espace.', 'price':5000, 'category':'Menuiserie', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':3000, 'basic_delivery_days':5, 'standard_price':5000, 'standard_delivery_days':7, 'premium_price':8000, 'premium_delivery_days':10},
            ]),
            ('karim.marrakech', [
                {'title':'Installation Hammam Traditionnel', 'description':'Installation complète hammam marocain traditionnel avec zellige et tadelakt.', 'price':25000, 'category':'Plomberie', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':18000, 'basic_delivery_days':15, 'standard_price':25000, 'standard_delivery_days':20, 'premium_price':35000, 'premium_delivery_days':30},
                {'title':'Réparation Fuite & Chauffe-eau', 'description':'Réparation toutes fuites d\'eau, remplacement chauffe-eau, débouchage.', 'price':400, 'category':'Plomberie', 'city':'Marrakech', 'is_urgent':True,
                 'basic_price':250, 'basic_delivery_days':1, 'standard_price':400, 'standard_delivery_days':1, 'premium_price':700, 'premium_delivery_days':2},
            ]),
            ('hassan.fes', [
                {'title':'Zellige Traditionnel de Fès', 'description':'Pose zellige artisanal traditionnel de Fès. Motifs géométriques authentiques.', 'price':800, 'category':'Mosaïque', 'city':'Fes', 'is_urgent':False,
                 'basic_price':500, 'basic_delivery_days':3, 'standard_price':800, 'standard_delivery_days':5, 'premium_price':1200, 'premium_delivery_days':7},
                {'title':'Restauration Zellige Ancien', 'description':'Restauration de zellige ancien dans riads et monuments. Conservation patrimoine.', 'price':3000, 'category':'Mosaïque', 'city':'Fes', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':7, 'standard_price':3000, 'standard_delivery_days':10, 'premium_price':5000, 'premium_delivery_days':15},
            ]),
        ]
        
        created_services = []
        for username, svcs in services_data:
            worker = User.query.filter_by(username=username).first()
            if worker:
                for sd in svcs:
                    s = Service.query.filter_by(title=sd['title'], worker_id=worker.id).first()
                    if not s:
                        s = Service(
                            title=sd['title'], description=sd['description'], price=sd['price'],
                            category=sd['category'], city=sd['city'], worker_id=worker.id,
                            is_active=True, is_urgent=sd.get('is_urgent', False),
                            basic_price=sd.get('basic_price', sd['price']),
                            basic_delivery_days=sd.get('basic_delivery_days', 1),
                            standard_price=sd.get('standard_price', sd['price']*1.5),
                            standard_delivery_days=sd.get('standard_delivery_days', 3),
                            premium_price=sd.get('premium_price', sd['price']*2),
                            premium_delivery_days=sd.get('premium_delivery_days', 7),
                            active_package='standard', views_count=45,
                            gig_tags=sd['category'].lower()+',urgent,'+sd['city'].lower()
                        )
                        db.session.add(s)
                        db.session.flush()
                        created_services.append(s)
        db.session.commit()
        print(f'{len(created_services)} demo services created')
        
        # Create demo clients
        clients_data = [
            {'username':'client.casa', 'full_name':'Saad El Amrani', 'email':'saad@client.ma', 'password':'client123', 'city':'Casablanca', 'phone':'0711111111'},
            {'username':'client.rabat', 'full_name':'Latifa Benjelloun', 'email':'latifa@client.ma', 'password':'client123', 'city':'Rabat', 'phone':'0722222222'},
            {'username':'client.marrakech', 'full_name':'Reda Filali', 'email':'reda@client.ma', 'password':'client123', 'city':'Marrakech', 'phone':'0733333333'},
            {'username':'client.fes', 'full_name':'Imane Chafik', 'email':'imane@client.ma', 'password':'client123', 'city':'Fes', 'phone':'0744444444'},
            {'username':'client.tanger', 'full_name':'Yassine Berrada', 'email':'yassine@client.ma', 'password':'client123', 'city':'Tangier', 'phone':'0755555555'},
        ]
        created_clients = []
        for cd in clients_data:
            c = User.query.filter_by(username=cd['username']).first()
            if not c:
                c = User(username=cd['username'], full_name=cd['full_name'], email=cd['email'],
                         password_hash=generate_password_hash(cd['password']), user_type='client',
                         city=cd['city'], is_active=True, phone=cd.get('phone'))
                db.session.add(c)
                db.session.flush()
                created_clients.append(c)
        db.session.commit()
        print(f'{len(created_clients)} demo clients created')
        
        # Create PAID bookings with invoices
        if created_clients and created_services:
            import random
            
            for i, client in enumerate(created_clients):
                # Book 2-3 services per client
                for svc in random.sample(created_services, min(2, len(created_services))):
                    # Create booking
                    b = Booking(service_id=svc.id, client_id=client.id, status='completed',
                                message=f'Reservation pour {svc.title}', created_at=datetime.utcnow()-timedelta(days=random.randint(1,30)))
                    db.session.add(b)
                    db.session.flush()
                    
                    # Create payment
                    amount = svc.standard_price or svc.price
                    ref = 'LMQ' + ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=10))
                    p = Payment(user_id=client.id, amount=amount, type='service', reference=ref,
                                description=f'Paiement: {svc.title}', status='completed',
                                completed_at=datetime.utcnow()-timedelta(days=random.randint(0,5)))
                    db.session.add(p)
                    db.session.flush()
                    
                    # Create invoice
                    tva_rate = 20.0
                    amount_ht = round(amount / (1 + tva_rate/100), 2)
                    amount_tva = round(amount - amount_ht, 2)
                    inv = Invoice(
                        payment_id=p.id, user_id=client.id, worker_id=svc.worker_id,
                        invoice_number=generate_invoice_number(),
                        amount_ht=amount_ht, tva_rate=tva_rate, amount_tva=amount_tva,
                        amount_ttc=amount, description=f'Facture: {svc.title}',
                        status='paid', paid_at=p.completed_at, booking_id=b.id,
                        items=f'[{{"label":"{svc.title}","qty":1,"unit_price":{amount},"total":{amount}}}]'
                    )
                    db.session.add(inv)
                    
                    # Create review for some bookings
                    if random.random() > 0.3:
                        r = Review(worker_id=svc.worker_id, client_id=client.id,
                                   rating=random.choice([4,5]),
                                   comment=random.choice([
                                       'Excellent travail, très professionnel !',
                                       'Intervention rapide et soignée. Merci !',
                                       'Très satisfait du résultat. Je recommande.',
                                       'Service impeccable, prix juste.',
                                       'Worker ponctuel et efficace. À refaire !'
                                   ]))
                        db.session.add(r)
            db.session.commit()
            print(f'PAID bookings with invoices created successfully')
        
        # Create 2 annonces per service category
        annonces_data = [
            {'title':'Cherche électricien urgent Casa', 'description':'Panne électrique dans mon appartement, besoin d\'intervention rapide.', 'category':'Électricité', 'city':'Casablanca', 'price':300, 'author':'client.casa'},
            {'title':'Installation éclairage LED boutique', 'description':'Cherche électricien pour installer éclairage LED dans ma boutique.', 'category':'Électricité', 'city':'Casablanca', 'price':2000, 'author':'client.casa'},
            {'title':'Peinture salon 40m2', 'description':'Besoin de peindre mon salon, couleur blanche mate.', 'category':'Peinture', 'city':'Casablanca', 'price':3500, 'author':'client.rabat'},
            {'title':'Papier peint chambre', 'description':'Installation papier peint dans 2 chambres.', 'category':'Peinture', 'city':'Rabat', 'price':1500, 'author':'client.rabat'},
            {'title':'Placard dressing sur mesure', 'description':'Cherche menuisier pour dressing sur mesure 3 portes.', 'category':'Menuiserie', 'city':'Rabat', 'price':6000, 'author':'client.rabat'},
            {'title':'Cuisine équipée complète', 'description':'Installation cuisine équipée dans nouvel appartement.', 'category':'Menuiserie', 'city':'Rabat', 'price':18000, 'author':'client.casa'},
            {'title':'Fuite sous évier urgent', 'description':'Fuite importante sous l\'évier, inondation imminente !', 'category':'Plomberie', 'city':'Marrakech', 'price':400, 'author':'client.marrakech'},
            {'title':'Installation chauffe-eau neuf', 'description':'Remplacement chauffe-eau 100L, fourniture et pose.', 'category':'Plomberie', 'city':'Marrakech', 'price':2500, 'author':'client.marrakech'},
            {'title':'Zellige salle de bain', 'description':'Pose zellige 5m2 dans salle de bain riad.', 'category':'Mosaïque', 'city':'Fes', 'price':5000, 'author':'client.fes'},
            {'title':'Restauration zellige ancien', 'description':'Restauration zellige dégradé dans patio riad.', 'category':'Mosaïque', 'city':'Fes', 'price':8000, 'author':'client.fes'},
        ]
        
        for ad in annonces_data:
            author = User.query.filter_by(username=ad['author']).first()
            if author:
                a = Annonce.query.filter_by(title=ad['title']).first()
                if not a:
                    a = Annonce(title=ad['title'], description=ad['description'],
                                category=ad['category'], city=ad['city'], price=ad['price'],
                                author_id=author.id, type='demande_service')
                    db.session.add(a)
        db.session.commit()
        print(f'{len(annonces_data)} demo annonces created')
        
        # Create demo messages between workers and clients
        messages_data = [
            ('youssef.casa', 'client.casa', 'Bonjour, êtes-vous disponible demain pour une intervention électrique ?', True),
            ('client.casa', 'youssef.casa', 'Oui, je suis disponible vers 14h. Quelle est l\'adresse ?', False),
            ('youssef.casa', 'client.casa', 'Parfait, je serai là à 14h précises. Merci !', True),
            ('karim.marrakech', 'client.marrakech', 'J\'ai une fuite sous mon évier, pouvez-vous venir rapidement ?', True),
            ('client.marrakech', 'karim.marrakech', 'Oui c\'est urgent, je suis à la Médina près de la porte Bab Agnaou.', False),
            ('hassan.fes', 'client.fes', 'Bonjour, je peux voir votre patio pour évaluer le zellige ?', True),
            ('client.fes', 'hassan.fes', 'Oui bien sûr, venez quand vous voulez cette semaine.', False),
        ]
        for sender_u, receiver_u, content, is_read in messages_data:
            sender = User.query.filter_by(username=sender_u).first()
            receiver = User.query.filter_by(username=receiver_u).first()
            if sender and receiver:
                m = Message.query.filter_by(sender_id=sender.id, receiver_id=receiver.id, content=content).first()
                if not m:
                    db.session.add(Message(sender_id=sender.id, receiver_id=receiver.id,
                                          content=content, is_read=is_read))
        db.session.commit()
        print('Demo messages created')
        
    # Print summary
    print('\n========== DEMO DATA SUMMARY ==========')
    print(f'Workers: {User.query.filter_by(user_type="worker").count()}')
    print(f'Clients: {User.query.filter_by(user_type="client").count()}')
    print(f'Services: {Service.query.count()}')
    print(f'Annonces: {Annonce.query.count()}')
    print(f'Bookings: {Booking.query.count()}')
    print(f'PAID Bookings: {Booking.query.filter_by(status="completed").count()}')
    print(f'Payments: {Payment.query.count()}')
    print(f'Invoices: {Invoice.query.count()}')
    print(f'Reviews: {Review.query.count()}')
    print(f'Messages: {Message.query.count()}')
    print('======================================\n')


