from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

bookings_bp = Blueprint('bookings', __name__)

@bookings_bp.route('/book-service/<int:service_id>', methods=['POST'])
@login_required
def book_service(service_id):
    service = Service.query.get_or_404(service_id)
    user = User.query.get(session['user_id'])
    if user.user_type not in ['client']:
        flash('Only clients.', 'danger')
        return redirect(url_for('services.service_detail', id=service_id))
    message = request.form.get('message')
    insurance = request.form.get('insurance') == 'on'
    if not message:
        flash('Message required.', 'danger')
        return redirect(url_for('services.service_detail', id=service_id))
    # Commission calculation
    config = AppConfig.get()
    commission = service.price * (config.commission_rate / 100)
    booking = Booking(client_id=session['user_id'], service_id=service_id, message=message,
                     commission_amount=commission, insurance_used=insurance)
    db.session.add(booking)
    db.session.flush()
    db.session.add(Commission(worker_id=service.worker_id, booking_id=booking.id, amount=commission,
                             rate_percent=config.commission_rate))
    # Points for booking
    user.points += 10
    worker = User.query.get(service.worker_id)
    worker.points += 20
    # Notify worker
    notif = Notification(user_id=service.worker_id, title='Nouvelle reservation',
                        message=f'{user.full_name} a reserve "{service.title}"',
                        type='booking', link='/my-bookings')
    db.session.add(notif)
    db.session.commit()
    check_and_award_badges(worker)
    flash('Booking sent!', 'success')
    return redirect(url_for('services.service_detail', id=service_id))

@bookings_bp.route('/my-bookings')
@login_required
def my_bookings():
    user = User.query.get(session['user_id'])
    if user.user_type == 'client':
        bookings = Booking.query.filter_by(client_id=session['user_id']).order_by(Booking.created_at.desc()).all()
    else:
        bookings = Booking.query.join(Service).filter(Service.worker_id == session['user_id']).order_by(Booking.created_at.desc()).all()
    return render_template('my_bookings.html', bookings=bookings)

@bookings_bp.route('/booking/update/<int:id>', methods=['POST'])
@login_required
def update_booking(id):
    booking = Booking.query.get_or_404(id)
    service = Service.query.get(booking.service_id)
    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    status = request.form.get('status')
    if status in ['accepted', 'rejected', 'completed']:
        booking.status = status
        booking.updated_at = datetime.utcnow()
        if status == 'completed':
            commission = Commission.query.filter_by(booking_id=booking.id).first()
            if commission: commission.status = 'due'
            worker = User.query.get(session['user_id'])
            worker.points += 50
            check_and_award_badges(worker)
        notif = Notification(user_id=booking.client_id, title='Reservation mise a jour',
                            message=f'Votre reservation est {status}', type='success', link='/my-bookings')
        db.session.add(notif)
        db.session.commit()
        flash(f'Booking {status}!', 'success')
    return redirect(url_for('bookings.my_bookings'))

@bookings_bp.route('/booking/<int:booking_id>/pay-escrow', methods=['POST'])
@login_required
def pay_escrow(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    client = User.query.get(session['user_id'])
    if booking.client_id != client.id:
        flash('Non autorise.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    service = Service.query.get(booking.service_id)
    amount = request.form.get('amount', type=float) or service.price
    if client.wallet_balance >= amount:
        client.wallet_balance -= amount
        booking.escrow_status = 'held'
        booking.status = 'confirmed'
        payment = Payment(user_id=client.id, amount=amount, type='escrow',
                          reference='ESC' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)),
                          description=f'Acompte pour {service.title}',
                          status='completed', is_escrow=True, escrow_status='held',
                          booking_id=booking.id)
        db.session.add(payment)
        db.session.commit()
        flash(f'Acompte de {amount} MAD bloque avec succes.', 'success')
    else:
        flash('Solde insuffisant. Rechargez votre portefeuille.', 'warning')
        return redirect(url_for('payments.wallet'))
    return redirect(url_for('bookings.my_bookings'))

@bookings_bp.route('/booking/<int:booking_id>/release-escrow', methods=['POST'])
@login_required
def release_escrow(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    client = User.query.get(session['user_id'])
    if booking.client_id != client.id:
        flash('Non autorise.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if booking.escrow_status != 'held':
        flash('Aucun acompte a liberer.', 'warning')
        return redirect(url_for('bookings.my_bookings'))
    payment = Payment.query.filter_by(booking_id=booking.id, is_escrow=True).first()
    if payment:
        payment.escrow_status = 'released'
        payment.released_at = datetime.utcnow()
        worker = User.query.get(service.worker_id) if (service := Service.query.get(booking.service_id)) else None
        if worker:
            worker.wallet_balance += payment.amount
            db.session.add(WalletTransaction(user_id=worker.id, amount=payment.amount, type='payment',
                              reference=payment.reference, status='completed',
                              description=f'Paiement pour {service.title}'))
    booking.escrow_status = 'released'
    booking.client_confirmed = True
    booking.confirmed_at = datetime.utcnow()
    db.session.commit()
    flash('Paiement libere. Le prestataire a recu son argent.', 'success')
    return redirect(url_for('bookings.my_bookings'))

@bookings_bp.route('/booking/<int:booking_id>/confirm-completion', methods=['POST'])
@login_required
def confirm_completion(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    user = User.query.get(session['user_id'])
    service = Service.query.get(booking.service_id)
    is_client = booking.client_id == user.id
    is_worker = service.worker_id == user.id
    if not (is_client or is_worker):
        flash('Non autorise.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if is_client:
        booking.client_confirmed = True
    if is_worker:
        booking.worker_confirmed = True
    if booking.client_confirmed and booking.worker_confirmed and booking.escrow_status == 'held':
        return redirect(url_for('bookings.release_escrow', booking_id=booking.id))
    db.session.commit()
    flash('Intervention confirmée. En attente de l\'autre partie.', 'success')
    return redirect(url_for('bookings.my_bookings'))

@bookings_bp.route('/booking/<int:booking_id>/track-worker')
@login_required
def track_worker_location(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])
    if booking.client_id != user.id and service.worker_id != user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    worker = User.query.get(service.worker_id)
    if not worker or not worker.is_tracking_enabled:
        return jsonify({'error': 'Worker not sharing location'}), 404
    return jsonify({
        'latitude': worker.last_latitude, 'longitude': worker.last_longitude,
        'last_update': worker.last_location_update.strftime('%H:%M:%S') if worker.last_location_update else None,
        'worker_name': worker.full_name, 'is_tracking': worker.is_tracking_enabled
    })

@bookings_bp.route('/booking/<int:booking_id>/upload-progress', methods=['POST'])
@login_required
def upload_progress_photos(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])
    if service.worker_id != user.id:
        flash('Seul le prestataire peut uploader.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if 'before_photo' in request.files:
        f = request.files['before_photo']
        if f and f.filename:
            path = save_uploaded_file(f, 'services')
            if path: booking.before_photo = path
    if 'after_photo' in request.files:
        f = request.files['after_photo']
        if f and f.filename:
            path = save_uploaded_file(f, 'services')
            if path: booking.after_photo = path
    db.session.commit()
    flash('Photos uploadées.', 'success')
    return redirect(url_for('bookings.my_bookings'))

