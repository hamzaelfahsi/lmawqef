from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

workers_bp = Blueprint('workers', __name__)

@workers_bp.route('/profile/<int:id>')
def profile(id):
    user = User.query.get_or_404(id)
    services = Service.query.filter_by(worker_id=id, is_active=True).all() if user.user_type in ['worker','entreprise'] else []
    reviews = Review.query.filter_by(worker_id=id).order_by(Review.created_at.desc()).all()
    portfolio = PortfolioItem.query.filter_by(user_id=id).order_by(PortfolioItem.created_at.desc()).all()
    badges = user.get_badges_list()
    level = user.get_level()
    has_booked = False
    if 'user_id' in session and session['user_id'] != id:
        has_booked = Booking.query.join(Service).filter(Booking.client_id == session['user_id'],
                                                        Service.worker_id == id).first() is not None
    return render_template('profile.html', user=user, services=services, reviews=reviews,
                         portfolio=portfolio, badges=badges, level=level, has_booked=has_booked)

@workers_bp.route('/my-profile', methods=['GET', 'POST'])
@login_required
def my_profile():
    user = User.query.get(session['user_id'])
    if request.method == 'POST':
        user.full_name = request.form.get('full_name')
        user.phone = request.form.get('phone')
        user.city = request.form.get('city')
        user.description = request.form.get('description')
        user.address = request.form.get('address')
        user.company_name = request.form.get('company_name')
        # Fiverr-style fields
        user.profession_title = request.form.get('profession_title')
        user.languages = request.form.get('languages')
        user.education = request.form.get('education')
        user.certifications = request.form.get('certifications')
        user.website_url = request.form.get('website_url')
        user.linkedin_url = request.form.get('linkedin_url')
        user.profile_video_url = request.form.get('profile_video_url')
        user.money_back_guarantee = request.form.get('money_back_guarantee') == 'on'
        rth = request.form.get('response_time_hours')
        if rth:
            try: user.response_time_hours = int(rth)
            except: pass
        if user.user_type in ['worker', 'entreprise']:
            user.skills = request.form.get('skills')
            user.rc_number = request.form.get('rc_number')
            user.ice_number = request.form.get('ice_number')
        # Cover photo upload
        if 'cover_photo' in request.files:
            file = request.files['cover_photo']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'profiles')
                if img_path: user.cover_photo = img_path
        # Avatar upload
        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'profiles')
                if img_path: user.avatar = img_path
        # Portfolio upload
        if 'portfolio_files' in request.files:
            files = request.files.getlist('portfolio_files')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'portfolio')
                    if img_path:
                        db.session.add(PortfolioItem(user_id=user.id,
                            title=request.form.get('portfolio_title', 'Portfolio'), filename=img_path))
        lat = request.form.get('latitude')
        lng = request.form.get('longitude')
        if lat and lng:
            try:
                user.latitude = float(lat)
                user.longitude = float(lng)
            except ValueError: pass
        db.session.commit()
        flash('Profil mis a jour avec succes!', 'success')
        return redirect(url_for('workers.my_profile'))
    portfolio = PortfolioItem.query.filter_by(user_id=user.id).order_by(PortfolioItem.created_at.desc()).all()
    badges = user.get_badges_list()
    level = user.get_level()
    availability = Availability.query.filter_by(user_id=user.id).all()
    invoices = Invoice.query.filter_by(user_id=user.id).order_by(Invoice.created_at.desc()).all()
    return render_template('my_profile.html', user=user, portfolio=portfolio, badges=badges,
                         level=level, availability=availability, cities=MOROCCAN_CITIES, categories=CATEGORIES,
                         invoices=invoices)

@workers_bp.route('/workers')
def workers():
    page = request.args.get('page', 1, type=int)
    city = request.args.get('city', '')
    skill = request.args.get('skill', '')
    user_type = request.args.get('user_type', '')
    query = User.query.filter(User.user_type.in_(['worker', 'entreprise']), User.is_active == True)
    if city: query = query.filter_by(city=city)
    if skill: query = query.filter(User.skills.contains(skill))
    if user_type: query = query.filter_by(user_type=user_type)
    workers = query.order_by(User.points.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('workers.html', workers=workers, city=city, skill=skill, user_type=user_type, cities=MOROCCAN_CITIES, categories=CATEGORIES)

@workers_bp.route('/leaderboard')
def leaderboard():
    top_workers = User.query.filter(User.user_type.in_(['worker','entreprise'])).order_by(User.points.desc()).limit(20).all()
    return render_template('leaderboard.html', top_workers=top_workers)

@workers_bp.route('/featured')
def featured_profiles():
    featured = User.query.filter_by(is_featured=True, is_active=True).filter(
        User.user_type.in_(['worker','entreprise'])).order_by(User.featured_until.desc()).limit(12).all()
    return render_template('featured.html', featured=featured)

@workers_bp.route('/dashboard/worker')
@login_required
def dashboard_worker():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
    total_services = Service.query.filter_by(worker_id=user.id).count()
    active_services = Service.query.filter_by(worker_id=user.id, is_active=True).count()
    total_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
    pending_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'pending').count()
    completed_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'completed').count()
    avg_rating = user.average_rating()
    total_reviews = user.review_count()
    total_views = db.session.query(db.func.sum(Service.views_count)).filter_by(worker_id=user.id).scalar() or 0
    # Monthly stats
    current_month = datetime.utcnow().month
    monthly_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id,
        db.extract('month', Booking.created_at) == current_month).count()
    # Commission stats
    total_commissions = db.session.query(db.func.sum(Commission.amount)).filter_by(worker_id=user.id).scalar() or 0
    pending_commissions = db.session.query(db.func.sum(Commission.amount)).filter_by(worker_id=user.id, status='pending').scalar() or 0
    # Revenue
    total_revenue = db.session.query(db.func.sum(Booking.commission_amount)).join(Service).filter(
        Service.worker_id == user.id, Booking.status == 'completed').scalar() or 0
    recent_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).order_by(Booking.created_at.desc()).limit(5).all()
    subscription = user.subscription_plan if user.has_active_subscription() else None
    badges = user.get_badges_list()
    level = user.get_level()
    stats = {
        'total_services': total_services, 'active_services': active_services,
        'total_bookings': total_bookings, 'pending_bookings': pending_bookings,
        'completed_bookings': completed_bookings, 'avg_rating': avg_rating,
        'total_reviews': total_reviews, 'total_views': total_views,
        'monthly_bookings': monthly_bookings, 'total_commissions': total_commissions,
        'pending_commissions': pending_commissions, 'total_revenue': total_revenue,
        'points': user.points
    }
    return render_template('dashboard_worker.html', stats=stats, recent_bookings=recent_bookings,
                         subscription=subscription, user=user, badges=badges, level=level)

@workers_bp.route('/become-featured')
@login_required
def become_featured():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers.', 'danger')
        return redirect(url_for('main.index'))
    config = AppConfig.get()
    return render_template('become_featured.html', price=config.featured_profile_price)

@workers_bp.route('/worker/<int:worker_id>/schedule')
def worker_schedule(worker_id):
    worker = User.query.get_or_404(worker_id)
    slots = Availability.query.filter_by(user_id=worker.id).all()
    services = Service.query.filter_by(worker_id=worker.id, is_active=True).all()
    return render_template('worker_schedule.html', worker=worker, slots=slots, services=services)

@workers_bp.route('/booking/schedule/<int:booking_id>', methods=['POST'])
@login_required
def schedule_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    user = User.query.get(session['user_id'])
    service = Service.query.get(booking.service_id)
    is_client = booking.client_id == user.id
    is_worker = service.worker_id == user.id
    if not (is_client or is_worker):
        flash('Non autorise.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    date_str = request.form.get('scheduled_date')
    time_str = request.form.get('scheduled_time')
    end_time = request.form.get('scheduled_end_time')
    if date_str:
        try:
            from datetime import date
            booking.scheduled_date = date.fromisoformat(date_str)
            booking.scheduled_time = time_str
            booking.scheduled_end_time = end_time
            other_id = service.worker_id if is_client else booking.client_id
            db.session.add(Notification(
                user_id=other_id, title='Rendez-vous planifie',
                message=f'Rendez-vous fixe au {date_str} a {time_str}.',
                type='schedule', link='/my-bookings'
            ))
            db.session.commit()
            flash('Rendez-vous planifie avec succes !', 'success')
        except:
            flash('Format de date invalide.', 'danger')
    return redirect(url_for('bookings.my_bookings'))

@workers_bp.route('/verify-identity', methods=['GET', 'POST'])
@login_required
def verify_identity():
    user = User.query.get(session['user_id'])
    verification = IdentityVerification.query.filter_by(user_id=user.id).first()
    if request.method == 'POST':
        if not verification:
            verification = IdentityVerification(user_id=user.id)
            db.session.add(verification)
        for field_name, attr_name in [('cin_front', 'cin_front'), ('cin_back', 'cin_back'), ('selfie', 'selfie')]:
            if field_name in request.files:
                file = request.files[field_name]
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'profiles')
                    if img_path:
                        setattr(verification, attr_name, img_path)
        verification.status = 'pending'
        db.session.commit()
        flash('Documents soumis. Notre equipe examine votre dossier.', 'success')
        return redirect(url_for('workers.verify_identity'))
    return render_template('verify_identity.html', user=user, verification=verification)

@workers_bp.route('/worker/start-tracking', methods=['POST'])
@login_required
def start_tracking():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        return jsonify({'error': 'Workers only'}), 403
    user.is_tracking_enabled = True
    db.session.commit()
    return jsonify({'success': True, 'tracking': True})

@workers_bp.route('/worker/stop-tracking', methods=['POST'])
@login_required
def stop_tracking():
    user = User.query.get(session['user_id'])
    user.is_tracking_enabled = False
    db.session.commit()
    return jsonify({'success': True, 'tracking': False})

@workers_bp.route('/worker/update-location', methods=['POST'])
@login_required
def update_location():
    user = User.query.get(session['user_id'])
    if not user.is_tracking_enabled:
        return jsonify({'error': 'Tracking not enabled'}), 403
    lat = request.json.get('latitude')
    lng = request.json.get('longitude')
    acc = request.json.get('accuracy')
    if lat is None or lng is None:
        return jsonify({'error': 'Missing coordinates'}), 400
    user.last_latitude = float(lat)
    user.last_longitude = float(lng)
    user.last_location_update = datetime.utcnow()
    db.session.add(WorkerLocation(worker_id=user.id, latitude=lat, longitude=lng, accuracy=acc))
    db.session.commit()
    return jsonify({'success': True})

@workers_bp.route('/worker/<int:worker_id>/favorite', methods=['POST'])
@login_required
def toggle_favorite(worker_id):
    user_id = session['user_id']
    existing = Favorite.query.filter_by(user_id=user_id, worker_id=worker_id).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        return jsonify({'favorited': False})
    else:
        db.session.add(Favorite(user_id=user_id, worker_id=worker_id))
        db.session.commit()
        return jsonify({'favorited': True})

@workers_bp.route('/become-worker', methods=['GET', 'POST'])
@login_required
def become_worker():
    user = User.query.get(session['user_id'])
    if user.user_type in ['worker', 'entreprise']:
        flash('Vous etes deja un prestataire!', 'info')
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        user.user_type = 'worker'
        user.worker_subtype = request.form.get('worker_subtype', 'autoentrepreneur')
        user.profession = request.form.get('profession', '')
        user.skills = request.form.get('skills', '')
        user.description = request.form.get('description', '')
        user.phone = request.form.get('phone', user.phone)
        user.city = request.form.get('city', user.city)
        db.session.commit()
        flash('Felicitations! Votre profil prestataire est active.', 'success')
        return redirect(url_for('main.dashboard'))
    return render_template('become_worker.html', user=user, cities=MOROCCAN_CITIES, categories=CATEGORIES)

@workers_bp.route('/worker/<username>')
def worker_public_profile(username):
    """Public worker profile page"""
    worker = User.query.filter_by(username=username, user_type='worker').first_or_404()
    services = Service.query.filter_by(worker_id=worker.id, is_active=True).all()
    reviews = Review.query.filter_by(worker_id=worker.id).order_by(Review.created_at.desc()).all()
    portfolio = PortfolioItem.query.filter_by(user_id=worker.id).order_by(PortfolioItem.created_at.desc()).all()
    return render_template('profile.html', user=worker, services=services, reviews=reviews, portfolio=portfolio)

