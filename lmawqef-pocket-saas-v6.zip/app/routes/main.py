from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES, ALLOWED_EXTENSIONS, ANNONCE_TYPES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    featured_services = Service.query.filter_by(is_active=True).order_by(Service.created_at.desc()).limit(6).all()
    featured_workers = User.query.filter_by(is_featured=True, is_active=True).filter(User.user_type.in_(['worker','entreprise'])).limit(4).all()
    top_workers = User.query.filter(User.user_type.in_(['worker','entreprise'])).all()
    top_workers = sorted(top_workers, key=lambda w: w.average_rating(), reverse=True)[:4]
    urgent_services = Service.query.filter_by(is_urgent=True, is_active=True).limit(3).all()
    stats = {
        'workers': User.query.filter(User.user_type.in_(['worker','entreprise'])).count(),
        'clients': User.query.filter_by(user_type='client').count(),
        'services': Service.query.filter_by(is_active=True).count(),
        'bookings': Booking.query.count(),
        'annonces': Annonce.query.filter_by(is_active=True).count(),
        'entreprises': User.query.filter_by(user_type='entreprise').count()
    }
    return render_template('index.html', featured_services=featured_services, top_workers=top_workers,
                         featured_workers=featured_workers, urgent_services=urgent_services, stats=stats,
                         categories=CATEGORIES, cities=MOROCCAN_CITIES)

@main_bp.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    if user.user_type == 'entreprise':
        return redirect(url_for('dashboard_entreprise'))
    elif user.user_type == 'worker':
        return redirect(url_for('dashboard_worker'))
    else:
        return redirect(url_for('main.dashboard_client'))

@main_bp.route('/dashboard/client')
@login_required
def dashboard_client():
    user = User.query.get(session['user_id'])
    if user.user_type != 'client':
        return redirect(url_for('main.dashboard'))
    total_bookings = Booking.query.filter_by(client_id=user.id).count()
    pending_bookings = Booking.query.filter_by(client_id=user.id, status='pending').count()
    completed_bookings = Booking.query.filter_by(client_id=user.id, status='completed').count()
    total_reviews = Review.query.filter_by(client_id=user.id).count()
    recent_bookings = Booking.query.filter_by(client_id=user.id).order_by(Booking.created_at.desc()).limit(5).all()
    stats = {'total_bookings': total_bookings, 'pending_bookings': pending_bookings,
             'completed_bookings': completed_bookings, 'total_reviews': total_reviews}
    return render_template('dashboard_client.html', stats=stats, recent_bookings=recent_bookings)

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        if not all([name, email, subject, message]):
            flash('All fields required.', 'danger')
            return redirect(url_for('main.contact'))
        msg = ContactMessage(name=name, email=email, subject=subject, message=message)
        db.session.add(msg)
        db.session.commit()
        flash('Message sent!', 'success')
        return redirect(url_for('main.contact'))
    return render_template('contact.html', cities=MOROCCAN_CITIES)

@main_bp.route('/about')
def about():
    stats = {
        'users': User.query.count(),
        'workers': User.query.filter(User.user_type.in_(['worker','entreprise'])).count(),
        'services': Service.query.filter_by(is_active=True).count(),
        'bookings': Booking.query.count(),
        'annonces': Annonce.query.filter_by(is_active=True).count(),
        'revenue': db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0
    }
    return render_template('about.html', stats=stats, cities=MOROCCAN_CITIES, categories=CATEGORIES)

@main_bp.route('/ai-match', methods=['GET', 'POST'])
@login_required
def ai_match():
    if request.method == 'POST':
        category_id = request.form.get('category_id', type=int)
        city = request.form.get('city', '')
        description = request.form.get('description', '')

        # Find all eligible workers
        workers = User.query.filter(
            User.user_type.in_(['worker', 'entreprise', 'auto_entrepreneur', 'freelance']),
            User.is_active == True
        ).all()

        results = []
        for worker in workers:
            score, factors = calculate_match_score(
                client=User.query.get(session['user_id']), worker=worker, 
                service_category=category_id, city=city
            )

            # Boost for verified, featured, insurance
            if worker.is_featured: score += 5
            if worker.insurance_active: score += 3

            # Keyword matching in description
            if description and worker.skills:
                keywords = description.lower().split()
                skill_words = worker.skills.lower().split()
                matches = sum(1 for k in keywords if k in skill_words)
                score += min(matches * 2, 10)

            results.append({
                'worker': worker,
                'score': round(score, 1),
                'factors': factors,
                'rating': worker.average_rating(),
                'reviews': worker.review_count(),
                'completed': Booking.query.filter(Booking.service_id.in_([s.id for s in Service.query.filter_by(worker_id=worker.id).all()]), Booking.status=='completed').count() if Service.query.filter_by(worker_id=worker.id).first() else 0
            })

        results.sort(key=lambda x: x['score'], reverse=True)
        top_results = results[:10]

        # Log the match
        if top_results:
            log = AIMatchLog(
                client_id=session['user_id'],
                category_id=category_id,
                city=city,
                top_worker_id=top_results[0]['worker'].id,
                match_score=top_results[0]['score'],
                factors=json.dumps(top_results[0]['factors'])
            )
            db.session.add(log)
            db.session.commit()

        return render_template('ai_match.html', results=top_results, category_id=category_id, city=city)

    categories = Category.query.all()
    return render_template('ai_match.html', categories=categories, results=None)

@main_bp.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy_policy.html')

@main_bp.route('/terms-of-service')
def terms_of_service():
    return render_template('terms_of_service.html')

@main_bp.route('/cookie-policy')
def cookie_policy():
    return render_template('cookie_policy.html')

@main_bp.route('/refund-policy')
def refund_policy():
    return render_template('refund_policy.html')

@main_bp.route('/security-policy')
def security_policy():
    return render_template('security_policy.html')

