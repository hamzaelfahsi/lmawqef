from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm = request.form.get('confirm_password')
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        city = request.form.get('city')
        user_type = request.form.get('user_type')
        if not all([username, email, password, confirm, full_name, phone, city, user_type]):
            flash('All fields required.', 'danger')
            return redirect(url_for('auth.register'))
        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('auth.register'))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return redirect(url_for('auth.register'))
        if User.query.filter_by(username=username).first():
            flash('Username exists.', 'danger')
            return redirect(url_for('auth.register'))
        if User.query.filter_by(email=email).first():
            flash('Email exists.', 'danger')
            return redirect(url_for('auth.register'))
        user = User(username=username, email=email, password_hash=generate_password_hash(password),
                   full_name=full_name, phone=phone, city=city, user_type=user_type,
                   skills=request.form.get('skills', '') if user_type in ['worker', 'entreprise'] else None,
                   description=request.form.get('description', ''),
                   company_name=request.form.get('company_name', '') if user_type == 'entreprise' else None,
                   rc_number=request.form.get('rc_number', '') if user_type == 'entreprise' else None,
                   ice_number=request.form.get('ice_number', '') if user_type == 'entreprise' else None,
                   worker_subtype=request.form.get('worker_subtype') if user_type == 'worker' else None)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!', 'success')
        return redirect(url_for('auth.login'))
    return render_template('register.html', cities=MOROCCAN_CITIES)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            if not user.is_active:
                flash('Account deactivated.', 'danger')
                return redirect(url_for('auth.login'))
            session['user_id'] = user.id
            session['username'] = user.username
            session['user_type'] = user.user_type
            flash(f'Welcome back, {user.full_name}!', 'success')
            next_page = request.args.get('next')
            if next_page: return redirect(next_page)
            return redirect(url_for('main.index'))
        else:
            flash('Invalid username or password.', 'danger')
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('Logged out.', 'info')
    return redirect(url_for('main.index'))

@auth_bp.route('/saas/register', methods=['GET', 'POST'])
def saas_register():
    if request.method == 'POST':
        name = request.form.get('name')
        slug = request.form.get('slug')
        contact_email = request.form.get('email')
        contact_phone = request.form.get('phone')
        city = request.form.get('city')
        plan = request.form.get('plan', 'starter')

        if Organization.query.filter_by(slug=slug).first():
            flash('Organization slug already exists.', 'danger')
            return redirect(url_for('saas_register'))

        org = Organization(
            name=name, slug=slug, contact_email=contact_email,
            contact_phone=contact_phone, city=city, plan=plan,
            status='trial',
            trial_ends_at=datetime.utcnow() + timedelta(days=14)
        )
        db.session.add(org)
        db.session.commit()

        # Create owner member
        if 'user_id' in session:
            member = OrganizationMember(
                organization_id=org.id,
                user_id=session['user_id'],
                role='owner'
            )
            db.session.add(member)
            db.session.commit()

        flash('Organization created! 14-day trial started.', 'success')
        return redirect(url_for('saas_dashboard', org_slug=slug))

    saas_plans = SaaSPlan.query.filter_by(is_active=True).order_by(SaaSPlan.display_order.asc()).all()
    return render_template('saas_register.html', plans=saas_plans)

