MOROCCAN_CITIES = [
    'Casablanca', 'Rabat', 'Marrakech', 'Fes', 'Tangier',
    'Agadir', 'Oujda', 'Kenitra', 'Tetouan', 'Safi',
    'El Jadida', 'Nador', 'Khouribga', 'Beni Mellal', 'Mohammedia',
    'Laayoune', 'Dakhla', 'Essaouira', 'Taza', 'Settat',
    'Berrechid', 'Khemisset', 'Ouarzazate', 'Al Hoceima', 'Errachidia',
    'Meknes', 'Sale', 'Sidi Slimane', 'Guelmim', 'Tiznit',
    'Taroudant', 'Kalaat M Gouna', 'Ifrane', 'Sefrou', 'Azrou',
    'Berkane', 'Taourirt', 'Inezgane', 'Ait Melloul', 'Lqliaa',
    'Midelt', 'Jerada', 'Fkih Ben Salah', 'Youssoufia', 'Sidi Bennour',
    'Oued Zem', 'Bouznika', 'Sidi Kacem', 'Martil', 'Fnideq',
    'Temara', 'Skhirat', 'Benslimane', 'Biougra', 'Ahfir',
    'Zagora', 'Chefchaouen', 'Larache', 'Ksar El Kebir', 'Tan-Tan',
    'Smara', 'Boujdour', 'Sidi Ifni', 'Tata', 'Zemamra',
    'Guercif', 'Had Kourt', 'Sidi Yahya', 'Bir Jdid', 'Ain El Aouda'
]

CATEGORIES = [
    'IT & Technology', 'Construction & Renovation', 'Cleaning & Housekeeping',
    'Transport & Logistics', 'Plumbing & Electrical', 'Carpentry & Woodwork',
    'Painting & Decoration', 'Gardening & Landscaping', 'Automotive & Mechanics',
    'Education & Tutoring', 'Health & Wellness', 'Photography & Events',
    'Legal & Accounting', 'Marketing & Design', 'Urgent Services', 'Other'
]

ANNONCE_TYPES = [
    ('recrutement', 'Recrutement de profils'),
    ('demande_service', 'Demande de service'),
    ('offre_service', 'Offre de service')
]

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
