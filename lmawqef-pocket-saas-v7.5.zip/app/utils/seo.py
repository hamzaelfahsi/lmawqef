from flask import request, url_for
from markupsafe import Markup
import json

class SeoHelper:
    """Generate SEO meta tags, JSON-LD structured data, and Open Graph tags."""
    
    def __init__(self, title=None, description=None, image=None, url=None, lang=None):
        self.title = title or "Lmawqef Pocket | Marketplace Maroc - Artisans & Services"
        self.description = description or (
            "Trouvez les meilleurs artisans, plombiers, électriciens et prestataires au Maroc. "
            "Réservez en ligne, payez en toute sécurité avec escrow et suivi GPS."
        )
        self.image = image or url_for('static', filename='img/og-image.jpg', _external=True)
        self.url = url or request.url
        self.lang = lang or 'fr'
    
    def meta_tags(self):
        tags = f'''<meta name="description" content="{self.description}">
<meta name="keywords" content="artisans Maroc, plombier Casablanca, électricien Rabat, menuisier Marrakech, services à domicile, bricolage, rénovation, Lmawqef">
<meta name="author" content="Lmawqef Pocket">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
<meta name="googlebot" content="index, follow">
<meta property="og:type" content="website">
<meta property="og:title" content="{self.title}">
<meta property="og:description" content="{self.description}">
<meta property="og:image" content="{self.image}">
<meta property="og:url" content="{self.url}">
<meta property="og:site_name" content="Lmawqef Pocket">
<meta property="og:locale" content="{self.lang}_MA">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{self.title}">
<meta name="twitter:description" content="{self.description}">
<meta name="twitter:image" content="{self.image}">
<link rel="canonical" href="{self.url}">'''
        return Markup(tags)
    
    def hreflang_tags(self, alternate_urls=None):
        """Generate hreflang tags for multilingual SEO."""
        base = request.base_url
        tags = f'<link rel="alternate" hreflang="{self.lang}" href="{self.url}">\n'
        for l in ['fr', 'ar', 'en']:
            if l != self.lang:
                tags += f'<link rel="alternate" hreflang="{l}" href="{self.url}?lang={l}">\n'
        tags += f'<link rel="alternate" hreflang="x-default" href="{self.url}">\n'
        return Markup(tags)
    
    def jsonld_website(self):
        data = {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Lmawqef Pocket",
            "url": request.url_root,
            "potentialAction": {
                "@type": "SearchAction",
                "target": request.url_root + "services?search={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }
        return Markup(f'<script type="application/ld+json">{json.dumps(data, ensure_ascii=False)}</script>')
    
    def jsonld_localbusiness(self, worker):
        data = {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": worker.full_name,
            "image": worker.avatar,
            "address": {
                "@type": "PostalAddress",
                "addressLocality": worker.city,
                "addressCountry": "MA"
            },
            "url": request.url,
            "telephone": worker.phone,
            "priceRange": "$$",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": getattr(worker, 'average_rating', lambda: 0)(),
                "reviewCount": getattr(worker, 'review_count', lambda: 0)()
            }
        }
        return Markup(f'<script type="application/ld+json">{json.dumps(data, ensure_ascii=False)}</script>')
    
    def jsonld_service(self, service):
        data = {
            "@context": "https://schema.org",
            "@type": "Service",
            "name": service.title,
            "description": service.description[:200],
            "provider": {
                "@type": "LocalBusiness",
                "name": service.worker.full_name if hasattr(service, 'worker') else "Lmawqef",
                "address": {
                    "@type": "PostalAddress",
                    "addressLocality": service.city,
                    "addressCountry": "MA"
                }
            },
            "areaServed": {
                "@type": "City",
                "name": service.city
            },
            "offers": {
                "@type": "Offer",
                "price": str(service.price),
                "priceCurrency": "MAD",
                "availability": "https://schema.org/InStock"
            }
        }
        return Markup(f'<script type="application/ld+json">{json.dumps(data, ensure_ascii=False)}</script>')
    
    def jsonld_breadcrumbs(self, items):
        """items = [(name, url), ...]"""
        data = {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": i+1,
                    "name": name,
                    "item": url
                } for i, (name, url) in enumerate(items)
            ]
        }
        return Markup(f'<script type="application/ld+json">{json.dumps(data, ensure_ascii=False)}</script>')
