import json
import os
from flask import session

_TRANSLATIONS = {}

def load_translations():
    global _TRANSLATIONS
    if _TRANSLATIONS:
        return _TRANSLATIONS
    base = os.path.join(os.path.dirname(__file__), '..', 'translations')
    for lang in ['fr', 'ar', 'en']:
        path = os.path.join(base, f'{lang}.json')
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                _TRANSLATIONS[lang] = json.load(f)
        else:
            _TRANSLATIONS[lang] = {}
    return _TRANSLATIONS

def get_language():
    return session.get('lang', 'fr')

def set_language(lang):
    if lang in ['fr', 'ar', 'en']:
        session['lang'] = lang
        session['rtl'] = (lang == 'ar')

def get_translations(lang=None):
    if not _TRANSLATIONS:
        load_translations()
    lang = lang or get_language()
    return _TRANSLATIONS.get(lang, _TRANSLATIONS.get('fr', {}))

def _(key, lang=None):
    return get_translations(lang).get(key, key)
