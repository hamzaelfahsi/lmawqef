from flask import session, flash, redirect, url_for, current_app
from werkzeug.utils import secure_filename
from functools import wraps
import os

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first.', 'danger')
            return redirect(url_for('auth.login'))
        from app.models import User
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            flash('Admin access required.', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

def save_uploaded_file(file_obj, folder='services'):
    """Save uploaded file to static/uploads/<folder>/"""
    if not file_obj or not file_obj.filename:
        return None
    filename = secure_filename(file_obj.filename)
    upload_folder = os.path.join(current_app.root_path, 'static', 'uploads', folder)
    os.makedirs(upload_folder, exist_ok=True)
    unique_name = f"{os.urandom(4).hex()}_{filename}"
    file_path = os.path.join(upload_folder, unique_name)
    file_obj.save(file_path)
    return f'uploads/{folder}/{unique_name}'
