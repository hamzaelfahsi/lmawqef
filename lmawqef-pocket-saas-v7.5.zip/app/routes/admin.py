from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
@admin_required
def admin_panel():
    config = AppConfig.get()
    stats = {
        'total_users': User.query.count(),
        'total_workers': User.query.filter_by(user_type='worker').count(),
        'total_entreprises': User.query.filter_by(user_type='entreprise').count(),
        'total_clients': User.query.filter_by(user_type='client').count(),
        'total_services': Service.query.count(),
        'total_bookings': Booking.query.count(),
        'total_reviews': Review.query.count(),
        'total_messages': ContactMessage.query.count(),
        'total_annonces': Annonce.query.count(),
        'total_payments': Payment.query.filter_by(status='completed').count(),
        'revenue': db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0,
        'active_subscriptions': User.query.filter_by(subscription_active=True).count(),
        'pending_bookings': Booking.query.filter_by(status='pending').count(),
        'total_commissions': db.session.query(db.func.sum(Commission.amount)).scalar() or 0,
        'points_distributed': db.session.query(db.func.sum(User.points)).scalar() or 0,
        'featured_profiles': User.query.filter_by(is_featured=True).count(),
    }
    # Monthly data for charts
    months = []
    bookings_monthly = []
    revenue_monthly = []
    for i in range(6):
        month_date = datetime.utcnow() - timedelta(days=30*i)
        months.insert(0, month_date.strftime('%b'))
        m_num = month_date.month
        b_count = Booking.query.filter(db.extract('month', Booking.created_at) == m_num).count()
        bookings_monthly.insert(0, b_count)
        r_sum = db.session.query(db.func.sum(Payment.amount)).filter(
            db.extract('month', Payment.created_at) == m_num, Payment.status == 'completed').scalar() or 0
        revenue_monthly.insert(0, round(r_sum, 0))
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_services = Service.query.order_by(Service.created_at.desc()).limit(10).all()
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(10).all()
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('admin_panel.html', stats=stats, recent_users=recent_users,
                         recent_services=recent_services, recent_bookings=recent_bookings,
                         recent_payments=recent_payments, messages=messages,
                         months=months, bookings_monthly=bookings_monthly, revenue_monthly=revenue_monthly)

@admin_bp.route('/admin/analytics')
@admin_required
def admin_analytics():
    # User growth by month
    months = []
    users_monthly = []
    for i in range(12):
        d = datetime.utcnow() - timedelta(days=30*i)
        months.insert(0, d.strftime('%b %Y'))
        count = User.query.filter(db.extract('month', User.created_at) == d.month,
                                   db.extract('year', User.created_at) == d.year).count()
        users_monthly.insert(0, count)
    # Top categories
    cat_data = {}
    for cat in CATEGORIES:
        cat_data[cat] = Service.query.filter_by(category=cat).count()
    # Top cities
    city_data = {}
    for city in MOROCCAN_CITIES[:10]:
        city_data[city] = User.query.filter_by(city=city).count()
    return render_template('admin_analytics.html', months=months, users_monthly=users_monthly,
                         cat_data=cat_data, city_data=city_data)

@admin_bp.route('/admin/users')
@admin_required
def admin_users():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    user_type = request.args.get('user_type', '')
    query = User.query
    if search:
        query = query.filter(db.or_(User.username.contains(search), User.email.contains(search),
                                     User.full_name.contains(search)))
    if user_type: query = query.filter_by(user_type=user_type)
    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_users.html', users=users, search=search, user_type=user_type)

@admin_bp.route('/admin/user/<int:id>/toggle-active', methods=['POST'])
@admin_required
def toggle_user_active(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('Cannot deactivate yourself.', 'danger')
    else:
        user.is_active = not user.is_active
        db.session.commit()
        flash(f'User {"activated" if user.is_active else "deactivated"}.', 'success')
    return redirect(url_for('admin.admin_users'))

@admin_bp.route('/admin/user/<int:id>/toggle-admin', methods=['POST'])
@admin_required
def toggle_admin(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('Cannot remove your own admin.', 'danger')
    else:
        user.is_admin = not user.is_admin
        if user.is_admin:
            role = AdminRole.query.filter_by(user_id=user.id).first()
            if not role:
                db.session.add(AdminRole(user_id=user.id))
        db.session.commit()
        flash('Admin status updated.', 'success')
    return redirect(url_for('admin.admin_users'))

@admin_bp.route('/admin/user/<int:id>/delete', methods=['POST'])
@admin_required
def delete_user(id):
    user = User.query.get_or_404(id)
    if user.id == session['user_id']:
        flash('Cannot delete yourself.', 'danger')
    else:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted.', 'success')
    return redirect(url_for('admin.admin_users'))

@admin_bp.route('/admin/commissions')
@admin_required
def admin_commissions():
    commissions = Commission.query.order_by(Commission.created_at.desc()).all()
    total_pending = db.session.query(db.func.sum(Commission.amount)).filter_by(status='pending').scalar() or 0
    total_due = db.session.query(db.func.sum(Commission.amount)).filter_by(status='due').scalar() or 0
    total_paid = db.session.query(db.func.sum(Commission.amount)).filter_by(status='paid').scalar() or 0
    return render_template('admin_commissions.html', commissions=commissions,
                         total_pending=total_pending, total_due=total_due, total_paid=total_paid)

@admin_bp.route('/admin/config', methods=['GET', 'POST'])
@admin_required
def admin_config():
    config = AppConfig.get()
    if request.method == 'POST':
        config.annonce_price = float(request.form.get('annonce_price', 20))
        config.free_announces_new_user = int(request.form.get('free_announces_new_user', 5))
        config.annonce_duration_days = int(request.form.get('annonce_duration_days', 30))
        config.commission_rate = float(request.form.get('commission_rate', 10))
        config.insurance_price = float(request.form.get('insurance_price', 50))
        config.featured_profile_price = float(request.form.get('featured_profile_price', 100))
        config.urgency_multiplier = float(request.form.get('urgency_multiplier', 1.5))
        config.contact_email = request.form.get('contact_email')
        config.contact_phone = request.form.get('contact_phone')
        config.updated_at = datetime.utcnow()
        db.session.commit()
        flash('Configuration updated.', 'success')
        return redirect(url_for('admin.admin_config'))
    return render_template('admin_config.html', config=config)

@admin_bp.route('/admin/admins')
@admin_required
def admin_admins():
    admins = User.query.filter_by(is_admin=True).all()
    return render_template('admin_admins.html', admins=admins)

@admin_bp.route('/admin/admin/<int:id>/permissions', methods=['POST'])
@admin_required
def update_admin_permissions(id):
    role = AdminRole.query.filter_by(user_id=id).first()
    if not role:
        role = AdminRole(user_id=id)
        db.session.add(role)
    role.can_manage_users = request.form.get('can_manage_users') == 'on'
    role.can_manage_services = request.form.get('can_manage_services') == 'on'
    role.can_manage_bookings = request.form.get('can_manage_bookings') == 'on'
    role.can_manage_annonces = request.form.get('can_manage_annonces') == 'on'
    role.can_manage_subscriptions = request.form.get('can_manage_subscriptions') == 'on'
    role.can_manage_payments = request.form.get('can_manage_payments') == 'on'
    role.can_manage_admins = request.form.get('can_manage_admins') == 'on'
    role.can_edit_config = request.form.get('can_edit_config') == 'on'
    role.can_view_analytics = request.form.get('can_view_analytics') == 'on'
    db.session.commit()
    flash('Permissions updated.', 'success')
    return redirect(url_for('admin.admin_admins'))

@admin_bp.route('/admin/admin/create', methods=['POST'])
@admin_required
def create_sub_admin():
    current_admin = User.query.get(session['user_id'])
    admin_role = current_admin.admin_role if hasattr(current_admin, 'admin_role') and current_admin.admin_role else None
    if current_admin.id != 1 and (not admin_role or not admin_role.can_manage_admins):
        flash('Vous n\'avez pas le droit de créer des sous-administrateurs.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    username = request.form.get('username')
    full_name = request.form.get('full_name')
    email = request.form.get('email')
    password = request.form.get('password')
    if not all([username, full_name, email, password]):
        flash('Tous les champs sont requis.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    if User.query.filter_by(username=username).first():
        flash('Ce nom d\'utilisateur existe déjà.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    if User.query.filter_by(email=email).first():
        flash('Cet email existe déjà.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    user = User(username=username, full_name=full_name, email=email,
                password_hash=generate_password_hash(password),
                user_type='admin', is_admin=True, is_active=True,
                phone='0000000000', city='Casablanca')
    db.session.add(user)
    db.session.flush()
    role = AdminRole(user_id=user.id)
    role.can_manage_users = request.form.get('can_manage_users') == 'on'
    role.can_manage_services = request.form.get('can_manage_services') == 'on'
    role.can_manage_bookings = request.form.get('can_manage_bookings') == 'on'
    role.can_manage_annonces = request.form.get('can_manage_annonces') == 'on'
    role.can_manage_subscriptions = request.form.get('can_manage_subscriptions') == 'on'
    role.can_manage_payments = request.form.get('can_manage_payments') == 'on'
    role.can_manage_admins = request.form.get('can_manage_admins') == 'on'
    role.can_edit_config = request.form.get('can_edit_config') == 'on'
    role.can_view_analytics = request.form.get('can_view_analytics') == 'on'
    db.session.add(role)
    db.session.commit()
    flash(f'Sous-administrateur {full_name} créé avec succès !', 'success')
    return redirect(url_for('admin.admin_admins'))

@admin_bp.route('/admin/admin/<int:id>/toggle', methods=['POST'])
@admin_required
def toggle_admin_status(id):
    current_admin = User.query.get(session['user_id'])
    admin_role = current_admin.admin_role if hasattr(current_admin, 'admin_role') and current_admin.admin_role else None
    if current_admin.id != 1 and (not admin_role or not admin_role.can_manage_admins):
        flash('Permission refusée.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    user = User.query.get_or_404(id)
    if user.id == 1:
        flash('Impossible de désactiver le super-administrateur.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    user.is_active = not user.is_active
    db.session.commit()
    status = 'activé' if user.is_active else 'désactivé'
    flash(f'Compte {user.full_name} {status}.', 'success')
    return redirect(url_for('admin.admin_admins'))

@admin_bp.route('/admin/admin/<int:id>/delete', methods=['POST'])
@admin_required
def delete_admin(id):
    current_admin = User.query.get(session['user_id'])
    admin_role = current_admin.admin_role if hasattr(current_admin, 'admin_role') and current_admin.admin_role else None
    if current_admin.id != 1 and (not admin_role or not admin_role.can_manage_admins):
        flash('Permission refusée.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    user = User.query.get_or_404(id)
    if user.id == 1:
        flash('Impossible de supprimer le super-administrateur.', 'danger')
        return redirect(url_for('admin.admin_admins'))
    AdminRole.query.filter_by(user_id=user.id).delete()
    db.session.delete(user)
    db.session.commit()
    flash('Sous-administrateur supprimé.', 'success')
    return redirect(url_for('admin.admin_admins'))

@admin_bp.route('/admin/badges', methods=['GET', 'POST'])
@admin_required
def admin_badges():
    if request.method == 'POST':
        badge = Badge(
            name=request.form.get('name'), slug=request.form.get('slug'),
            description=request.form.get('description'),
            icon=request.form.get('icon', 'fa-award'),
            color=request.form.get('color', '#f59e0b'),
            condition_type=request.form.get('condition_type'),
            condition_value=int(request.form.get('condition_value', 0)),
            points_reward=int(request.form.get('points_reward', 0))
        )
        db.session.add(badge)
        db.session.commit()
        flash('Badge added.', 'success')
    badges = Badge.query.all()
    return render_template('admin_badges.html', badges=badges)

@admin_bp.route('/admin/levels', methods=['GET', 'POST'])
@admin_required
def admin_levels():
    if request.method == 'POST':
        level = Level(
            name=request.form.get('name'),
            min_points=int(request.form.get('min_points', 0)),
            max_points=int(request.form.get('max_points')) if request.form.get('max_points') else None,
            icon=request.form.get('icon', 'fa-star'),
            color=request.form.get('color', '#0d9488'),
            benefits=request.form.get('benefits')
        )
        db.session.add(level)
        db.session.commit()
        flash('Level added.', 'success')
    levels = Level.query.order_by(Level.min_points.asc()).all()
    return render_template('admin_levels.html', levels=levels)

@admin_bp.route('/admin/whatsapp')
@admin_required
def admin_whatsapp():
    templates = WhatsAppTemplate.query.all()
    logs = WhatsAppLog.query.order_by(WhatsAppLog.created_at.desc()).limit(100).all()
    return render_template('admin_whatsapp.html', templates=templates, logs=logs)

@admin_bp.route('/api/analytics/admin')
@admin_required
def api_analytics_admin():
    # Platform-wide analytics for admin Chart.js
    months = []
    users_data = []
    bookings_data = []
    revenue_data = []

    for i in range(6):
        month_date = datetime.utcnow() - timedelta(days=30*i)
        month_name = month_date.strftime('%b %Y')
        months.insert(0, month_name)

        start = month_date.replace(day=1, hour=0, minute=0, second=0)
        if i > 0:
            end = (start + timedelta(days=32)).replace(day=1)
        else:
            end = datetime.utcnow()

        u_count = User.query.filter(User.created_at >= start, User.created_at < end).count()
        b_count = Booking.query.filter(Booking.created_at >= start, Booking.created_at < end).count()
        rev = db.session.query(db.func.sum(Payment.amount)).filter(
            Payment.status == 'completed',
            Payment.created_at >= start,
            Payment.created_at < end
        ).scalar() or 0

        users_data.insert(0, u_count)
        bookings_data.insert(0, b_count)
        revenue_data.insert(0, round(float(rev), 2))

    # Category distribution
    cats = Category.query.all()
    cat_labels = [c.name for c in cats]
    cat_counts = [Service.query.filter_by(category_id=c.id, is_active=True).count() for c in cats]

    # City distribution (top 10)
    city_data = db.session.query(User.city, db.func.count(User.id)).group_by(User.city).order_by(db.func.count(User.id).desc()).limit(10).all()

    return jsonify({
        'months': months,
        'new_users': users_data,
        'bookings': bookings_data,
        'revenue': revenue_data,
        'category_labels': cat_labels,
        'category_data': cat_counts,
        'city_labels': [c[0] for c in city_data],
        'city_data': [c[1] for c in city_data],
        'total_users': User.query.count(),
        'total_workers': User.query.filter(User.user_type.in_(['worker', 'entreprise'])).count(),
        'total_bookings': Booking.query.count(),
        'total_revenue': round(float(db.session.query(db.func.sum(Payment.amount)).filter(Payment.status == 'completed').scalar() or 0), 2)
    })

@admin_bp.route('/admin/verifications')
@admin_required
def admin_verifications():
    pending = IdentityVerification.query.filter_by(status='pending').order_by(IdentityVerification.submitted_at.desc()).all()
    return render_template('admin_verifications.html', verifications=pending)

@admin_bp.route('/admin/verification/<int:id>/<action>', methods=['POST'])
@admin_required
def admin_verify_action(id, action):
    v = IdentityVerification.query.get_or_404(id)
    if action == 'approve':
        v.status = 'verified'
        v.verified_at = datetime.utcnow()
        v.user.is_identity_verified = True
        flash('Identite verifiee.', 'success')
    elif action == 'reject':
        v.status = 'rejected'
        v.rejection_reason = request.form.get('reason', 'Document non conforme')
        v.user.is_identity_verified = False
        flash('Verification rejetee.', 'warning')
    db.session.commit()
    return redirect(url_for('admin.admin_verifications'))

@admin_bp.route('/admin/check-super-workers')
@admin_required
def check_super_workers():
    all_workers = User.query.filter(User.user_type.in_(['worker', 'entreprise'])).all()
    if not all_workers:
        flash('Aucun worker trouve.', 'info')
        return redirect(url_for('admin.admin_panel'))
    scored = []
    for w in all_workers:
        rating = w.average_rating() or 1
        completion = w.completion_rate or 100
        score = w.points * rating * (completion / 100)
        scored.append((w, score))
    scored.sort(key=lambda x: x[1], reverse=True)
    top_count = max(1, len(scored) // 10)
    for w in all_workers:
        w.is_super_worker = False
    for w, _ in scored[:top_count]:
        w.is_super_worker = True
    db.session.commit()
    flash(f'{top_count} Super Workers mis a jour.', 'success')
    return redirect(url_for('admin.admin_panel'))

@admin_bp.route('/admin/whatsapp-logs')
@admin_required
def admin_whatsapp_logs():
    return redirect(url_for('admin_whatsapp'))

@admin_bp.route('/admin/urgent')
@admin_required
def admin_urgent():
    return redirect(url_for('admin.admin_panel'))

@admin_bp.route('/admin/settings')
@admin_required
def admin_settings():
    return redirect(url_for('admin.admin_config'))

@admin_bp.route('/admin/insurance')
@admin_required
def admin_insurance():
    return redirect(url_for('admin.admin_panel'))

