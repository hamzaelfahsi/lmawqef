from flask import Blueprint, Response
from app.extensions import db
from app.models import Service

seo_bp = Blueprint('seo', __name__)

@seo_bp.route('/sitemap.xml')
def sitemap():
    from flask import request
    base = request.url_root
    urls = [base, base + 'services', base + 'workers', base + 'annonces']
    for svc in Service.query.filter_by(is_active=True).all():
        urls.append(base + f'service/{svc.id}')
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    for u in urls:
        xml += f'<url><loc>{u}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>\n'
    xml += '</urlset>'
    return Response(xml, mimetype='application/xml')

@seo_bp.route('/robots.txt')
def robots():
    return Response('User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: /sitemap.xml\n', mimetype='text/plain')
