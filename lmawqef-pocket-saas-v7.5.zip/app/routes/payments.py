from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/payment/process', methods=['POST'])
@login_required
def process_payment():
    payment_type = request.form.get('type')
    annonce_id = request.form.get('annonce_id', type=int)
    plan_id = request.form.get('plan_id', type=int)
    booking_id = request.form.get('booking_id', type=int)
    insurance = request.form.get('insurance') == 'on'
    user = User.query.get(session['user_id'])
    
    def create_invoice_for_payment(payment, description, items_list=None, worker_id=None):
        tva_rate = 20.0
        amount_ht = round(payment.amount / (1 + tva_rate/100), 2)
        amount_tva = round(payment.amount - amount_ht, 2)
        inv = Invoice(
            payment_id=payment.id,
            user_id=payment.user_id,
            worker_id=worker_id,
            invoice_number=generate_invoice_number(),
            amount_ht=amount_ht,
            tva_rate=tva_rate,
            amount_tva=amount_tva,
            amount_ttc=payment.amount,
            description=description,
            status='paid',
            paid_at=datetime.utcnow(),
            items=json.dumps(items_list) if items_list else None
        )
        db.session.add(inv)
        db.session.flush()
        return inv
    
    if payment_type == 'annonce' and annonce_id:
        annonce = Annonce.query.get_or_404(annonce_id)
        config = AppConfig.get()
        amount = config.annonce_price
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=amount, type='annonce', reference=ref,
                          description=f'Annonce: {annonce.title}')
        db.session.add(payment)
        db.session.flush()
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        annonce.is_paid = True
        annonce.payment_id = payment.id
        # Generate invoice
        items = [{'label': f'Annonce: {annonce.title}', 'qty': 1, 'unit_price': amount, 'total': amount}]
        inv = create_invoice_for_payment(payment, f'Paiement annonce #{annonce.id}', items)
        db.session.commit()
        flash('Payment successful! Annonce online.', 'success')
        return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
    elif payment_type == 'service' and booking_id:
        booking = Booking.query.get_or_404(booking_id)
        service = booking.service
        amount = float(request.form.get('amount', service.price if service else 0))
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=amount, type='service', reference=ref,
                          description=f'Service: {service.title if service else "N/A"}')
        db.session.add(payment)
        db.session.flush()
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        booking.status = 'paid'
        # Generate invoice
        items = [{'label': service.title if service else 'Service', 'qty': 1, 'unit_price': amount, 'total': amount}]
        inv = create_invoice_for_payment(payment, f'Paiement service #{service.id if service else booking_id}', items, worker_id=service.worker_id if service else None)
        inv.booking_id = booking.id
        db.session.commit()
        flash('Paiement confirme! Facture generee.', 'success')
        return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
    elif payment_type == 'abonnement' and plan_id:
        plan = SubscriptionPlan.query.get_or_404(plan_id)
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=plan.price, type='abonnement', reference=ref,
                          description=f'Abonnement {plan.name}')
        db.session.add(payment)
        db.session.flush()
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        user.subscription_plan_id = plan.id
        user.subscription_active = True
        user.subscription_start = datetime.utcnow()
        user.subscription_end = datetime.utcnow() + timedelta(days=plan.duration_days)
        user.announces_month_used = 0
        user.announces_month_reset = datetime.utcnow()
        items = [{'label': f'Abonnement {plan.name}', 'qty': 1, 'unit_price': plan.price, 'total': plan.price}]
        inv = create_invoice_for_payment(payment, f'Abonnement {plan.name}', items)
        db.session.commit()
        flash(f'Abonnement {plan.name} active!', 'success')
        return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
    elif payment_type == 'featured':
        config = AppConfig.get()
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=config.featured_profile_price, type='featured', reference=ref,
                          description='Featured profile')
        db.session.add(payment)
        db.session.flush()
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        user.is_featured = True
        user.featured_until = datetime.utcnow() + timedelta(days=30)
        items = [{'label': 'Mise en vedette profil 30 jours', 'qty': 1, 'unit_price': config.featured_profile_price, 'total': config.featured_profile_price}]
        inv = create_invoice_for_payment(payment, 'Mise en vedette profil', items)
        db.session.commit()
        flash('Profile featured for 30 days!', 'success')
        return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
    elif payment_type == 'insurance':
        config = AppConfig.get()
        ref = generate_reference()
        payment = Payment(user_id=user.id, amount=config.insurance_price, type='insurance', reference=ref,
                          description='Lmawqef Protect')
        db.session.add(payment)
        db.session.flush()
        payment.status = 'completed'
        payment.completed_at = datetime.utcnow()
        user.insurance_active = True
        user.insurance_expires = datetime.utcnow() + timedelta(days=30)
        items = [{'label': 'Assurance Lmawqef Protect 30 jours', 'qty': 1, 'unit_price': config.insurance_price, 'total': config.insurance_price}]
        inv = create_invoice_for_payment(payment, 'Assurance Lmawqef Protect', items)
        db.session.commit()
        flash('Insurance activated!', 'success')
        return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
    flash('Invalid payment.', 'danger')
    return redirect(url_for('main.index'))

@payments_bp.route('/abonnements')
def abonnements():
    user = User.query.get(session['user_id']) if 'user_id' in session else None
    if user:
        if user.user_type == 'entreprise':
            plans = SubscriptionPlan.query.filter_by(target_type='entreprise', is_active=True).all()
        elif user.user_type == 'worker':
            if user.worker_subtype == 'freelance':
                plans = SubscriptionPlan.query.filter(SubscriptionPlan.target_type.in_(['autoentrepreneur','freelance']),
                                                      SubscriptionPlan.is_active == True).all()
            else:
                plans = SubscriptionPlan.query.filter_by(target_type='autoentrepreneur', is_active=True).all()
        else:
            plans = []
    else:
        plans = SubscriptionPlan.query.filter_by(is_active=True).all()
    return render_template('abonnements.html', plans=plans, user=user)

@payments_bp.route('/abonnement/subscribe/<int:plan_id>')
@login_required
def subscribe_plan(plan_id):
    plan = SubscriptionPlan.query.get_or_404(plan_id)
    user = User.query.get(session['user_id'])
    if plan.price == 0:
        user.subscription_plan_id = plan.id
        user.subscription_active = True
        user.subscription_start = datetime.utcnow()
        user.subscription_end = datetime.utcnow() + timedelta(days=plan.duration_days)
        db.session.commit()
        flash(f'Abonnement {plan.name} active gratuitement!', 'success')
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('payments.payment_abonnement', plan_id=plan_id))

@payments_bp.route('/payment/abonnement/<int:plan_id>')
@login_required
def payment_abonnement(plan_id):
    plan = SubscriptionPlan.query.get_or_404(plan_id)
    return render_template('payment_abonnement.html', plan=plan)

@payments_bp.route('/abonnement/cancel')
@login_required
def cancel_subscription():
    user = User.query.get(session['user_id'])
    user.subscription_active = False
    user.subscription_end = datetime.utcnow()
    db.session.commit()
    flash('Abonnement annule.', 'info')
    return redirect(url_for('main.dashboard'))

@payments_bp.route('/admin/subscriptions')
@admin_required
def admin_subscriptions():
    plans = SubscriptionPlan.query.all()
    active_subs = User.query.filter_by(subscription_active=True).all()
    return render_template('admin_subscriptions.html', plans=plans, active_subs=active_subs)

@payments_bp.route('/admin/subscription/plan/add', methods=['POST'])
@admin_required
def add_subscription_plan():
    plan = SubscriptionPlan(
        name=request.form.get('name'), slug=request.form.get('slug'),
        description=request.form.get('description'),
        price=float(request.form.get('price', 0)),
        duration_days=int(request.form.get('duration_days', 30)),
        annonce_limit=int(request.form.get('annonce_limit', 0)),
        features=request.form.get('features'),
        target_type=request.form.get('target_type')
    )
    db.session.add(plan)
    db.session.commit()
    flash('Plan added.', 'success')
    return redirect(url_for('admin.admin_subscriptions'))

@payments_bp.route('/admin/subscription/plan/edit/<int:id>', methods=['POST'])
@admin_required
def edit_subscription_plan(id):
    plan = SubscriptionPlan.query.get_or_404(id)
    plan.name = request.form.get('name')
    plan.description = request.form.get('description')
    plan.price = float(request.form.get('price', 0))
    plan.duration_days = int(request.form.get('duration_days', 30))
    plan.annonce_limit = int(request.form.get('annonce_limit', 0))
    plan.features = request.form.get('features')
    plan.target_type = request.form.get('target_type')
    plan.is_active = request.form.get('is_active') == 'on'
    db.session.commit()
    flash('Plan updated.', 'success')
    return redirect(url_for('admin.admin_subscriptions'))

@payments_bp.route('/admin/payments')
@admin_required
def admin_payments():
    page = request.args.get('page', 1, type=int)
    payments = Payment.query.order_by(Payment.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    total_revenue = db.session.query(db.func.sum(Payment.amount)).filter_by(status='completed').scalar() or 0
    return render_template('admin_payments.html', payments=payments, total_revenue=total_revenue)

@payments_bp.route('/admin/commission/pay/<int:id>', methods=['POST'])
@admin_required
def pay_commission(id):
    commission = Commission.query.get_or_404(id)
    commission.status = 'paid'
    commission.paid_at = datetime.utcnow()
    db.session.commit()
    flash('Commission paid.', 'success')
    return redirect(url_for('admin_commissions'))

@payments_bp.route('/admin/invoices')
@admin_required
def admin_invoices():
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', 'all')
    query = Invoice.query.order_by(Invoice.created_at.desc())
    if status != 'all':
        query = query.filter_by(status=status)
    invoices = query.paginate(page=page, per_page=20, error_out=False)
    total_revenue = db.session.query(db.func.sum(Invoice.amount_ttc)).filter_by(status='paid').scalar() or 0
    total_count = Invoice.query.count()
    paid_count = Invoice.query.filter_by(status='paid').count()
    return render_template('admin_invoices.html', invoices=invoices, total_revenue=total_revenue,
                          total_count=total_count, paid_count=paid_count, status=status)

@payments_bp.route('/admin/invoice/<int:invoice_id>/view')
@admin_required
def admin_invoice_view(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    items = []
    if invoice.items:
        try:
            items = json.loads(invoice.items) if invoice.items.startswith('[') else []
        except:
            items = []
    return render_template('admin_invoice_modal.html', invoice=invoice, items=items)

@payments_bp.route('/admin/invoice/<int:invoice_id>/download')
@admin_required
def admin_invoice_download(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    items = []
    if invoice.items:
        try:
            items = json.loads(invoice.items) if invoice.items.startswith('[') else []
        except:
            items = []
    from flask import make_response
    rendered = render_template('invoice_pdf.html', invoice=invoice, items=items)
    response = make_response(rendered)
    response.headers['Content-Type'] = 'text/html'
    response.headers['Content-Disposition'] = f'attachment; filename={invoice.invoice_number}.html'
    return response

@payments_bp.route('/admin/invoice/<int:invoice_id>/status', methods=['POST'])
@admin_required
def admin_invoice_status(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    new_status = request.form.get('status')
    if new_status in ['issued', 'paid', 'cancelled']:
        invoice.status = new_status
        db.session.commit()
        flash(f'Facture {invoice.invoice_number} mise à jour : {new_status}', 'success')
    return redirect(url_for('admin.admin_invoices'))

@payments_bp.route('/saas/<org_slug>/dashboard')
@login_required
def saas_dashboard(org_slug):
    org = Organization.query.filter_by(slug=org_slug).first_or_404()
    member = OrganizationMember.query.filter_by(organization_id=org.id, user_id=session['user_id']).first()
    if not member:
        flash('You are not a member of this organization.', 'danger')
        return redirect(url_for('main.index'))

    org_users = db.session.query(User).join(OrganizationMember).filter(
        OrganizationMember.organization_id == org.id
    ).all()
    org_services = Service.query.join(User).join(OrganizationMember).filter(
        OrganizationMember.organization_id == org.id,
        Service.is_active == True
    ).all()

    return render_template('saas_dashboard.html', org=org, member=member, org_users=org_users, org_services=org_services)

@payments_bp.route('/admin/saas')
@admin_required
def admin_saas():
    orgs = Organization.query.order_by(Organization.created_at.desc()).all()
    saas_plans = SaaSPlan.query.all()
    return render_template('admin_saas.html', organizations=orgs, saas_plans=saas_plans)

@payments_bp.route('/admin/saas/plans', methods=['GET', 'POST'])
@admin_required
def admin_saas_plans():
    if request.method == 'POST':
        plan = SaaSPlan(
            name=request.form.get('name'),
            slug=request.form.get('slug'),
            description=request.form.get('description'),
            price_monthly=float(request.form.get('price_monthly', 0)),
            price_yearly=float(request.form.get('price_yearly', 0)),
            max_users=int(request.form.get('max_users', 5)),
            max_services=int(request.form.get('max_services', 50)),
            max_annonces=int(request.form.get('max_annonces', 100)),
            features=request.form.get('features', '[]'),
            display_order=int(request.form.get('display_order', 0))
        )
        db.session.add(plan)
        db.session.commit()
        flash('SaaS plan added.', 'success')
    plans = SaaSPlan.query.order_by(SaaSPlan.display_order.asc()).all()
    return render_template('admin_saas_plans.html', plans=plans)

@payments_bp.route('/api/payment/request-confirmation/<int:booking_id>', methods=['POST'])
@login_required
def api_request_payment_confirmation(booking_id):
    """Worker requests payment confirmation from client"""
    booking = Booking.query.get_or_404(booking_id)
    # Booking links to service, service links to worker
    actual_worker_id = booking.service.worker_id if booking.service else None
    if actual_worker_id != session['user_id']:
        return jsonify({'error': 'Only the worker can request payment confirmation'}), 403
    
    existing = PaymentConfirmation.query.filter_by(booking_id=booking_id).first()
    if existing:
        return jsonify({'error': 'Payment confirmation already exists for this booking'}), 400
    
    data = request.get_json() or request.form
    amount = booking.price or 0
    if data and 'amount' in data:
        try:
            amount = float(data.get('amount'))
        except (ValueError, TypeError):
            pass
    
    pc = PaymentConfirmation(
        booking_id=booking_id,
        amount=amount,
        status='pending'
    )
    db.session.add(pc)
    db.session.commit()
    
    return jsonify({'success': True, 'confirmation_id': pc.id, 'status': pc.status})

@payments_bp.route('/api/payment/confirm/<int:confirmation_id>', methods=['POST'])
@login_required
def api_confirm_payment(confirmation_id):
    """Client or worker confirms payment"""
    pc = PaymentConfirmation.query.get_or_404(confirmation_id)
    booking = Booking.query.get(pc.booking_id)
    
    if not booking:
        return jsonify({'error': 'Booking not found'}), 404
    
    data = request.get_json() or request.form
    user_type = data.get('user_type', '').lower() if hasattr(data, 'get') else data.get('user_type', '')
    notes = data.get('notes', '') if hasattr(data, 'get') else data.get('notes', '')
    
    is_worker = session['user_id'] == booking.worker_id
    is_client = session['user_id'] == booking.client_id
    
    if not is_worker and not is_client:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if is_worker:
        pc.worker_confirmed = True
        pc.worker_confirmed_at = datetime.utcnow()
        pc.worker_notes = notes
        pc.status = 'worker_confirmed'
    elif is_client:
        pc.client_confirmed = True
        pc.client_confirmed_at = datetime.utcnow()
        pc.client_notes = notes
        pc.status = 'client_confirmed'
    
    # Check if both confirmed
    if pc.worker_confirmed and pc.client_confirmed:
        pc.status = 'fully_confirmed'
        booking.status = 'completed'
        db.session.commit()
        return jsonify({'success': True, 'status': 'fully_confirmed', 'message': 'Payment fully confirmed by both parties!'})
    
    db.session.commit()
    return jsonify({
        'success': True, 
        'status': pc.status,
        'worker_confirmed': pc.worker_confirmed,
        'client_confirmed': pc.client_confirmed
    })

@payments_bp.route('/api/payment/status/<int:booking_id>')
@login_required
def api_payment_status(booking_id):
    """Get payment confirmation status"""
    pc = PaymentConfirmation.query.filter_by(booking_id=booking_id).first()
    if not pc:
        return jsonify({'exists': False})
    
    return jsonify({
        'exists': True,
        'status': pc.status,
        'amount': pc.amount,
        'worker_confirmed': pc.worker_confirmed,
        'worker_confirmed_at': pc.worker_confirmed_at.strftime('%d/%m/%Y %H:%M') if pc.worker_confirmed_at else None,
        'client_confirmed': pc.client_confirmed,
        'client_confirmed_at': pc.client_confirmed_at.strftime('%d/%m/%Y %H:%M') if pc.client_confirmed_at else None,
        'worker_notes': pc.worker_notes,
        'client_notes': pc.client_notes
    })

@payments_bp.route('/wallet')
@login_required
def wallet():
    user = User.query.get(session['user_id'])
    transactions = WalletTransaction.query.filter_by(user_id=user.id).order_by(WalletTransaction.created_at.desc()).limit(20).all()
    return render_template('wallet.html', user=user, transactions=transactions)

@payments_bp.route('/wallet/deposit', methods=['POST'])
@login_required
def wallet_deposit():
    user = User.query.get(session['user_id'])
    amount = request.form.get('amount', type=float)
    method = request.form.get('method', 'cmi')
    if not amount or amount < 10:
        flash('Montant minimum 10 MAD.', 'danger')
        return redirect(url_for('payments.wallet'))
    ref = 'WLT' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
    tx = WalletTransaction(user_id=user.id, amount=amount, type='deposit',
                           payment_method=method, reference=ref,
                           description=f'Depot via {method}', status='pending')
    db.session.add(tx)
    db.session.commit()
    flash(f'Demande de depot de {amount} MAD initiée. Reference: {ref}', 'success')
    return redirect(url_for('payments.wallet'))

@payments_bp.route('/wallet/withdraw', methods=['POST'])
@login_required
def wallet_withdraw():
    user = User.query.get(session['user_id'])
    amount = request.form.get('amount', type=float)
    method = request.form.get('method', 'inwi_money')
    if not amount or amount < 50:
        flash('Montant minimum de retrait 50 MAD.', 'danger')
        return redirect(url_for('payments.wallet'))
    if user.wallet_balance < amount:
        flash('Solde insuffisant.', 'danger')
        return redirect(url_for('payments.wallet'))
    ref = 'WDR' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
    tx = WalletTransaction(user_id=user.id, amount=-amount, type='withdrawal',
                           payment_method=method, reference=ref,
                           description=f'Retrait vers {method}', status='pending')
    user.wallet_balance -= amount
    db.session.add(tx)
    db.session.commit()
    flash(f'Retrait de {amount} MAD initie. Reference: {ref}', 'info')
    return redirect(url_for('payments.wallet'))

@payments_bp.route('/admin/wallet/confirm/<int:tx_id>', methods=['POST'])
@admin_required
def admin_confirm_wallet(tx_id):
    tx = WalletTransaction.query.get_or_404(tx_id)
    if tx.status != 'pending':
        flash('Transaction deja traitee.', 'warning')
        return redirect(url_for('admin.admin_payments'))
    tx.status = 'completed'
    tx.completed_at = datetime.utcnow()
    if tx.type == 'deposit':
        tx.user.wallet_balance += tx.amount
    db.session.commit()
    flash(f'Transaction {tx.reference} confirmee.', 'success')
    return redirect(url_for('admin.admin_payments'))

@payments_bp.route('/payment')
@login_required
def payment_page():
    payment_type = request.args.get('type', 'service')
    booking_id = request.args.get('booking_id', type=int)
    amount = request.args.get('amount', type=float)
    
    if payment_type == 'service' and booking_id:
        booking = Booking.query.get_or_404(booking_id)
        service = booking.service
        # Only client can pay
        if booking.client_id != session['user_id']:
            flash('Non autorise.', 'danger')
            return redirect(url_for('bookings.my_bookings'))
        if booking.status == 'paid':
            flash('Ce service est deja paye.', 'info')
            # Redirect to invoice if exists
            inv = Invoice.query.filter_by(booking_id=booking.id).first()
            if inv:
                return redirect(url_for('payments.invoice_detail', invoice_id=inv.id))
            return redirect(url_for('bookings.my_bookings'))
        return render_template('payment_service.html', booking=booking, service=service, amount=amount or service.price, type='service')
    
    return redirect(url_for('payments.abonnements'))

@payments_bp.route('/invoice/<int:invoice_id>')
@login_required
def invoice_detail(invoice_id):
    """View invoice detail"""
    invoice = Invoice.query.get_or_404(invoice_id)
    user = User.query.get(session['user_id'])
    # Only client, worker involved, or admin can view
    if invoice.user_id != user.id and invoice.worker_id != user.id and not user.is_admin:
        flash('Non autorise.', 'danger')
        return redirect(url_for('main.index'))
    items = json.loads(invoice.items) if invoice.items else []
    return render_template('invoice_detail.html', invoice=invoice, items=items, user=user)

@payments_bp.route('/invoice/<int:invoice_id>/pdf')
@login_required
def invoice_pdf(invoice_id):
    """Download invoice as PDF-style HTML"""
    invoice = Invoice.query.get_or_404(invoice_id)
    user = User.query.get(session['user_id'])
    if invoice.user_id != user.id and invoice.worker_id != user.id and not user.is_admin:
        flash('Non autorise.', 'danger')
        return redirect(url_for('main.index'))
    items = json.loads(invoice.items) if invoice.items else []
    return render_template('invoice_pdf.html', invoice=invoice, items=items)

