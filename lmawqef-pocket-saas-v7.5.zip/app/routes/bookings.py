from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation, check_and_award_badges
)

bookings_bp = Blueprint('bookings', __name__)


@bookings_bp.route('/book-service/<int:service_id>', methods=['POST'])
@login_required
def book_service(service_id):
    """Create a booking with payment method choice and price proposal."""
    service = Service.query.get_or_404(service_id)
    user = User.query.get(session['user_id'])
    # Check if user is a client (user_type='client' or worker_subtype='client')
    is_client = (user.user_type == 'client') or (user.worker_subtype == 'client')
    if not is_client:
        flash(_('clients_only'), 'danger')
        return redirect(url_for('services.service_detail', id=service_id))

    message = request.form.get('message', '')
    proposed_price = request.form.get('proposed_price', type=float)
    payment_method = request.form.get('payment_method', 'app')
    cash_timing = request.form.get('cash_payment_timing', 'after_service')
    insurance = request.form.get('insurance') == 'on'

    if not message:
        flash(_('message_required'), 'danger')
        return redirect(url_for('services.service_detail', id=service_id))

    # Validate proposed price
    if proposed_price and proposed_price <= 0:
        flash(_('invalid_price'), 'danger')
        return redirect(url_for('services.service_detail', id=service_id))

    # Commission calculation (based on negotiated or service price)
    base_price = proposed_price or service.price
    config = AppConfig.get()
    commission = base_price * (config.commission_rate / 100)

    booking = Booking(
        client_id=session['user_id'],
        service_id=service_id,
        message=message,
        commission_amount=commission,
        insurance_used=insurance,
        client_proposed_price=proposed_price,
        negotiated_price=proposed_price,  # Initially set to client's proposal
        payment_method=payment_method,
        cash_payment_timing=cash_timing if payment_method == 'cash' else None,
        price_negotiation_status='pending' if proposed_price else 'agreed',
        status='pending'
    )
    db.session.add(booking)
    db.session.flush()

    db.session.add(Commission(
        worker_id=service.worker_id,
        booking_id=booking.id,
        amount=commission,
        rate_percent=config.commission_rate
    ))

    # Points
    user.points += 10
    worker = User.query.get(service.worker_id)
    worker.points += 20

    # Notify worker
    price_msg = f" | Prix propose: {proposed_price} MAD" if proposed_price else ""
    notif = Notification(
        user_id=service.worker_id,
        title=_('new_booking_title'),
        message=f"{user.full_name} a reserve '{service.title}'{price_msg}. Paiement: {payment_method.upper()}",
        type='booking',
        link='/my-bookings'
    )
    db.session.add(notif)
    db.session.commit()
    check_and_award_badges(worker)

    flash(_('booking_sent'), 'success')
    return redirect(url_for('services.service_detail', id=service_id))


@bookings_bp.route('/my-bookings')
@login_required
def my_bookings():
    user = User.query.get(session['user_id'])
    if user.user_type == 'client' or user.worker_subtype in ['client']:
        bookings = Booking.query.filter_by(client_id=session['user_id']).order_by(Booking.created_at.desc()).all()
    else:
        bookings = Booking.query.join(Service).filter(Service.worker_id == session['user_id']).order_by(Booking.created_at.desc()).all()
    return render_template('my_bookings.html', bookings=bookings)


@bookings_bp.route('/booking/update/<int:id>', methods=['POST'])
@login_required
def update_booking(id):
    booking = Booking.query.get_or_404(id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])

    is_worker = service.worker_id == user.id
    is_client = booking.client_id == user.id

    if not (is_worker or is_client):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    status = request.form.get('status')

    if status == 'accepted' and is_worker:
        # Worker accepts the booking
        booking.status = 'accepted'
        booking.updated_at = datetime.utcnow()
        # If there's a price proposal from client, mark it as accepted
        if booking.client_proposed_price and booking.price_negotiation_status == 'pending':
            booking.negotiated_price = booking.client_proposed_price
            booking.price_negotiation_status = 'agreed'

        notif = Notification(
            user_id=booking.client_id,
            title=_('booking_accepted_title'),
            message=f"Votre reservation pour '{service.title}' a ete acceptee!" +
                    (f" Prix convenu: {booking.negotiated_price} MAD" if booking.negotiated_price else ""),
            type='success',
            link='/my-bookings'
        )
        db.session.add(notif)
        db.session.commit()
        flash(_('booking_accepted'), 'success')

    elif status == 'rejected' and is_worker:
        booking.status = 'rejected'
        booking.updated_at = datetime.utcnow()
        notif = Notification(
            user_id=booking.client_id,
            title=_('booking_rejected_title'),
            message=f"Votre reservation pour '{service.title}' a ete refusee.",
            type='warning',
            link='/my-bookings'
        )
        db.session.add(notif)
        db.session.commit()
        flash(_('booking_rejected'), 'info')

    elif status == 'completed' and is_worker:
        booking.status = 'completed'
        booking.updated_at = datetime.utcnow()
        commission = Commission.query.filter_by(booking_id=booking.id).first()
        if commission:
            commission.status = 'due'
        worker = User.query.get(service.worker_id)
        worker.points += 50
        check_and_award_badges(worker)

        notif = Notification(
            user_id=booking.client_id,
            title=_('booking_completed_title'),
            message=f"'{service.title}' est termine. Confirmez et payez.",
            type='success',
            link='/my-bookings'
        )
        db.session.add(notif)
        db.session.commit()
        flash(_('booking_completed'), 'success')

    return redirect(url_for('bookings.my_bookings'))


# ==================== PRICE NEGOTIATION ====================

@bookings_bp.route('/booking/<int:booking_id>/propose-price', methods=['POST'])
@login_required
def propose_price(booking_id):
    """Either client or worker proposes a new price."""
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])

    is_worker = service.worker_id == user.id
    is_client = booking.client_id == user.id

    if not (is_worker or is_client):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    new_price = request.form.get('proposed_price', type=float)
    if not new_price or new_price <= 0:
        flash(_('invalid_price'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    if is_client:
        booking.client_proposed_price = new_price
        booking.price_negotiation_status = 'pending'
        notify_user_id = service.worker_id
        actor = user.full_name
    else:
        booking.worker_proposed_price = new_price
        booking.price_negotiation_status = 'pending'
        notify_user_id = booking.client_id
        actor = user.full_name

    booking.updated_at = datetime.utcnow()

    notif = Notification(
        user_id=notify_user_id,
        title=_('price_proposed_title'),
        message=f"{actor} propose un nouveau prix pour '{service.title}': {new_price} MAD. Acceptez, refusez ou contre-proposez.",
        type='info',
        link='/my-bookings'
    )
    db.session.add(notif)
    db.session.commit()
    flash(f"Prix de {new_price} MAD propose!", 'success')
    return redirect(url_for('bookings.my_bookings'))


@bookings_bp.route('/booking/<int:booking_id>/accept-price', methods=['POST'])
@login_required
def accept_price(booking_id):
    """Accept the proposed price from the other party."""
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])

    is_worker = service.worker_id == user.id
    is_client = booking.client_id == user.id

    if not (is_worker or is_client):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    # Determine which price to accept
    if is_worker and booking.client_proposed_price:
        booking.negotiated_price = booking.client_proposed_price
        booking.price_negotiation_status = 'agreed'
        notify_user_id = booking.client_id
    elif is_client and booking.worker_proposed_price:
        booking.negotiated_price = booking.worker_proposed_price
        booking.price_negotiation_status = 'agreed'
        notify_user_id = service.worker_id
    else:
        flash("Aucun prix a accepter.", 'warning')
        return redirect(url_for('bookings.my_bookings'))

    booking.updated_at = datetime.utcnow()
    notif = Notification(
        user_id=notify_user_id,
        title=_('price_accepted_title'),
        message=f"Prix de {booking.negotiated_price} MAD accepte pour '{service.title}'!",
        type='success',
        link='/my-bookings'
    )
    db.session.add(notif)
    db.session.commit()
    flash(f"Prix de {booking.negotiated_price} MAD accepte!", 'success')
    return redirect(url_for('bookings.my_bookings'))


@bookings_bp.route('/booking/<int:booking_id>/reject-price', methods=['POST'])
@login_required
def reject_price(booking_id):
    """Reject the proposed price and optionally provide a counter-offer."""
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])

    is_worker = service.worker_id == user.id
    is_client = booking.client_id == user.id

    if not (is_worker or is_client):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    booking.price_negotiation_status = 'rejected'
    notify_user_id = booking.client_id if is_worker else service.worker_id

    notif = Notification(
        user_id=notify_user_id,
        title=_('price_rejected_title'),
        message=f"Votre proposition de prix pour '{service.title}' a ete refusee. Faites une nouvelle offre.",
        type='warning',
        link='/my-bookings'
    )
    db.session.add(notif)
    db.session.commit()
    flash("Proposition refusee. Vous pouvez faire une contre-offre.", 'info')
    return redirect(url_for('bookings.my_bookings'))


# ==================== ESCROW & PAYMENT ====================

@bookings_bp.route('/booking/<int:booking_id>/pay-escrow', methods=['POST'])
@login_required
def pay_escrow(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    client = User.query.get(session['user_id'])
    if booking.client_id != client.id:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    service = Service.query.get(booking.service_id)
    amount = request.form.get('amount', type=float) or booking.negotiated_price or service.price

    if client.wallet_balance >= amount:
        client.wallet_balance -= amount
        booking.escrow_status = 'held'
        booking.payment_status = 'paid'
        booking.status = 'confirmed'

        payment = Payment(
            user_id=client.id, amount=amount, type='escrow',
            reference='ESC' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)),
            description=f"Acompte pour {service.title}",
            status='completed', is_escrow=True, escrow_status='held',
            booking_id=booking.id
        )
        db.session.add(payment)

        notif = Notification(
            user_id=service.worker_id,
            title='Acompte recu',
            message=f"Acompte de {amount} MAD bloque pour '{service.title}'.",
            type='success',
            link='/my-bookings'
        )
        db.session.add(notif)
        db.session.commit()
        flash(f"Acompte de {amount} MAD bloque avec succes.", 'success')
    else:
        flash(_('insufficient_balance'), 'warning')
        return redirect(url_for('payments.wallet'))
    return redirect(url_for('bookings.my_bookings'))


@bookings_bp.route('/booking/<int:booking_id>/release-escrow', methods=['POST'])
@login_required
def release_escrow(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    client = User.query.get(session['user_id'])
    if booking.client_id != client.id:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if booking.escrow_status != 'held':
        flash("Aucun acompte a liberer.", 'warning')
        return redirect(url_for('bookings.my_bookings'))

    payment = Payment.query.filter_by(booking_id=booking.id, is_escrow=True).first()
    service = Service.query.get(booking.service_id)
    if payment:
        payment.escrow_status = 'released'
        payment.released_at = datetime.utcnow()
        worker = User.query.get(service.worker_id)
        if worker:
            worker.wallet_balance += payment.amount
            db.session.add(WalletTransaction(
                user_id=worker.id, amount=payment.amount, type='payment',
                reference=payment.reference, status='completed',
                description=f"Paiement pour {service.title}"
            ))
    booking.escrow_status = 'released'
    booking.client_confirmed = True
    booking.confirmed_at = datetime.utcnow()
    db.session.commit()
    flash("Paiement libere. Le prestataire a recu son argent.", 'success')
    return redirect(url_for('bookings.my_bookings'))


@bookings_bp.route('/booking/<int:booking_id>/confirm-completion', methods=['POST'])
@login_required
def confirm_completion(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    user = User.query.get(session['user_id'])
    service = Service.query.get(booking.service_id)
    is_client = booking.client_id == user.id
    is_worker = service.worker_id == user.id

    if not (is_client or is_worker):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    if is_client:
        booking.client_confirmed = True
    if is_worker:
        booking.worker_confirmed = True

    # For cash payments with after_service timing, just mark confirmed
    if booking.payment_method == 'cash' and booking.cash_payment_timing == 'after_service':
        booking.payment_status = 'pending'  # Will be paid physically
        booking.status = 'completed'
        db.session.commit()
        flash("Service confirme. Le paiement en especes est attendu.", 'success')
        return redirect(url_for('bookings.my_bookings'))

    # For escrow, release if both confirmed
    if booking.client_confirmed and booking.worker_confirmed and booking.escrow_status == 'held':
        return redirect(url_for('bookings.release_escrow', booking_id=booking.id))

    db.session.commit()
    flash("Intervention confirmee. En attente de l'autre partie.", 'success')
    return redirect(url_for('bookings.my_bookings'))


@bookings_bp.route('/booking/<int:booking_id>/pay-cash', methods=['POST'])
@login_required
def pay_cash(booking_id):
    """Mark a cash payment as completed (after physical payment)."""
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])

    is_client = booking.client_id == user.id
    is_worker = service.worker_id == user.id

    if not (is_client or is_worker):
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))

    booking.payment_status = 'paid'
    booking.status = 'completed'
    db.session.commit()

    notif = Notification(
        user_id=service.worker_id if is_client else booking.client_id,
        title='Paiement en especes confirme',
        message=f"Paiement en especes de {booking.negotiated_price or service.price} MAD confirme pour '{service.title}'.",
        type='success',
        link='/my-bookings'
    )
    db.session.add(notif)
    db.session.commit()
    flash("Paiement en especes confirme!", 'success')
    return redirect(url_for('bookings.my_bookings'))


# ==================== GPS & PHOTOS ====================

@bookings_bp.route('/booking/<int:booking_id>/track-worker')
@login_required
def track_worker_location(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])
    if booking.client_id != user.id and service.worker_id != user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    worker = User.query.get(service.worker_id)
    if not worker or not worker.is_tracking_enabled:
        return jsonify({'error': 'Worker not sharing location'}), 404
    return jsonify({
        'latitude': worker.last_latitude, 'longitude': worker.last_longitude,
        'last_update': worker.last_location_update.strftime('%H:%M:%S') if worker.last_location_update else None,
        'worker_name': worker.full_name, 'is_tracking': worker.is_tracking_enabled
    })


@bookings_bp.route('/booking/<int:booking_id>/upload-progress', methods=['POST'])
@login_required
def upload_progress_photos(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    service = Service.query.get(booking.service_id)
    user = User.query.get(session['user_id'])
    if service.worker_id != user.id:
        flash('Seul le prestataire peut uploader.', 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if 'before_photo' in request.files:
        f = request.files['before_photo']
        if f and f.filename:
            path = save_uploaded_file(f, 'services')
            if path:
                booking.before_photo = path
    if 'after_photo' in request.files:
        f = request.files['after_photo']
        if f and f.filename:
            path = save_uploaded_file(f, 'services')
            if path:
                booking.after_photo = path
    db.session.commit()
    flash('Photos uploadées.', 'success')
    return redirect(url_for('bookings.my_bookings'))
