from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

annonces_bp = Blueprint('annonces', __name__)

@annonces_bp.route('/annonces')
def annonces():
    page = request.args.get('page', 1, type=int)
    type_filter = request.args.get('type', '')
    category = request.args.get('category', '')
    city = request.args.get('city', '')
    query = Annonce.query.filter_by(is_active=True)
    query = query.filter(db.or_(Annonce.expires_at == None, Annonce.expires_at > datetime.utcnow()))
    if type_filter: query = query.filter_by(type=type_filter)
    if category: query = query.filter_by(category=category)
    if city: query = query.filter_by(city=city)
    annonces = query.order_by(Annonce.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('annonces.html', annonces=annonces, type_filter=type_filter,
                         category=category, city=city, cities=MOROCCAN_CITIES, categories=CATEGORIES)

@annonces_bp.route('/annonce/<int:id>')
def annonce_detail(id):
    annonce = Annonce.query.get_or_404(id)
    annonce.views_count += 1
    db.session.commit()
    # Get author profile with full details
    author = User.query.get(annonce.author_id)
    author_services = Service.query.filter_by(worker_id=annonce.author_id, is_active=True).limit(6).all()
    author_reviews = Review.query.filter_by(worker_id=annonce.author_id).order_by(Review.created_at.desc()).limit(5).all()
    # Get completed jobs via service_id (booking has no worker_id, it has service_id)
    author_service_ids = [s.id for s in Service.query.filter_by(worker_id=annonce.author_id).all()]
    author_completed_jobs = Booking.query.filter(Booking.service_id.in_(author_service_ids), Booking.status=='completed').count() if author_service_ids else 0
    author_stats = {
        'services_count': len(author_services),
        'reviews_count': len(author_reviews),
        'completed_jobs': author_completed_jobs,
        'rating': author.average_rating() if hasattr(author, 'average_rating') else 0,
        'member_since': author.created_at.strftime('%B %Y') if author.created_at else 'N/A'
    }
    # Get offers for this annonce
    offers = AnnonceOffer.query.filter_by(annonce_id=id).order_by(AnnonceOffer.created_at.desc()).all()
    has_applied = False
    my_offer = None
    if 'user_id' in session:
        my_offer = AnnonceOffer.query.filter_by(annonce_id=id, worker_id=session['user_id']).first()
        has_applied = my_offer is not None
    accepted_offer = AnnonceOffer.query.filter_by(annonce_id=id, status='accepted').first()
    return render_template('annonce_detail.html', annonce=annonce, author=author,
                         author_services=author_services, author_reviews=author_reviews,
                         author_stats=author_stats, offers=offers, has_applied=has_applied,
                         my_offer=my_offer, accepted_offer=accepted_offer,
                         cities=MOROCCAN_CITIES, categories=CATEGORIES)

@annonces_bp.route('/annonce/<int:id>/apply', methods=['POST'])
@login_required
def apply_to_annonce(id):
    worker = User.query.get(session['user_id'])
    if worker.user_type not in ['worker', 'entreprise']:
        flash('Seuls les prestataires peuvent postuler.', 'danger')
        return redirect(url_for('annonces.annonce_detail', id=id))
    annonce = Annonce.query.get_or_404(id)
    # Check if already applied
    existing = AnnonceOffer.query.filter_by(annonce_id=id, worker_id=worker.id).first()
    if existing:
        flash('Vous avez déjà postulé à cette annonce.', 'warning')
        return redirect(url_for('annonces.annonce_detail', id=id))
    message = request.form.get('message', '')
    price = request.form.get('proposed_price')
    days = request.form.get('estimated_days')
    offer = AnnonceOffer(
        annonce_id=id,
        worker_id=worker.id,
        message=message,
        proposed_price=float(price) if price else None,
        estimated_days=int(days) if days else None
    )
    db.session.add(offer)
    # Notify the annonce author
    db.session.add(Notification(
        user_id=annonce.author_id,
        title=f'Nouvelle offre sur "{annonce.title[:30]}..."',
        message=f'{worker.full_name} a proposé ses services pour votre annonce. Cliquez pour voir les détails.',
        type='offer_received',
        link=f'/annonce/{annonce.id}'
    ))
    db.session.commit()
    flash('Votre candidature a été envoyée !', 'success')
    return redirect(url_for('annonces.annonce_detail', id=id))

@annonces_bp.route('/annonce/<int:id>/offers')
@login_required
def get_annonce_offers(id):
    annonce = Annonce.query.get_or_404(id)
    if annonce.author_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403
    offers = AnnonceOffer.query.filter_by(annonce_id=id).order_by(AnnonceOffer.created_at.desc()).all()
    data = []
    for o in offers:
        w = o.worker
        data.append({
            'id': o.id,
            'worker_id': w.id,
            'worker_name': w.full_name,
            'worker_avatar': w.avatar,
            'worker_rating': w.average_rating() if hasattr(w, 'average_rating') else 0,
            'worker_city': w.city,
            'worker_profession': w.profession_title or w.skills or 'Prestataire',
            'message': o.message,
            'proposed_price': o.proposed_price,
            'estimated_days': o.estimated_days,
            'status': o.status,
            'created_at': o.created_at.strftime('%d %b %Y %H:%M')
        })
    return jsonify({'offers': data, 'annonce_title': annonce.title})

@annonces_bp.route('/annonce/add', methods=['GET', 'POST'])
@login_required
def add_annonce():
    user = User.query.get(session['user_id'])
    config = AppConfig.get()
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        type_a = request.form.get('type')
        category = request.form.get('category')
        city = request.form.get('city')
        price = request.form.get('price')
        if not all([title, description, type_a]):
            flash('Required fields missing.', 'danger')
            return redirect(url_for('annonces.add_annonce'))
        can_free = user.can_post_free_announce()
        can_monthly = user.can_post_monthly_announce()
        price_float = float(price) if price else None
        announce_price = user.get_announce_price()
        needs_payment = announce_price > 0 and not can_free and not can_monthly
        annonce = Annonce(
            author_id=user.id, title=title, description=description, type=type_a,
            category=category, city=city, price=price_float,
            expires_at=datetime.utcnow() + timedelta(days=config.annonce_duration_days)
        )
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'annonces')
                if img_path: annonce.image = img_path
        if not needs_payment:
            annonce.is_paid = True
            if can_free: user.free_announces_used += 1
            elif can_monthly: user.announces_month_used += 1
        db.session.add(annonce)
        db.session.flush()
        if needs_payment:
            db.session.commit()
            return redirect(url_for('payment_annonce', annonce_id=annonce.id))
        db.session.commit()
        user.points += 5
        check_and_award_badges(user)
        # Notify workers matching category and city
        if category and city:
            matched_workers = User.query.filter(
                User.user_type.in_(['worker', 'entreprise']),
                User.is_active == True,
                User.city == city,
                db.or_(User.skills.contains(category), User.profession_title.contains(category))
            ).all()
            for w in matched_workers:
                if w.id != user.id:
                    db.session.add(Notification(
                        user_id=w.id,
                        title=f'Nouvelle annonce : {title[:40]}...',
                        message=f'Une annonce dans votre domaine ({category}) a été publiée à {city}. Budget: {price_float or "Non précisé"} MAD.',
                        type='annonce_alert',
                        link=f'/annonce/{annonce.id}'
                    ))
            db.session.commit()
        flash('Annonce published!', 'success')
        return redirect(url_for('annonces.annonces'))
    return render_template('add_annonce.html', user=user, config=config, cities=MOROCCAN_CITIES, categories=CATEGORIES)

@annonces_bp.route('/payment/annonce/<int:annonce_id>')
@login_required
def payment_annonce(annonce_id):
    annonce = Annonce.query.get_or_404(annonce_id)
    if annonce.author_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('annonces.annonces'))
    config = AppConfig.get()
    return render_template('payment.html', annonce=annonce, amount=config.annonce_price, type='annonce')

@annonces_bp.route('/admin/annonces')
@admin_required
def admin_annonces():
    page = request.args.get('page', 1, type=int)
    annonces = Annonce.query.order_by(Annonce.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_annonces.html', annonces=annonces)

@annonces_bp.route('/admin/annonces/delete/<int:id>', methods=['POST'])
@admin_required
def admin_delete_annonce(id):
    annonce = Annonce.query.get_or_404(id)
    db.session.delete(annonce)
    db.session.commit()
    flash('Deleted.', 'success')
    return redirect(url_for('admin.admin_annonces'))

