from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

api_bp = Blueprint('api', __name__)

@api_bp.route('/set-language', methods=['POST'])
def set_language_route():
    from app.utils.translations import set_language
    lang = request.form.get('lang', 'fr')
    set_language(lang)
    session['visited'] = True
    return redirect(request.referrer or url_for('main.index'))


@api_bp.route('/review/<int:worker_id>', methods=['POST'])
@login_required
def add_review(worker_id):
    user = User.query.get(session['user_id'])
    if user.user_type != 'client':
        flash('Only clients.', 'danger')
        return redirect(url_for('workers.profile', id=worker_id))
    rating = request.form.get('rating', type=int)
    comment = request.form.get('comment')
    if not rating or not comment or rating < 1 or rating > 5:
        flash('Valid rating required.', 'danger')
        return redirect(url_for('workers.profile', id=worker_id))
    has_booked = Booking.query.join(Service).filter(Booking.client_id == session['user_id'],
                                                    Service.worker_id == worker_id).first()
    if not has_booked:
        flash('Book first.', 'danger')
        return redirect(url_for('workers.profile', id=worker_id))
    existing = Review.query.filter_by(client_id=session['user_id'], worker_id=worker_id).first()
    if existing:
        flash('Already reviewed.', 'danger')
        return redirect(url_for('workers.profile', id=worker_id))
    review = Review(rating=rating, comment=comment, client_id=session['user_id'], worker_id=worker_id)
    db.session.add(review)
    worker = User.query.get(worker_id)
    worker.points += 30
    notif = Notification(user_id=worker_id, title='Nouvel avis',
                        message=f'{user.full_name}: {rating} etoiles', type='success',
                        link=f'/profile/{worker_id}')
    db.session.add(notif)
    db.session.commit()
    check_and_award_badges(worker)
    flash('Review added!', 'success')
    return redirect(url_for('workers.profile', id=worker_id))

@api_bp.route('/portfolio/delete/<int:id>', methods=['POST'])
@login_required
def delete_portfolio(id):
    item = PortfolioItem.query.get_or_404(id)
    if item.user_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('workers.my_profile'))
    db.session.delete(item)
    db.session.commit()
    flash('Removed.', 'success')
    return redirect(url_for('workers.my_profile'))

@api_bp.route('/dashboard/entreprise')
@login_required
def dashboard_entreprise():
    user = User.query.get(session['user_id'])
    if user.user_type != 'entreprise':
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
    total_services = Service.query.filter_by(worker_id=user.id).count()
    total_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
    pending_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id, Booking.status == 'pending').count()
    avg_rating = user.average_rating()
    recent_bookings = Booking.query.join(Service).filter(Service.worker_id == user.id).order_by(Booking.created_at.desc()).limit(5).all()
    subscription = user.subscription_plan if user.has_active_subscription() else None
    badges = user.get_badges_list()
    level = user.get_level()
    stats = {'total_services': total_services, 'total_bookings': total_bookings,
             'pending_bookings': pending_bookings, 'avg_rating': avg_rating, 'total_reviews': user.review_count()}
    return render_template('dashboard_entreprise.html', stats=stats, recent_bookings=recent_bookings,
                         subscription=subscription, user=user, badges=badges, level=level)

@api_bp.route('/notification/delete/<int:id>', methods=['POST'])
@login_required
def delete_notification(id):
    notif = Notification.query.get_or_404(id)
    if notif.user_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('messages.notifications'))
    db.session.delete(notif)
    db.session.commit()
    flash('Deleted.', 'success')
    return redirect(url_for('messages.notifications'))

@api_bp.route('/devis/create', methods=['GET', 'POST'])
@login_required
def create_devis():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers.', 'danger')
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        client_name = request.form.get('client_name')
        client_email = request.form.get('client_email')
        title = request.form.get('title')
        description = request.form.get('description')
        items_json = request.form.get('items')
        total_ht = float(request.form.get('total_ht', 0))
        tva_rate = float(request.form.get('tva_rate', 20))
        total_ttc = total_ht * (1 + tva_rate / 100)
        valid_days = int(request.form.get('valid_days', 30))
        devis = Devis(
            worker_id=user.id, client_name=client_name, client_email=client_email,
            title=title, description=description, items=items_json,
            total_ht=total_ht, tva_rate=tva_rate, total_ttc=total_ttc,
            valid_until=datetime.utcnow() + timedelta(days=valid_days)
        )
        db.session.add(devis)
        db.session.commit()
        flash('Devis created!', 'success')
        return redirect(url_for('payments.my_devis'))
    return render_template('create_devis.html')

@api_bp.route('/my-devis')
@login_required
def my_devis():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers.', 'danger')
        return redirect(url_for('main.index'))
    devis_list = Devis.query.filter_by(worker_id=user.id).order_by(Devis.created_at.desc()).all()
    return render_template('my_devis.html', devis_list=devis_list)

@api_bp.route('/devis/<int:id>/pdf')
@login_required
def devis_pdf(id):
    devis = Devis.query.get_or_404(id)
    if devis.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('payments.my_devis'))
    items = json.loads(devis.items) if devis.items else []
    return render_template('devis_pdf.html', devis=devis, items=items)

@api_bp.route('/offer/<int:offer_id>/accept', methods=['POST'])
@login_required
def accept_offer(offer_id):
    offer = AnnonceOffer.query.get_or_404(offer_id)
    annonce = offer.annonce
    if annonce.author_id != session['user_id']:
        flash('Permission refusée.', 'danger')
        return redirect(url_for('annonces.annonce_detail', id=annonce.id))
    offer.status = 'accepted'
    # Reject other offers
    AnnonceOffer.query.filter(AnnonceOffer.annonce_id == annonce.id, AnnonceOffer.id != offer.id).update({'status': 'rejected'})
    # Notify worker
    db.session.add(Notification(
        user_id=offer.worker_id,
        title='Votre offre a été acceptée !',
        message=f'Félicitations ! Le client a accepté votre offre pour "{annonce.title}". Contactez-le pour commencer.',
        type='offer_accepted',
        link=f'/annonce/{annonce.id}'
    ))
    db.session.commit()
    flash('Offre acceptée ! Le prestataire va vous contacter.', 'success')
    return redirect(url_for('annonces.annonce_detail', id=annonce.id))

@api_bp.route('/offer/<int:offer_id>/reject', methods=['POST'])
@login_required
def reject_offer(offer_id):
    offer = AnnonceOffer.query.get_or_404(offer_id)
    annonce = offer.annonce
    if annonce.author_id != session['user_id']:
        flash('Permission refusée.', 'danger')
        return redirect(url_for('annonces.annonce_detail', id=annonce.id))
    offer.status = 'rejected'
    db.session.add(Notification(
        user_id=offer.worker_id,
        title='Votre offre a été déclinée',
        message=f'Votre offre pour "{annonce.title}" n\'a pas été retenue cette fois.',
        type='offer_rejected'
    ))
    db.session.commit()
    flash('Offre rejetée.', 'info')
    return redirect(url_for('annonces.annonce_detail', id=annonce.id))

@api_bp.route('/insurance')
@login_required
def insurance_page():
    user = User.query.get(session['user_id'])
    config = AppConfig.get()
    return render_template('insurance.html', config=config, user=user)

@api_bp.route('/urgent-services')
def urgent_services():
    services = Service.query.filter_by(is_urgent=True, is_active=True).order_by(Service.created_at.desc()).all()
    config = AppConfig.query.first()
    if not config:
        config = AppConfig()
    return render_template('urgent_services.html', services=services, config=config)

@api_bp.route('/availability', methods=['GET', 'POST'])
@login_required
def manage_availability():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise']:
        flash('Only workers.', 'danger')
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        Availability.query.filter_by(user_id=user.id).delete()
        for i in range(7):
            start = request.form.get(f'start_{i}')
            end = request.form.get(f'end_{i}')
            avail = request.form.get(f'available_{i}') == 'on'
            if start and end:
                db.session.add(Availability(user_id=user.id, day_of_week=i, start_time=start, end_time=end, is_available=avail))
        db.session.commit()
        flash('Availability updated!', 'success')
        return redirect(url_for('workers.manage_availability'))
    availability = Availability.query.filter_by(user_id=user.id).all()
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    return render_template('availability.html', availability=availability, days=days)

@api_bp.route('/api/chatbot', methods=['POST'])
def chatbot_api():
    data = request.get_json()
    message = data.get('message', '').lower()
    responses = {
        'bonjour': 'Bonjour! Comment puis-je vous aider aujourd\'hui?',
        'hello': 'Hello! How can I help you today?',
        'salam': 'Wa alaykoum salam! Comment puis-je vous aider?',
        'service': 'Vous pouvez rechercher des services par categorie, ville ou mot-cle. Utilisez la barre de recherche en haut!',
        'prix': 'Les prix varient selon le service. Chaque worker fixe ses propres tarifs.',
        'paiement': 'Nous acceptons les cartes bancaires (CMI), le paiement mobile (Inwi Money, Orange Money) et le virement bancaire.',
        'abonnement': 'Nos abonnements PRO offrent des annonces illimitees, profil prioritaire et plus de visibilite. Consultez la page Abonnements!',
        'annonce': 'Pour publier une annonce, cliquez sur "Publier une Annonce". La premiere est gratuite, les suivantes coutent 20 MAD.',
        'comment': 'Inscrivez-vous, choisissez votre type de compte (client ou worker), et commencez a utiliser la plateforme!',
        'urgence': 'Pour les services urgents, activez le mode Urgence lors de la creation du service. Le prix sera majore mais vous trouverez un worker plus rapidement.',
    }
    for key, response in responses.items():
        if key in message:
            return jsonify({'response': response, 'success': True})
    return jsonify({'response': 'Je ne comprends pas encore cette question. Essayez: prix, abonnement, comment s\'inscrire ou contactez notre support.', 'success': True})

@api_bp.route('/categories')
def categories_page():
    category_counts = {}
    for cat in CATEGORIES:
        category_counts[cat] = Service.query.filter_by(category=cat, is_active=True).count()
    return render_template('categories.html', category_counts=category_counts)

@api_bp.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@api_bp.route('/api/search')
def api_search():
    q = request.args.get('q', '')
    if not q or len(q) < 2:
        return jsonify({'services': [], 'workers': []})
    services = Service.query.filter(
        db.or_(Service.title.contains(q), Service.description.contains(q)),
        Service.is_active == True
    ).limit(5).all()
    workers = User.query.filter(
        db.or_(User.full_name.contains(q), User.skills.contains(q)),
        User.user_type.in_(['worker', 'entreprise'])
    ).limit(5).all()
    return jsonify({
        'services': [{'id': s.id, 'title': s.title, 'price': s.price, 'city': s.city} for s in services],
        'workers': [{'id': w.id, 'name': w.full_name, 'city': w.city, 'rating': w.average_rating()} for w in workers]
    })

@api_bp.route('/api/ai-match/score')
def api_ai_match_score():
    worker_id = request.args.get('worker_id', type=int)
    category_id = request.args.get('category_id', type=int)
    city = request.args.get('city', '')
    if not worker_id:
        return jsonify({'error': 'worker_id required'}), 400
    worker = User.query.get_or_404(worker_id)
    score, factors = calculate_match_score(None, worker, category_id, city)
    return jsonify({'score': score, 'factors': factors})

@api_bp.route('/video-call/<int:booking_id>')
@login_required
def video_call(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.client_id != session['user_id'] and booking.worker_id != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('bookings.my_bookings'))

    room = VideoCallRoom.query.filter_by(booking_id=booking_id).first()
    if not room:
        room_id = 'lmawqef-' + generate_reference().lower()
        room = VideoCallRoom(booking_id=booking_id, room_id=room_id, provider='jitsi')
        db.session.add(room)
        db.session.commit()

    return render_template('video_call.html', booking=booking, room=room)

@api_bp.route('/api/video-call/<int:booking_id>/start', methods=['POST'])
@login_required
def start_video_call(booking_id):
    room = VideoCallRoom.query.filter_by(booking_id=booking_id).first()
    if room:
        room.started_at = datetime.utcnow()
        room.status = 'active'
        db.session.commit()
    return jsonify({'success': True, 'room_id': room.room_id if room else None})

@api_bp.route('/api/video-call/<int:booking_id>/end', methods=['POST'])
@login_required
def end_video_call(booking_id):
    room = VideoCallRoom.query.filter_by(booking_id=booking_id).first()
    if room and room.started_at:
        room.ended_at = datetime.utcnow()
        room.duration_seconds = int((room.ended_at - room.started_at).total_seconds())
        room.status = 'ended'
        db.session.commit()
    return jsonify({'success': True, 'duration': room.duration_seconds if room else 0})

@api_bp.route('/whatsapp/send', methods=['POST'])
@login_required
def whatsapp_send():
    phone = request.form.get('phone')
    template = request.form.get('template', 'booking_confirmation')
    if not phone:
        return jsonify({'error': 'Phone required'}), 400
    result = send_whatsapp_message(phone, template)
    return jsonify(result)

@api_bp.route('/qr-check/<code>')
def qr_check(code):
    qr = QRCodeCheck.query.filter_by(code=code).first()
    if not qr or not qr.is_valid:
        flash('Invalid or expired QR code.', 'danger')
        return redirect(url_for('main.index'))

    booking = Booking.query.get(qr.booking_id)
    if not booking:
        flash('Booking not found.', 'danger')
        return redirect(url_for('main.index'))

    if qr.status == 'checked_in':
        flash('Already checked in!', 'info')
    else:
        qr.status = 'checked_in'
        qr.checked_in_at = datetime.utcnow()
        db.session.commit()
        flash('Check-in successful!', 'success')

    return render_template('qr_check.html', qr=qr, booking=booking)

@api_bp.route('/qr-check/generate/<int:booking_id>')
@login_required
def generate_qr_check(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.client_id != session['user_id'] and booking.worker_id != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('bookings.my_bookings'))

    # Invalidate old QR codes for this booking
    QRCodeCheck.query.filter_by(booking_id=booking_id).update({'is_valid': False})

    code = generate_reference() + '-' + str(booking_id)
    qr_data = url_for('qr_check', code=code, _external=True)
    qr_b64 = generate_qr_code(qr_data)

    qr = QRCodeCheck(
        booking_id=booking_id,
        code=code,
        qr_image_url='data:image/png;base64,' + qr_b64,
        is_valid=True
    )
    db.session.add(qr)
    db.session.commit()

    return render_template('qr_check.html', qr=qr, booking=booking, generated=True)

@api_bp.route('/ramadan-toggle', methods=['POST'])
@admin_required
def ramadan_toggle():
    config = get_ramadan_config()
    config.is_active = not config.is_active
    db.session.commit()
    flash(f'Ramadan mode {"activated" if config.is_active else "deactivated"}.', 'success')
    return redirect(url_for('admin.admin_config'))

@api_bp.route('/api/maps/geocode')
def maps_geocode():
    address = request.args.get('address', '')
    if not address:
        return jsonify({'error': 'Address required'}), 400

    # In production, call Google Maps Geocoding API
    # For demo, return mock data or use lat/lng from user profiles
    users = User.query.filter(
        db.or_(User.city.contains(address), User.address.contains(address))
    ).all()

    results = []
    for u in users:
        if u.latitude and u.longitude:
            results.append({
                'id': u.id,
                'name': u.full_name,
                'lat': u.latitude,
                'lng': u.longitude,
                'city': u.city,
                'type': u.user_type
            })

    return jsonify({'results': results})

@api_bp.route('/api/maps/nearby-workers')
def maps_nearby_workers():
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    radius = request.args.get('radius', 10, type=float)  # km
    category_id = request.args.get('category_id', type=int)

    if not lat or not lng:
        return jsonify({'error': 'lat and lng required'}), 400

    # Simple distance filter using Haversine formula
    workers = User.query.filter(
        User.user_type.in_(['worker', 'entreprise', 'auto_entrepreneur', 'freelance']),
        User.is_active == True,
        User.latitude != None,
        User.longitude != None
    ).all()

    from math import radians, sin, cos, sqrt, atan2
    def haversine(lat1, lng1, lat2, lng2):
        R = 6371
        dlat = radians(lat2 - lat1)
        dlng = radians(lng2 - lng1)
        a = sin(dlat/2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlng/2)**2
        return 2 * R * atan2(sqrt(a), sqrt(1-a))

    results = []
    for w in workers:
        dist = haversine(lat, lng, w.latitude, w.longitude)
        if dist <= radius:
            services = Service.query.filter_by(worker_id=w.id, is_active=True)
            if category_id:
                services = services.filter_by(category_id=category_id)
            svc_count = services.count()
            results.append({
                'id': w.id,
                'name': w.full_name,
                'lat': w.latitude,
                'lng': w.longitude,
                'distance_km': round(dist, 2),
                'rating': w.average_rating(),
                'services_count': svc_count
            })

    results.sort(key=lambda x: x['distance_km'])
    return jsonify({'results': results, 'center': {'lat': lat, 'lng': lng}})

@api_bp.route('/api/analytics/dashboard')
@login_required
def api_analytics_dashboard():
    user_id = session['user_id']
    user = User.query.get(user_id)

    # Monthly bookings data for Chart.js
    months = []
    bookings_data = []
    revenue_data = []

    for i in range(6):
        month_date = datetime.utcnow() - timedelta(days=30*i)
        month_name = month_date.strftime('%b %Y')
        months.insert(0, month_name)

        start = month_date.replace(day=1, hour=0, minute=0, second=0)
        if i > 0:
            end = (start + timedelta(days=32)).replace(day=1)
        else:
            end = datetime.utcnow()

        if user.user_type in ['worker', 'entreprise'] or user.worker_subtype in ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']:
            worker_service_ids = [s.id for s in Service.query.filter_by(worker_id=user_id).all()]
            count = Booking.query.filter(
                Booking.service_id.in_(worker_service_ids) if worker_service_ids else False,
                Booking.created_at >= start,
                Booking.created_at < end
            ).count()
            # Join with Service to get price since Booking has no price column
            from sqlalchemy import join
            revenue = db.session.query(db.func.sum(Service.price)).select_from(Booking).join(
                Service, Booking.service_id == Service.id
            ).filter(
                Booking.service_id.in_(worker_service_ids) if worker_service_ids else False,
                Booking.status == 'completed',
                Booking.created_at >= start,
                Booking.created_at < end
            ).scalar() or 0
        else:
            count = Booking.query.filter(
                Booking.client_id == user_id,
                Booking.created_at >= start,
                Booking.created_at < end
            ).count()
            revenue = 0

        bookings_data.insert(0, count)
        revenue_data.insert(0, round(float(revenue), 2))

    # Rating distribution
    if user.user_type in ['worker', 'entreprise'] or user.worker_subtype in ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']:
        reviews = Review.query.filter_by(worker_id=user_id).all()
    else:
        reviews = []

    rating_dist = {1:0, 2:0, 3:0, 4:0, 5:0}
    for r in reviews:
        rating_dist[r.rating] = rating_dist.get(r.rating, 0) + 1

    return jsonify({
        'months': months,
        'bookings': bookings_data,
        'revenue': revenue_data,
        'rating_distribution': list(rating_dist.values()),
        'total_views': Service.query.filter_by(worker_id=user_id).with_entities(db.func.sum(Service.views_count)).scalar() or 0 if (user.user_type in ['worker', 'entreprise'] or user.worker_subtype in ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']) else 0,
        'conversion_rate': round(len(reviews) / max(len(bookings_data), 1) * 100, 1)
    })

@api_bp.route('/oauth/google')
def oauth_google():
    """Initiate Google OAuth2 flow"""
    google_cfg = get_google_provider_cfg()
    if not google_cfg:
        flash('Unable to connect to Google. Please try again.', 'danger')
        return redirect(url_for('auth.login'))
    
    client_id = app.config.get('GOOGLE_CLIENT_ID', '')
    if not client_id:
        flash('Google OAuth is not configured.', 'danger')
        return redirect(url_for('auth.login'))
    
    authorization_endpoint = google_cfg['authorization_endpoint']
    from werkzeug.security import gen_salt
    state = gen_salt(32)
    session['oauth_state'] = state
    
    import urllib.parse
    redirect_uri = url_for('oauth_google_callback', _external=True)
    qs = urllib.parse.urlencode({
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'openid email profile',
        'state': state,
        'prompt': 'select_account'
    })
    return redirect(f"{authorization_endpoint}?{qs}")

@api_bp.route('/oauth/google/callback')
def oauth_google_callback():
    """Handle Google OAuth2 callback"""
    if 'error' in request.args:
        flash(f'OAuth error: {request.args.get("error_description", "Unknown error")}', 'danger')
        return redirect(url_for('auth.login'))
    
    code = request.args.get('code')
    state = request.args.get('state')
    stored_state = session.pop('oauth_state', None)
    
    if not code or state != stored_state:
        flash('Invalid OAuth state. Please try again.', 'danger')
        return redirect(url_for('auth.login'))
    
    google_cfg = get_google_provider_cfg()
    token_endpoint = google_cfg['token_endpoint']
    client_id = app.config.get('GOOGLE_CLIENT_ID', '')
    client_secret = app.config.get('GOOGLE_CLIENT_SECRET', '')
    redirect_uri = url_for('oauth_google_callback', _external=True)
    
    # Exchange code for token
    import urllib.parse
    token_data = urllib.parse.urlencode({
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri,
        'client_id': client_id,
        'client_secret': client_secret,
    }).encode('utf-8')
    
    req = urllib.request.Request(token_endpoint, data=token_data, 
                                  headers={'Content-Type': 'application/x-www-form-urlencoded'})
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    
    try:
        with urllib.request.urlopen(req, context=context, timeout=10) as response:
            token_json = json.loads(response.read().decode('utf-8'))
    except Exception as e:
        flash('Failed to authenticate with Google.', 'danger')
        return redirect(url_for('auth.login'))
    
    access_token = token_json.get('access_token')
    if not access_token:
        flash('Failed to get access token from Google.', 'danger')
        return redirect(url_for('auth.login'))
    
    # Get user info
    userinfo_endpoint = google_cfg['userinfo_endpoint']
    req = urllib.request.Request(userinfo_endpoint, 
                                  headers={'Authorization': f'Bearer {access_token}'})
    try:
        with urllib.request.urlopen(req, context=context, timeout=10) as response:
            userinfo = json.loads(response.read().decode('utf-8'))
    except Exception:
        flash('Failed to get user info from Google.', 'danger')
        return redirect(url_for('auth.login'))
    
    email = userinfo.get('email')
    name = userinfo.get('name', email.split('@')[0] if email else 'User')
    google_id = userinfo.get('sub')
    picture = userinfo.get('picture', '')
    
    if not email or not google_id:
        flash('Incomplete information from Google.', 'danger')
        return redirect(url_for('auth.login'))
    
    # Check if user exists
    user = User.query.filter_by(email=email).first()
    if not user:
        # Create new user from Google data
        user = User(
            username=email.split('@')[0],
            full_name=name,
            email=email,
            phone='',
            city='',
            user_type='client',
            is_active=True,
            password_hash=generate_password_hash(gen_reference())
        )
        db.session.add(user)
        db.session.commit()
    
    # Store or update OAuth token
    oauth_token = OAuthToken.query.filter_by(user_id=user.id, provider='google').first()
    if not oauth_token:
        oauth_token = OAuthToken(user_id=user.id, provider='google', provider_user_id=google_id)
        db.session.add(oauth_token)
    oauth_token.access_token = access_token
    oauth_token.expires_at = datetime.utcnow() + timedelta(seconds=token_json.get('expires_in', 3600))
    db.session.commit()
    
    session['user_id'] = user.id
    session['username'] = user.username
    session['user_type'] = user.user_type
    flash(f'Welcome {user.full_name}! You are logged in via Google.', 'success')
    return redirect(url_for('main.dashboard'))

@api_bp.route('/api/chat/send', methods=['POST'])
@login_required
def api_chat_send():
    """Send a message via API"""
    data = request.get_json() or request.form
    receiver_id = data.get('receiver_id')
    if receiver_id:
        try:
            receiver_id = int(receiver_id)
        except (ValueError, TypeError):
            receiver_id = None
    content = (data.get('content') or '').strip()
    
    if not receiver_id or not content:
        return jsonify({'error': 'receiver_id and content required'}), 400
    
    receiver = User.query.get(receiver_id)
    if not receiver:
        return jsonify({'error': 'Receiver not found'}), 404
    
    msg = Message(
        sender_id=session['user_id'],
        receiver_id=receiver_id,
        content=content
    )
    db.session.add(msg)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': {
            'id': msg.id, 'sender_id': msg.sender_id, 'receiver_id': msg.receiver_id,
            'content': msg.content, 'is_read': msg.is_read,
            'created_at': msg.created_at.strftime('%H:%M') if msg.created_at else '',
            'sender_name': User.query.get(session['user_id']).full_name
        }
    })

@api_bp.route('/api/chat/unread-count')
@login_required
def api_chat_unread_count():
    """Get count of unread messages"""
    count = Message.query.filter_by(receiver_id=session['user_id'], is_read=False).count()
    return jsonify({'count': count})

@api_bp.route('/my-favorites')
@login_required
def my_favorites():
    user = User.query.get(session['user_id'])
    favorites = Favorite.query.filter_by(user_id=user.id).order_by(Favorite.created_at.desc()).all()
    return render_template('my_favorites.html', favorites=favorites)

@api_bp.route('/toggle-rtl', methods=['POST'])
@login_required
def toggle_rtl():
    user = User.query.get(session['user_id'])
    user.prefers_rtl = not user.prefers_rtl
    db.session.commit()
    session['rtl'] = user.prefers_rtl
    return redirect(request.referrer or url_for('main.index'))

@api_bp.route('/manifest.json')
def manifest():
    return jsonify({
        "name": "Lmawqef Pocket", "short_name": "Lmawqef",
        "start_url": "/", "display": "standalone",
        "background_color": "#ffffff", "theme_color": "#1a5f2a",
        "icons": [
            {"src": "/static/img/icon-192.png", "sizes": "192x192"},
            {"src": "/static/img/icon-512.png", "sizes": "512x512"}
        ]
    })

@api_bp.route('/sw.js')
def service_worker():
    sw = "const CACHE_NAME='lmawqef-v1';const urlsToCache=['/','/static/css/style.css','/static/js/main.js'];self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(urlsToCache)))});self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});"
    return sw, 200, {'Content-Type': 'application/javascript'}

@api_bp.route('/upload/avatar', methods=['POST'])
@login_required
def upload_avatar():
    user = User.query.get(session['user_id'])
    if 'avatar' not in request.files:
        flash('Aucun fichier selectionne.', 'danger')
        return redirect(url_for('workers.my_profile'))
    file = request.files['avatar']
    if file.filename == '':
        flash('Aucun fichier selectionne.', 'danger')
        return redirect(url_for('workers.my_profile'))
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        filename = f"avatar_{user.id}_{int(datetime.utcnow().timestamp())}{ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'avatars', filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        file.save(filepath)
        user.avatar = f"uploads/avatars/{filename}"
        db.session.commit()
        flash('Photo de profil mise a jour!', 'success')
    return redirect(url_for('workers.my_profile'))

@api_bp.route('/upload/portfolio', methods=['POST'])
@login_required
def upload_portfolio():
    user = User.query.get(session['user_id'])
    if 'portfolio' not in request.files:
        flash('Aucun fichier selectionne.', 'danger')
        return redirect(url_for('workers.my_profile'))
    file = request.files['portfolio']
    if file and file.filename != '' and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        filename = f"portfolio_{user.id}_{int(datetime.utcnow().timestamp())}{ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'portfolio', filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        file.save(filepath)
        title = request.form.get('title', 'Portfolio Item')
        desc = request.form.get('description', '')
        item = PortfolioItem(user_id=user.id, title=title, description=desc, filename=f"uploads/portfolio/{filename}")
        db.session.add(item)
        db.session.commit()
        flash('Element ajoute au portfolio!', 'success')
    return redirect(url_for('workers.my_profile'))

@api_bp.route('/api/maps/nearby')
def api_maps_nearby():
    """Find nearby workers based on lat/lon"""
    try:
        lat = float(request.args.get('lat', 0))
        lon = float(request.args.get('lon', 0))
        radius = float(request.args.get('radius', 10))
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid coordinates'}), 400
    
    # Haversine formula
    from math import radians, cos, sin, asin, sqrt
    def haversine(lat1, lon1, lat2, lon2):
        lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        return 2 * 6371 * asin(sqrt(a))
    
    workers = User.query.filter_by(user_type='worker', is_active=True).all()
    nearby = []
    for w in workers:
        if w.latitude and w.longitude:
            dist = haversine(lat, lon, w.latitude, w.longitude)
            if dist <= radius:
                nearby.append({
                    'id': w.id, 'username': w.username, 'full_name': w.full_name,
                    'profession': w.profession or '', 'city': w.city,
                    'distance_km': round(dist, 1), 'rating': w.average_rating()
                })
    nearby.sort(key=lambda x: x['distance_km'])
    return jsonify({'workers': nearby[:20]})

@api_bp.route('/my-invoices')
@login_required
def my_invoices():
    """List all invoices for current user"""
    user = User.query.get(session['user_id'])
    if user.is_admin:
        invoices = Invoice.query.order_by(Invoice.created_at.desc()).all()
    else:
        invoices = Invoice.query.filter(
            db.or_(Invoice.user_id == user.id, Invoice.worker_id == user.id)
        ).order_by(Invoice.created_at.desc()).all()
    return render_template('my_invoices.html', invoices=invoices, user=user)

@api_bp.route('/devis/<int:id>/sign', methods=['GET', 'POST'])
@login_required
def sign_devis(id):
    """Page for electronic signature on devis"""
    devis = Devis.query.get_or_404(id)
    user = User.query.get(session['user_id'])
    # Worker signs first, then client
    is_worker = devis.worker_id == user.id
    is_client = not is_worker  # Anyone else can sign as client if they have the link
    if request.method == 'POST':
        signature_data = request.form.get('signature')
        if not signature_data:
            flash('Signature requise.', 'danger')
            return redirect(url_for('sign_devis', id=id))
        if is_worker and not devis.worker_signature:
            devis.worker_signature = signature_data
            devis.worker_signed_at = datetime.utcnow()
            devis.status = 'signed'
            db.session.commit()
            flash('Devis signe electroniquement par vous (Worker).', 'success')
        elif not is_worker and devis.worker_signature and not devis.client_signature:
            devis.client_signature = signature_data
            devis.client_signed_at = datetime.utcnow()
            devis.status = 'accepted'
            db.session.commit()
            flash('Devis signe electroniquement par le Client. Devis accepte!', 'success')
        else:
            flash('Signature non autorisee a ce stade.', 'warning')
        return redirect(url_for('devis_pdf', id=id))
    return render_template('sign_devis.html', devis=devis, is_worker=is_worker, is_client=is_client, user=user)

@api_bp.route('/api/devis/<int:id>/sign', methods=['POST'])
@login_required
def api_sign_devis(id):
    """API endpoint to save electronic signature"""
    devis = Devis.query.get_or_404(id)
    user = User.query.get(session['user_id'])
    data = request.get_json() or request.form
    signature_data = data.get('signature') if hasattr(data, 'get') else data.get('signature')
    if not signature_data:
        return jsonify({'error': 'Signature data required'}), 400
    is_worker = devis.worker_id == user.id
    if is_worker and not devis.worker_signature:
        devis.worker_signature = signature_data
        devis.worker_signed_at = datetime.utcnow()
        devis.status = 'signed'
        db.session.commit()
        return jsonify({'success': True, 'signed_by': 'worker', 'status': devis.status})
    elif not is_worker and devis.worker_signature and not devis.client_signature:
        devis.client_signature = signature_data
        devis.client_signed_at = datetime.utcnow()
        devis.status = 'accepted'
        db.session.commit()
        return jsonify({'success': True, 'signed_by': 'client', 'status': devis.status})
    return jsonify({'error': 'Not authorized or already signed'}), 403

