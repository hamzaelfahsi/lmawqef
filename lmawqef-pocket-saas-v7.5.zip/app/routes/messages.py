from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation
)

messages_bp = Blueprint('messages', __name__)

@messages_bp.route('/messages')
@login_required
def messages():
    user = User.query.get(session['user_id'])
    sent = Message.query.filter_by(sender_id=user.id).all()
    received = Message.query.filter_by(receiver_id=user.id).all()
    conversation_ids = set()
    for m in sent: conversation_ids.add(m.receiver_id)
    for m in received: conversation_ids.add(m.sender_id)
    conversations = []
    for uid in conversation_ids:
        other = User.query.get(uid)
        if other:
            last_msg = Message.query.filter(
                db.or_(
                    db.and_(Message.sender_id == user.id, Message.receiver_id == uid),
                    db.and_(Message.sender_id == uid, Message.receiver_id == user.id)
                )
            ).order_by(Message.created_at.desc()).first()
            unread = Message.query.filter_by(sender_id=uid, receiver_id=user.id, is_read=False).count()
            conversations.append({'user': other, 'last_message': last_msg, 'unread': unread})
    conversations.sort(key=lambda x: x['last_message'].created_at if x['last_message'] else datetime.min, reverse=True)
    selected_id = request.args.get('with', type=int)
    selected_user = User.query.get(selected_id) if selected_id else None
    messages_list = []
    if selected_user:
        messages_list = Message.query.filter(
            db.or_(
                db.and_(Message.sender_id == user.id, Message.receiver_id == selected_id),
                db.and_(Message.sender_id == selected_id, Message.receiver_id == user.id)
            )
        ).order_by(Message.created_at.asc()).all()
        for msg in messages_list:
            if msg.receiver_id == user.id and not msg.is_read:
                msg.is_read = True
        db.session.commit()
    return render_template('messages.html', conversations=conversations, selected_user=selected_user,
                         messages_list=messages_list)

@messages_bp.route('/messages/send', methods=['POST'])
@login_required
def send_message():
    receiver_id = request.form.get('receiver_id', type=int)
    content = request.form.get('content')
    if not receiver_id or not content:
        return jsonify({'success': False, 'error': 'Missing data'})
    receiver = User.query.get(receiver_id)
    if not receiver:
        return jsonify({'success': False, 'error': 'User not found'})
    msg = Message(sender_id=session['user_id'], receiver_id=receiver_id, content=content)
    db.session.add(msg)
    sender = User.query.get(session['user_id'])
    notif = Notification(user_id=receiver_id, title='Nouveau message',
                        message=f'{sender.full_name}: {content[:50]}...',
                        type='message', link='/messages?with=' + str(session['user_id']))
    db.session.add(notif)
    db.session.commit()
    return jsonify({'success': True, 'message': {
        'id': msg.id, 'content': msg.content,
        'created_at': msg.created_at.strftime('%H:%M'), 'is_sender': True
    }})

@messages_bp.route('/api/messages/poll')
@login_required
def poll_messages():
    with_id = request.args.get('with', type=int)
    last_id = request.args.get('last_id', 0, type=int)
    if not with_id:
        return jsonify({'messages': []})
    messages = Message.query.filter(
        db.or_(
            db.and_(Message.sender_id == session['user_id'], Message.receiver_id == with_id),
            db.and_(Message.sender_id == with_id, Message.receiver_id == session['user_id'])
        ), Message.id > last_id
    ).order_by(Message.created_at.asc()).all()
    for msg in messages:
        if msg.receiver_id == session['user_id']:
            msg.is_read = True
    db.session.commit()
    return jsonify({'messages': [{
        'id': m.id, 'content': m.content,
        'created_at': m.created_at.strftime('%H:%M'),
        'is_sender': m.sender_id == session['user_id']
    } for m in messages]})

@messages_bp.route('/notifications')
@login_required
def notifications():
    notifs = Notification.query.filter_by(user_id=session['user_id']).order_by(Notification.created_at.desc()).all()
    for n in notifs:
        if not n.is_read:
            n.is_read = True
    db.session.commit()
    return render_template('notifications.html', notifications=notifs)

@messages_bp.route('/api/chat/messages/<int:user_id>')
@messages_bp.route('/api/chat/messages')
@login_required
def api_chat_messages(user_id=None):
    """Get messages between current user and another user"""
    other_id = user_id or request.args.get('user_id', type=int)
    if not other_id:
        return jsonify({'error': 'user_id required'}), 400
    
    msgs = Message.query.filter(
        ((Message.sender_id == session['user_id']) & (Message.receiver_id == other_id)) |
        ((Message.sender_id == other_id) & (Message.receiver_id == session['user_id']))
    ).order_by(Message.created_at.asc()).all()
    
    # Mark as read
    for msg in msgs:
        if msg.receiver_id == session['user_id'] and not msg.is_read:
            msg.is_read = True
    db.session.commit()
    
    return jsonify({
        'messages': [{
            'id': m.id, 'sender_id': m.sender_id, 'receiver_id': m.receiver_id,
            'content': m.content, 'is_read': m.is_read,
            'created_at': m.created_at.strftime('%H:%M') if m.created_at else '',
            'sender_name': User.query.get(m.sender_id).full_name if User.query.get(m.sender_id) else 'Unknown'
        } for m in msgs]
    })

@messages_bp.route('/messages/poll')
@login_required
def messages_poll():
    since_id = request.args.get('since', 0, type=int)
    new_msgs = Message.query.filter(
        Message.receiver_id == session['user_id'],
        Message.id > since_id,
        Message.is_read == False
    ).order_by(Message.created_at.asc()).all()
    return jsonify({
        'messages': [{
            'id': m.id, 'sender_id': m.sender_id,
            'sender_name': m.sender.full_name if m.sender else 'Inconnu',
            'content': m.content, 'created_at': m.created_at.strftime('%H:%M')
        } for m in new_msgs],
        'unread_count': Message.query.filter_by(receiver_id=session['user_id'], is_read=False).count()
    })

@messages_bp.route('/message/<int:msg_id>/read', methods=['POST'])
@login_required
def mark_message_read(msg_id):
    msg = Message.query.get_or_404(msg_id)
    if msg.receiver_id == session['user_id']:
        msg.is_read = True
        msg.is_delivered = True
        msg.delivered_at = datetime.utcnow()
        db.session.commit()
    return jsonify({'success': True})

@messages_bp.route('/message/send-ajax', methods=['POST'])
@login_required
def send_message_ajax():
    receiver_id = request.form.get('receiver_id', type=int)
    content = request.form.get('content', '').strip()
    if not receiver_id or not content:
        return jsonify({'error': 'Invalid data'}), 400
    msg = Message(sender_id=session['user_id'], receiver_id=receiver_id,
                  content=content, is_read=False)
    db.session.add(msg)
    db.session.commit()
    return jsonify({
        'success': True, 'message': {
            'id': msg.id, 'content': msg.content,
            'created_at': msg.created_at.strftime('%H:%M'), 'is_me': True
        }
    })

