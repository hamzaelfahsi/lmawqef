from app import create_app
import os

app = create_app()

if __name__ == '__main__':
    # Replit uses 0.0.0.0 and auto-detects port
    port = int(os.environ.get('PORT', 5000))
    host = '0.0.0.0'
    debug = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    app.run(host=host, port=port, debug=debug)
