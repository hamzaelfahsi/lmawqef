# Lmawqef Pocket - Replit Quick Start

## Aucun PostgreSQL requis !

Ce projet utilise **SQLite** par defaut. Pas besoin de `psycopg2`.

## Etapes d'installation sur Replit

### 1. Upload du ZIP
- Cliquez sur **"Upload"** dans le panneau gauche de Replit
- Uploadez `lmawqef-pocket-saas-v6.zip`
- Le projet se decompresse automatiquement

### 2. Installer les dependances (30 secondes)
Dans le Shell Replit, tapez :
```bash
pip install -r requirements.txt
```

**Note** : Si vous voyez une erreur sur `psycopg2`, **ignorez-la** — le projet utilise SQLite, pas PostgreSQL.

### 3. Lancer l'application
Cliquez sur **"Run"** (triangle vert) ou tapez dans le Shell :
```bash
python run.py
```

L'app demarre sur `http://0.0.0.0:5000`. Replit ouvre automatiquement le navigateur.

### 4. Donnees de demo
La premiere fois, les donnees de test se creent automatiquement :
- **8 Artisans** (electricien, plombier, menuisier, peintre...)
- **5 Freelancers** (dev, designer, redacteur, photographe, traducteur)
- **5 Auto-Entrepreneurs** (coach, comptable, consultante, formateur, avocate)
- **5 Entreprises** (BTP, nettoyage, demenagement, IT, securite)
- **7 Clients** + **49 Services** + **21 Factures payees**

### 5. Comptes de test

| Compte | Login | Mot de passe |
|--------|-------|-------------|
| Client | client.casa | client123 |
| Artisan | youssef.casa | worker123 |
| Freelancer | tech.casa | worker123 |
| Auto-Entrepreneur | coach.casa | worker123 |
| Entreprise | btp.casa | worker123 |

## Structure du projet

```
lmawqef-pocket/
├── run.py              # Point d'entree
├── requirements.txt   # 4 packages uniquement
├── .replit            # Config Replit (auto)
├── replit.nix         # Deps systeme Replit (auto)
├── app/
│   ├── __init__.py    # Factory Flask + SQLite
│   ├── models/        # Modeles de donnees
│   ├── routes/        # 10 blueprints
│   ├── templates/     # 70+ templates Jinja2
│   ├── static/        # CSS/JS/Images
│   └── translations/    # FR / EN / AR
└── instance/
    └── lmawqef_v6.db  # Base SQLite (auto-generee)
```

## Changer de langue

Cliquez sur le drapeau dans la navbar : **FR** 🇫🇷 / **AR** 🇲🇦 / **EN** 🇬🇧

## Troubleshooting

| Probleme | Solution |
|----------|----------|
| `ModuleNotFoundError` | `pip install -r requirements.txt` |
| Port 5000 occupe | Replit auto-detecte un autre port |
| Base de donnees verrouillee | Supprimez `instance/lmawqef_v6.db` et relancez |
| Erreur `psycopg2` | **Ignorez** — SQLite est utilise |

## En production (Replit Deployment)

Pour deployer en ligne avec Replit :
1. Allez dans l'onglet **"Deployments"**
2. Cliquez **"Deploy"**
3. Replit genere une URL publique

---

**Made with ❤️ in Morocco**
