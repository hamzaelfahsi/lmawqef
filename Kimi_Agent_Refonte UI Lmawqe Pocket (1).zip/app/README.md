# Lmawqef Pocket — Version Fullstack Ultimate

Plateforme de mise en relation entre clients et professionnels au Maroc, reconstruite avec une stack moderne.

## Stack technique

- **Frontend** : React 19 + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend** : Hono + tRPC 11.x (end-to-end type safety)
- **Base de données** : MySQL + Drizzle ORM
- **Authentification** : OAuth 2.0 (Kimi) + Email/Mot de passe local (bcrypt + JWT)

## Fonctionnalités implémentées

### Core
- Authentification (inscription / connexion) avec choix de profil : Client, Artisan, Entreprise, Auto-entrepreneur, Freelance
- Marketplace de services par catégorie et ville
- Profils professionnels avec portfolio, disponibilités, badges, niveaux
- Système de réservation avec statuts (pending → confirmed → in_progress → completed)
- Avis et notation
- Chat temps réel (polling)
- Système de notifications

### Monétisation
- Abonnements (Gratuit / Basic / Pro / Entreprise)
- Annonces payantes (5 gratuites, puis 20 MAD)
- Profils en vedette
- Assurance Lmawqef Protect
- Commissions (10% par défaut)

### Gamification
- Système de points et niveaux (Novice → Légende)
- Badges automatiques (Premier client, Artisan confirmé, Top Rated, Urgencier...)
- Classement public des professionnels

### Admin
- Dashboard avec statistiques (utilisateurs, revenus, commissions)
- Gestion des utilisateurs, paiements, annonces
- Messages de contact
- Configuration des badges, niveaux et plans

## Schéma base de données (20+ tables)

- `users` — comptes avec champs métier (profession, géolocalisation, gamification, abonnement)
- `categories` — catégories de services
- `services` / `service_images` — services et photos
- `bookings` — réservations avec commission et avis
- `messages` — chat entre utilisateurs
- `notifications` — système de notifications
- `subscription_plans` / `user_subscriptions` — abonnements
- `annonces` — annonces payantes
- `payments` — paiements simulés
- `levels` / `badges` / `user_badges` — gamification
- `devis` / `devis_items` — devis PDF
- `portfolio_items` — portfolio photos
- `availabilities` — disponibilités hebdomadaires
- `commissions` — suivi des commissions
- `contact_messages` — formulaire de contact
- `app_configs` — configuration dynamique

## Commandes

```bash
# Développement
npm install
npm run db:push   # synchroniser le schéma MySQL
npm run dev       # http://localhost:3000

# Production
npm run build
npm start
```

## Déploiement

1. Configurer `DATABASE_URL` dans `.env`
2. Exécuter `npm run db:push`
3. Exécuter `npx tsx db/seed.ts` pour initialiser les catégories, niveaux, badges et plans
4. Exécuter `npm run build`
5. Démarrer avec `npm start`

## Variables d'environnement

- `DATABASE_URL` — URL de connexion MySQL
- `APP_SECRET` — secret pour les JWT (généré automatiquement)
- `VITE_KIMI_AUTH_URL`, `VITE_APP_ID`, `APP_SECRET` — configuration OAuth Kimi

## Structure des routes frontend

- `/` — Landing page
- `/marketplace` — Marketplace des services
- `/service/:id` — Détail d'un service
- `/worker/:id` — Profil professionnel
- `/dashboard` — Tableau de bord
- `/messages` — Chat
- `/notifications` — Notifications
- `/annonces` — Annonces
- `/annonces/new` — Créer une annonce
- `/abonnements` — Plans d'abonnement
- `/leaderboard` — Classement
- `/admin` — Panel admin
- `/login` — Connexion
- `/register` — Inscription
