import { relations } from "drizzle-orm";
import {
  users, sessions, categories, services, serviceImages, bookings,
  messages, notifications, subscriptionPlans, userSubscriptions,
  annonces, payments, levels, badges, userBadges, devis, devisItems,
  portfolioItems, availabilities, commissions,
} from "./schema";

export const usersRelations = relations(users, ({ many, one }) => ({
  sessions: many(sessions),
  services: many(services),
  bookingsAsClient: many(bookings, { relationName: "clientBookings" }),
  bookingsAsWorker: many(bookings, { relationName: "workerBookings" }),
  sentMessages: many(messages, { relationName: "sentMessages" }),
  receivedMessages: many(messages, { relationName: "receivedMessages" }),
  notifications: many(notifications),
  subscriptions: many(userSubscriptions),
  annonces: many(annonces),
  payments: many(payments),
  portfolioItems: many(portfolioItems),
  availabilities: many(availabilities),
  userBadges: many(userBadges),
  level: one(levels, { fields: [users.levelId], references: [levels.id] }),
  subscriptionPlan: one(subscriptionPlans, { fields: [users.subscriptionPlanId], references: [subscriptionPlans.id] }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, { fields: [sessions.userId], references: [users.id] }),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  services: many(services),
  annonces: many(annonces),
}));

export const servicesRelations = relations(services, ({ one, many }) => ({
  worker: one(users, { fields: [services.workerId], references: [users.id] }),
  category: one(categories, { fields: [services.categoryId], references: [categories.id] }),
  images: many(serviceImages),
  bookings: many(bookings),
}));

export const serviceImagesRelations = relations(serviceImages, ({ one }) => ({
  service: one(services, { fields: [serviceImages.serviceId], references: [services.id] }),
}));

export const bookingsRelations = relations(bookings, ({ one, many }) => ({
  client: one(users, { fields: [bookings.clientId], references: [users.id], relationName: "clientBookings" }),
  worker: one(users, { fields: [bookings.workerId], references: [users.id], relationName: "workerBookings" }),
  service: one(services, { fields: [bookings.serviceId], references: [services.id] }),
  messages: many(messages),
  devis: many(devis),
  commissions: many(commissions),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, { fields: [messages.senderId], references: [users.id], relationName: "sentMessages" }),
  receiver: one(users, { fields: [messages.receiverId], references: [users.id], relationName: "receivedMessages" }),
  booking: one(bookings, { fields: [messages.bookingId], references: [bookings.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

export const subscriptionPlansRelations = relations(subscriptionPlans, ({ many }) => ({
  userSubscriptions: many(userSubscriptions),
  users: many(users),
}));

export const userSubscriptionsRelations = relations(userSubscriptions, ({ one }) => ({
  user: one(users, { fields: [userSubscriptions.userId], references: [users.id] }),
  plan: one(subscriptionPlans, { fields: [userSubscriptions.planId], references: [subscriptionPlans.id] }),
}));

export const annoncesRelations = relations(annonces, ({ one }) => ({
  user: one(users, { fields: [annonces.userId], references: [users.id] }),
  category: one(categories, { fields: [annonces.categoryId], references: [categories.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, { fields: [payments.userId], references: [users.id] }),
}));

export const levelsRelations = relations(levels, ({ many }) => ({
  users: many(users),
}));

export const badgesRelations = relations(badges, ({ many }) => ({
  userBadges: many(userBadges),
}));

export const userBadgesRelations = relations(userBadges, ({ one }) => ({
  user: one(users, { fields: [userBadges.userId], references: [users.id] }),
  badge: one(badges, { fields: [userBadges.badgeId], references: [badges.id] }),
}));

export const devisRelations = relations(devis, ({ one, many }) => ({
  worker: one(users, { fields: [devis.workerId], references: [users.id] }),
  client: one(users, { fields: [devis.clientId], references: [users.id] }),
  booking: one(bookings, { fields: [devis.bookingId], references: [bookings.id] }),
  items: many(devisItems),
}));

export const devisItemsRelations = relations(devisItems, ({ one }) => ({
  devis: one(devis, { fields: [devisItems.devisId], references: [devis.id] }),
}));

export const portfolioItemsRelations = relations(portfolioItems, ({ one }) => ({
  user: one(users, { fields: [portfolioItems.userId], references: [users.id] }),
}));

export const availabilitiesRelations = relations(availabilities, ({ one }) => ({
  user: one(users, { fields: [availabilities.userId], references: [users.id] }),
}));

export const commissionsRelations = relations(commissions, ({ one }) => ({
  booking: one(bookings, { fields: [commissions.bookingId], references: [bookings.id] }),
  worker: one(users, { fields: [commissions.workerId], references: [users.id] }),
}));
