import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "../db/schema";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL not set");

const db = drizzle(databaseUrl, { mode: "planetscale", schema });

async function seed() {
  // Categories
  const cats = await db.select().from(schema.categories);
  if (cats.length === 0) {
    await db.insert(schema.categories).values([
      { name: "Plomberie", slug: "plomberie", icon: "droplet", color: "#3498db", displayOrder: 1 },
      { name: "Électricité", slug: "electricite", icon: "zap", color: "#f1c40f", displayOrder: 2 },
      { name: "Menuiserie", slug: "menuiserie", icon: "trees", color: "#8B4513", displayOrder: 3 },
      { name: "Peinture", slug: "peinture", icon: "paintbrush", color: "#e74c3c", displayOrder: 4 },
      { name: "Jardinage", slug: "jardinage", icon: "leaf", color: "#2ecc71", displayOrder: 5 },
      { name: "Nettoyage", slug: "nettoyage", icon: "sparkles", color: "#1abc9c", displayOrder: 6 },
      { name: "Déménagement", slug: "demenagement", icon: "truck", color: "#e67e22", displayOrder: 7 },
      { name: "Informatique", slug: "informatique", icon: "laptop", color: "#9b59b6", displayOrder: 8 },
      { name: "Climatisation", slug: "climatisation", icon: "wind", color: "#00bcd4", displayOrder: 9 },
      { name: "Construction", slug: "construction", icon: "hard-hat", color: "#795548", displayOrder: 10 },
    ]);
    console.log("Categories seeded");
  }

  // Levels
  const levels = await db.select().from(schema.levels);
  if (levels.length === 0) {
    await db.insert(schema.levels).values([
      { name: "Novice", slug: "novice", minPoints: 0, maxPoints: 99, color: "#CD7F32", icon: "seedling" },
      { name: "Apprenti", slug: "apprenti", minPoints: 100, maxPoints: 499, color: "#C0C0C0", icon: "hammer" },
      { name: "Artisan", slug: "artisan", minPoints: 500, maxPoints: 1499, color: "#FFD700", icon: "star" },
      { name: "Expert", slug: "expert", minPoints: 1500, maxPoints: 4999, color: "#4ECDC4", icon: "crown" },
      { name: "Maître", slug: "maitre", minPoints: 5000, maxPoints: 9999, color: "#E74C3C", icon: "trophy" },
      { name: "Légende", slug: "legende", minPoints: 10000, maxPoints: 999999, color: "#9B59B6", icon: "gem" },
    ]);
    console.log("Levels seeded");
  }

  // Badges
  const badges = await db.select().from(schema.badges);
  if (badges.length === 0) {
    await db.insert(schema.badges).values([
      { name: "Premier Client", slug: "premier-client", description: "Avoir 1 réservation complétée", conditionType: "bookings_count", conditionValue: 1, pointsReward: 10, color: "#3498db", icon: "handshake" },
      { name: "Artisan Confirmé", slug: "artisan-confirme", description: "Avoir 10 réservations complétées", conditionType: "bookings_count", conditionValue: 10, pointsReward: 50, color: "#2ecc71", icon: "badge-check" },
      { name: "Top Rated", slug: "top-rated", description: "Avoir une note moyenne de 4.5+", conditionType: "rating", conditionValue: 5, pointsReward: 100, color: "#f1c40f", icon: "star" },
      { name: "Expert Recommandé", slug: "expert-recommande", description: "Avoir 20 avis positifs", conditionType: "reviews_count", conditionValue: 20, pointsReward: 75, color: "#e67e22", icon: "thumbs-up" },
      { name: "Super Prestataire", slug: "super-prestataire", description: "Avoir 5 services actifs", conditionType: "services_count", conditionValue: 5, pointsReward: 30, color: "#9b59b6", icon: "briefcase" },
      { name: "Urgencier", slug: "urgencier", description: "Compléter 5 services urgents", conditionType: "urgent_jobs", conditionValue: 5, pointsReward: 60, color: "#e74c3c", icon: "zap" },
    ]);
    console.log("Badges seeded");
  }

  // Subscription plans
  const plans = await db.select().from(schema.subscriptionPlans);
  if (plans.length === 0) {
    await db.insert(schema.subscriptionPlans).values([
      { name: "Gratuit", slug: "gratuit", description: "Pour démarrer", price: "0.00", durationDays: 30, maxServices: 3, maxAnnonces: 0, maxPortfolio: 3, isActive: true, displayOrder: 1 },
      { name: "Basic", slug: "basic", description: "Pour artisans actifs", price: "99.00", durationDays: 30, maxServices: 10, maxAnnonces: 5, maxPortfolio: 10, isActive: true, displayOrder: 2 },
      { name: "Pro", slug: "pro", description: "Pour professionnels", price: "249.00", durationDays: 30, maxServices: 50, maxAnnonces: 20, maxPortfolio: 50, isActive: true, displayOrder: 3 },
      { name: "Entreprise", slug: "entreprise", description: "Pour les entreprises", price: "499.00", durationDays: 30, maxServices: 999, maxAnnonces: 50, maxPortfolio: 200, isActive: true, displayOrder: 4 },
    ]);
    console.log("Plans seeded");
  }

  console.log("Seed completed!");
}

seed().catch(console.error);
