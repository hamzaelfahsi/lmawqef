import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  decimal,
  boolean,
  bigint,
} from "drizzle-orm/mysql-core";

// =================== USERS ===================
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).unique(),
  email: varchar("email", { length: 320 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: varchar("name", { length: 255 }),
  avatar: text("avatar"),
  phone: varchar("phone", { length: 50 }),
  city: varchar("city", { length: 100 }),
  role: mysqlEnum("role", ["user", "admin", "superadmin"]).default("user").notNull(),
  // Gamification
  points: int("points").default(0).notNull(),
  levelId: bigint("levelId", { mode: "number", unsigned: true }),
  // Account type
  accountType: mysqlEnum("accountType", ["client", "worker", "enterprise", "auto_entrepreneur", "freelance"]).default("client").notNull(),
  enterpriseName: varchar("enterpriseName", { length: 255 }),
  iceNumber: varchar("iceNumber", { length: 50 }),
  rcNumber: varchar("rcNumber", { length: 50 }),
  // Worker profile fields
  profession: varchar("profession", { length: 255 }),
  bio: text("bio"),
  address: text("address"),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  isVerified: boolean("isVerified").default(false).notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  featuredUntil: timestamp("featuredUntil"),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0.0").notNull(),
  reviewCount: int("reviewCount").default(0).notNull(),
  completedJobs: int("completedJobs").default(0).notNull(),
  // Insurance
  hasInsurance: boolean("hasInsurance").default(false).notNull(),
  insuranceUntil: timestamp("insuranceUntil"),
  // Subscription
  subscriptionPlanId: bigint("subscriptionPlanId", { mode: "number", unsigned: true }),
  subscriptionUntil: timestamp("subscriptionUntil"),
  // Announcements
  freeAnnoncesUsed: int("freeAnnoncesUsed").default(0).notNull(),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const sessions = mysqlTable("sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  token: varchar("token", { length: 512 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== CATEGORIES ===================
export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  icon: varchar("icon", { length: 100 }),
  color: varchar("color", { length: 20 }),
  description: text("description"),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== SERVICES ===================
export const services = mysqlTable("services", {
  id: serial("id").primaryKey(),
  workerId: bigint("workerId", { mode: "number", unsigned: true }).notNull(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  priceType: mysqlEnum("priceType", ["fixed", "hourly", "quote"]).default("fixed").notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  isUrgent: boolean("isUrgent").default(false).notNull(),
  urgentMultiplier: decimal("urgentMultiplier", { precision: 3, scale: 2 }).default("1.50").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  viewCount: int("viewCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export const serviceImages = mysqlTable("service_images", {
  id: serial("id").primaryKey(),
  serviceId: bigint("serviceId", { mode: "number", unsigned: true }).notNull(),
  imageUrl: text("imageUrl").notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== BOOKINGS ===================
export const bookings = mysqlTable("bookings", {
  id: serial("id").primaryKey(),
  clientId: bigint("clientId", { mode: "number", unsigned: true }).notNull(),
  workerId: bigint("workerId", { mode: "number", unsigned: true }).notNull(),
  serviceId: bigint("serviceId", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", ["pending", "confirmed", "in_progress", "completed", "cancelled", "disputed"]).default("pending").notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).default("0.00").notNull(),
  rating: int("rating"),
  review: text("review"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// =================== MESSAGES ===================
export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  senderId: bigint("senderId", { mode: "number", unsigned: true }).notNull(),
  receiverId: bigint("receiverId", { mode: "number", unsigned: true }).notNull(),
  bookingId: bigint("bookingId", { mode: "number", unsigned: true }),
  content: text("content").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== NOTIFICATIONS ===================
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["booking", "message", "review", "payment", "subscription", "announcement", "system", "badge"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  relatedId: bigint("relatedId", { mode: "number", unsigned: true }),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== SUBSCRIPTIONS ===================
export const subscriptionPlans = mysqlTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  durationDays: int("durationDays").default(30).notNull(),
  maxServices: int("maxServices").default(5).notNull(),
  maxAnnonces: int("maxAnnonces").default(3).notNull(),
  maxPortfolio: int("maxPortfolio").default(5).notNull(),
  features: text("features"), // JSON array
  isActive: boolean("isActive").default(true).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const userSubscriptions = mysqlTable("user_subscriptions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  planId: bigint("planId", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", ["active", "expired", "cancelled", "pending"]).default("active").notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  paymentRef: varchar("paymentRef", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== ANNONCES ===================
export const annonces = mysqlTable("annonces", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }),
  isUrgent: boolean("isUrgent").default(false).notNull(),
  status: mysqlEnum("status", ["pending", "active", "completed", "cancelled"]).default("pending").notNull(),
  isPaid: boolean("isPaid").default(false).notNull(),
  paymentRef: varchar("paymentRef", { length: 255 }),
  views: int("views").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// =================== PAYMENTS ===================
export const payments = mysqlTable("payments", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["annonce", "subscription", "featured", "insurance", "commission"]).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("MAD").notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  paymentMethod: varchar("paymentMethod", { length: 50 }),
  transactionId: varchar("transactionId", { length: 255 }),
  relatedId: bigint("relatedId", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// =================== GAMIFICATION ===================
export const levels = mysqlTable("levels", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  minPoints: int("minPoints").default(0).notNull(),
  maxPoints: int("maxPoints").default(0).notNull(),
  color: varchar("color", { length: 20 }).default("#FFD700").notNull(),
  icon: varchar("icon", { length: 100 }),
  benefits: text("benefits"), // JSON
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const badges = mysqlTable("badges", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 100 }),
  color: varchar("color", { length: 20 }).default("#4ECDC4").notNull(),
  conditionType: mysqlEnum("conditionType", ["bookings_count", "rating", "reviews_count", "services_count", "points", "featured", "insurance", "urgent_jobs"]).notNull(),
  conditionValue: int("conditionValue").default(1).notNull(),
  pointsReward: int("pointsReward").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const userBadges = mysqlTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  badgeId: bigint("badgeId", { mode: "number", unsigned: true }).notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

// =================== DEVIS / QUOTES ===================
export const devis = mysqlTable("devis", {
  id: serial("id").primaryKey(),
  workerId: bigint("workerId", { mode: "number", unsigned: true }).notNull(),
  clientId: bigint("clientId", { mode: "number", unsigned: true }).notNull(),
  bookingId: bigint("bookingId", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["draft", "sent", "accepted", "rejected", "expired"]).default("draft").notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).default("0.00").notNull(),
  taxRate: decimal("taxRate", { precision: 5, scale: 2 }).default("20.00").notNull(),
  taxAmount: decimal("taxAmount", { precision: 10, scale: 2 }).default("0.00").notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).default("0.00").notNull(),
  validUntil: timestamp("validUntil"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export const devisItems = mysqlTable("devis_items", {
  id: serial("id").primaryKey(),
  devisId: bigint("devisId", { mode: "number", unsigned: true }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== PORTFOLIO ===================
export const portfolioItems = mysqlTable("portfolio_items", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("imageUrl").notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== AVAILABILITY ===================
export const availabilities = mysqlTable("availabilities", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  dayOfWeek: int("dayOfWeek").notNull(), // 0-6
  startTime: varchar("startTime", { length: 5 }).notNull(), // HH:MM
  endTime: varchar("endTime", { length: 5 }).notNull(),
  isAvailable: boolean("isAvailable").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== COMMISSIONS ===================
export const commissions = mysqlTable("commissions", {
  id: serial("id").primaryKey(),
  bookingId: bigint("bookingId", { mode: "number", unsigned: true }).notNull(),
  workerId: bigint("workerId", { mode: "number", unsigned: true }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  rate: decimal("rate", { precision: 5, scale: 2 }).default("10.00").notNull(),
  status: mysqlEnum("status", ["pending", "paid", "waived"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  paidAt: timestamp("paidAt"),
});

// =================== CONTACT MESSAGES ===================
export const contactMessages = mysqlTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// =================== CONFIG ===================
export const appConfigs = mysqlTable("app_configs", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Service = typeof services.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type Annonce = typeof annonces.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type Level = typeof levels.$inferSelect;
export type Badge = typeof badges.$inferSelect;
export type Devis = typeof devis.$inferSelect;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type Category = typeof categories.$inferSelect;
