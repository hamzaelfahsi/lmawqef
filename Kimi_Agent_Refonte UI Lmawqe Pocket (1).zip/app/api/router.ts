import { authRouter } from "./auth-router";
import { localAuthRouter } from "./routers/local-auth-router";
import { userRouter } from "./routers/user-router";
import { serviceRouter } from "./routers/service-router";
import { messageRouter, notificationRouter } from "./routers/message-router";
import { subscriptionRouter, paymentRouter } from "./routers/subscription-router";
import { annonceRouter, devisRouter } from "./routers/annonce-router";
import { adminRouter } from "./routers/admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  user: userRouter,
  service: serviceRouter,
  message: messageRouter,
  notification: notificationRouter,
  subscription: subscriptionRouter,
  payment: paymentRouter,
  annonce: annonceRouter,
  devis: devisRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
