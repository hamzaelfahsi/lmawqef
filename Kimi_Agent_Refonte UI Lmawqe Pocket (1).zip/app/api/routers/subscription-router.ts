import { eq, and, desc } from "drizzle-orm";
import { z } from "zod";
import { createRouter, publicQuery, authedQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { subscriptionPlans, userSubscriptions, payments, users } from "@db/schema";

export const subscriptionRouter = createRouter({
  listPlans: publicQuery.query(async () => {
    const db = getDb();
    return db.query.subscriptionPlans.findMany({
      where: eq(subscriptionPlans.isActive, true),
      orderBy: subscriptionPlans.displayOrder,
    });
  }),

  getMySubscription: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const sub = await db.query.userSubscriptions.findFirst({
      where: and(eq(userSubscriptions.userId, ctx.user.id), eq(userSubscriptions.status, "active")),
      orderBy: desc(userSubscriptions.expiresAt),
      with: { plan: true },
    });
    return sub;
  }),

  subscribe: authedQuery
    .input(z.object({ planId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const plan = await db.query.subscriptionPlans.findFirst({ where: eq(subscriptionPlans.id, input.planId) });
      if (!plan) throw new Error("Plan not found");
      const now = new Date();
      const expiresAt = new Date(now.getTime() + plan.durationDays * 24 * 60 * 60 * 1000);
      const [sub] = await db.insert(userSubscriptions).values({
        userId: ctx.user.id,
        planId: input.planId,
        status: "active",
        startedAt: now,
        expiresAt,
      }).$returningId();
      await db.update(users).set({
        subscriptionPlanId: input.planId,
        subscriptionUntil: expiresAt,
        updatedAt: now,
      }).where(eq(users.id, ctx.user.id));
      return { id: sub.id, expiresAt };
    }),

  // Admin
  createPlan: adminQuery
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
      description: z.string().optional(),
      price: z.string().or(z.number()),
      durationDays: z.number().default(30),
      maxServices: z.number().default(5),
      maxAnnonces: z.number().default(3),
      maxPortfolio: z.number().default(5),
      features: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const price = typeof input.price === "string" ? parseFloat(input.price) : input.price;
      const res = await db.insert(subscriptionPlans).values({ ...input, price: price.toFixed(2) });
      return res;
    }),

  updatePlan: adminQuery
    .input(z.object({ id: z.number(), isActive: z.boolean().optional(), price: z.string().or(z.number()).optional(), maxServices: z.number().optional(), maxAnnonces: z.number().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const updates: any = {};
      if (input.isActive !== undefined) updates.isActive = input.isActive;
      if (input.price !== undefined) updates.price = typeof input.price === "string" ? parseFloat(input.price) : input.price;
      if (input.maxServices !== undefined) updates.maxServices = input.maxServices;
      if (input.maxAnnonces !== undefined) updates.maxAnnonces = input.maxAnnonces;
      await db.update(subscriptionPlans).set(updates).where(eq(subscriptionPlans.id, input.id));
      return { success: true };
    }),

  listAllSubscriptions: adminQuery.query(async () => {
    const db = getDb();
    return db.query.userSubscriptions.findMany({
      orderBy: desc(userSubscriptions.createdAt),
      with: { user: true, plan: true },
    });
  }),
});

export const paymentRouter = createRouter({
  createPayment: authedQuery
    .input(z.object({
      type: z.enum(["annonce", "subscription", "featured", "insurance", "commission"]),
      amount: z.number().positive(),
      relatedId: z.number().optional(),
      paymentMethod: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const txId = "TX-" + Math.random().toString(36).substring(2, 10).toUpperCase();
      const [payment] = await db.insert(payments).values({
        userId: ctx.user.id,
        type: input.type,
        amount: input.amount.toFixed(2),
        paymentMethod: input.paymentMethod || "CMI",
        transactionId: txId,
        status: "pending",
        relatedId: input.relatedId,
      }).$returningId();
      return { id: payment.id, transactionId: txId };
    }),

  confirmPayment: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const payment = await db.query.payments.findFirst({ where: eq(payments.id, input.id) });
      if (!payment || payment.userId !== ctx.user.id) throw new Error("Not authorized");
      await db.update(payments).set({ status: "completed", updatedAt: new Date() }).where(eq(payments.id, input.id));
      // Handle post-payment logic
      if (payment.type === "featured") {
        const until = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        await db.update(users).set({ isFeatured: true, featuredUntil: until, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));
      }
      if (payment.type === "insurance") {
        const until = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        await db.update(users).set({ hasInsurance: true, insuranceUntil: until, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));
      }
      return { success: true };
    }),

  listMyPayments: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.payments.findMany({
      where: eq(payments.userId, ctx.user.id),
      orderBy: desc(payments.createdAt),
    });
  }),

  listAllPayments: adminQuery.query(async () => {
    const db = getDb();
    return db.query.payments.findMany({
      orderBy: desc(payments.createdAt),
      with: { user: true },
    });
  }),
});
