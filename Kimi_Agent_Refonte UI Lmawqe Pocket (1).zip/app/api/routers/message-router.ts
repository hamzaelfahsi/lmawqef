import { eq, and, desc, or, sql } from "drizzle-orm";
import { z } from "zod";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { messages, notifications } from "@db/schema";

export const messageRouter = createRouter({
  sendMessage: authedQuery
    .input(z.object({ receiverId: z.number(), content: z.string().min(1).max(2000), bookingId: z.number().optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [msg] = await db.insert(messages).values({
        senderId: ctx.user.id,
        receiverId: input.receiverId,
        content: input.content,
        bookingId: input.bookingId,
      }).$returningId();
      // Create notification for receiver
      await db.insert(notifications).values({
        userId: input.receiverId,
        type: "message",
        title: "Nouveau message",
        content: `Vous avez reçu un message de ${ctx.user.name || "Quelqu'un"}`,
        relatedId: msg.id,
      });
      return { id: msg.id };
    }),

  getConversation: authedQuery
    .input(z.object({ otherUserId: z.number(), bookingId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const conditions = [
        or(
          and(eq(messages.senderId, ctx.user.id), eq(messages.receiverId, input.otherUserId)),
          and(eq(messages.receiverId, ctx.user.id), eq(messages.senderId, input.otherUserId))
        ),
      ];
      if (input.bookingId) {
        conditions.push(eq(messages.bookingId, input.bookingId));
      }
      const msgs = await db.query.messages.findMany({
        where: and(...conditions),
        orderBy: desc(messages.createdAt),
        limit: 100,
        with: { sender: true, receiver: true },
      });
      // Mark as read
      await db.update(messages).set({ isRead: true }).where(
        and(eq(messages.receiverId, ctx.user.id), eq(messages.senderId, input.otherUserId), eq(messages.isRead, false))
      );
      return msgs.reverse();
    }),

  getConversations: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    // Get distinct conversation partners with latest message
    const allMessages = await db.query.messages.findMany({
      where: or(eq(messages.senderId, ctx.user.id), eq(messages.receiverId, ctx.user.id)),
      orderBy: desc(messages.createdAt),
      with: { sender: true, receiver: true },
    });
    const partnerMap = new Map<number, typeof allMessages[0]>();
    for (const msg of allMessages) {
      const partnerId = msg.senderId === ctx.user.id ? msg.receiverId : msg.senderId;
      if (!partnerMap.has(partnerId)) {
        partnerMap.set(partnerId, msg);
      }
    }
    return Array.from(partnerMap.entries()).map(([partnerId, lastMsg]) => ({ partnerId, lastMsg }));
  }),

  getUnreadCount: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const count = await db.select({ count: sql<number>`count(*)` }).from(messages)
      .where(and(eq(messages.receiverId, ctx.user.id), eq(messages.isRead, false)));
    return count[0]?.count || 0;
  }),
});

export const notificationRouter = createRouter({
  getUnreadCount: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const count = await db.select({ count: sql<number>`count(*)` }).from(notifications)
      .where(and(eq(notifications.userId, ctx.user.id), eq(notifications.isRead, false)));
    return count[0]?.count || 0;
  }),
});
