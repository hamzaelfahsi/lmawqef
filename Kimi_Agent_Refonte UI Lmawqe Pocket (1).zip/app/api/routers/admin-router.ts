import { eq, and, desc, sql } from "drizzle-orm";
import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  users, services, bookings, payments, contactMessages,
  levels, badges, commissions, appConfigs, categories,
} from "@db/schema";

export const adminRouter = createRouter({
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [workerCount] = await db.select({ count: sql<number>`count(*)` }).from(users).where(sql`${users.accountType} IN ('worker', 'enterprise', 'auto_entrepreneur', 'freelance')`);
    const [serviceCount] = await db.select({ count: sql<number>`count(*)` }).from(services);
    const [bookingCount] = await db.select({ count: sql<number>`count(*)` }).from(bookings);
    const [revenue] = await db.select({ total: sql<number>`COALESCE(SUM(${payments.amount}), 0)` }).from(payments).where(eq(payments.status, "completed"));
    const [pendingCommission] = await db.select({ total: sql<number>`COALESCE(SUM(${commissions.amount}), 0)` }).from(commissions).where(eq(commissions.status, "pending"));
    const [contactUnread] = await db.select({ count: sql<number>`count(*)` }).from(contactMessages).where(eq(contactMessages.isRead, false));
    const recentUsers = await db.query.users.findMany({ orderBy: desc(users.createdAt), limit: 5 });
    const recentBookings = await db.query.bookings.findMany({ orderBy: desc(bookings.createdAt), limit: 5, with: { client: true, worker: true } });
    const recentPayments = await db.query.payments.findMany({ orderBy: desc(payments.createdAt), limit: 5, with: { user: true } });

    return {
      counts: { users: userCount?.count || 0, workers: workerCount?.count || 0, services: serviceCount?.count || 0, bookings: bookingCount?.count || 0 },
      revenue: revenue?.total || 0,
      pendingCommission: pendingCommission?.total || 0,
      contactUnread: contactUnread?.count || 0,
      recentUsers,
      recentBookings,
      recentPayments,
    };
  }),

  listUsers: adminQuery
    .input(z.object({ search: z.string().optional(), role: z.string().optional(), limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.search) conditions.push(sql`(${users.name} LIKE ${`%${input.search}%`} OR ${users.email} LIKE ${`%${input.search}%`})`);
      if (input.role) conditions.push(eq(users.role, input.role as any));
      return db.query.users.findMany({
        where: conditions.length ? and(...conditions) : undefined,
        limit: input.limit,
        offset: input.offset,
        orderBy: desc(users.createdAt),
      });
    }),

  updateUserRole: adminQuery
    .input(z.object({ id: z.number(), role: z.enum(["user", "admin", "superadmin"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(users).set({ role: input.role }).where(eq(users.id, input.id));
      return { success: true };
    }),

  verifyWorker: adminQuery
    .input(z.object({ id: z.number(), isVerified: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(users).set({ isVerified: input.isVerified }).where(eq(users.id, input.id));
      return { success: true };
    }),

  // Contact messages
  listContactMessages: adminQuery.query(async () => {
    const db = getDb();
    return db.query.contactMessages.findMany({ orderBy: desc(contactMessages.createdAt) });
  }),

  markContactRead: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(contactMessages).set({ isRead: true }).where(eq(contactMessages.id, input.id));
      return { success: true };
    }),

  // Config
  getConfig: adminQuery
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const cfg = await db.query.appConfigs.findFirst({ where: eq(appConfigs.key, input.key) });
      return cfg;
    }),

  setConfig: adminQuery
    .input(z.object({ key: z.string(), value: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.query.appConfigs.findFirst({ where: eq(appConfigs.key, input.key) });
      if (existing) {
        await db.update(appConfigs).set({ value: input.value, updatedAt: new Date() }).where(eq(appConfigs.id, existing.id));
      } else {
        await db.insert(appConfigs).values({ key: input.key, value: input.value });
      }
      return { success: true };
    }),

  // Commissions
  listCommissions: adminQuery.query(async () => {
    const db = getDb();
    return db.query.commissions.findMany({ orderBy: desc(commissions.createdAt), with: { worker: true, booking: true } });
  }),

  markCommissionPaid: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(commissions).set({ status: "paid", paidAt: new Date() }).where(eq(commissions.id, input.id));
      return { success: true };
    }),

  // Levels & Badges
  createLevel: adminQuery
    .input(z.object({ name: z.string().min(1), slug: z.string().min(1), minPoints: z.number(), maxPoints: z.number(), color: z.string(), icon: z.string().optional(), benefits: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(levels).values(input);
      return { success: true };
    }),

  createBadge: adminQuery
    .input(z.object({ name: z.string().min(1), slug: z.string().min(1), description: z.string().min(1), conditionType: z.enum(["bookings_count", "rating", "reviews_count", "services_count", "points", "featured", "insurance", "urgent_jobs"]), conditionValue: z.number(), pointsReward: z.number().optional(), color: z.string().optional(), icon: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(badges).values(input);
      return { success: true };
    }),

  seedDefaults: adminQuery.mutation(async () => {
    const db = getDb();
    // Seed levels
    const existingLevels = await db.query.levels.findMany();
    if (existingLevels.length === 0) {
      await db.insert(levels).values([
        { name: "Novice", slug: "novice", minPoints: 0, maxPoints: 99, color: "#CD7F32", icon: "seedling" },
        { name: "Apprenti", slug: "apprenti", minPoints: 100, maxPoints: 499, color: "#C0C0C0", icon: "hammer" },
        { name: "Artisan", slug: "artisan", minPoints: 500, maxPoints: 1499, color: "#FFD700", icon: "star" },
        { name: "Expert", slug: "expert", minPoints: 1500, maxPoints: 4999, color: "#4ECDC4", icon: "crown" },
        { name: "Maître", slug: "maitre", minPoints: 5000, maxPoints: 9999, color: "#E74C3C", icon: "trophy" },
        { name: "Légende", slug: "legende", minPoints: 10000, maxPoints: 999999, color: "#9B59B6", icon: "gem" },
      ]);
    }
    // Seed badges
    const existingBadges = await db.query.badges.findMany();
    if (existingBadges.length === 0) {
      await db.insert(badges).values([
        { name: "Premier Client", slug: "premier-client", description: "Avoir 1 réservation complétée", conditionType: "bookings_count", conditionValue: 1, pointsReward: 10, color: "#3498db", icon: "handshake" },
        { name: "Artisan Confirmé", slug: "artisan-confirme", description: "Avoir 10 réservations complétées", conditionType: "bookings_count", conditionValue: 10, pointsReward: 50, color: "#2ecc71", icon: "badge-check" },
        { name: "Top Rated", slug: "top-rated", description: "Avoir une note moyenne de 4.5+", conditionType: "rating", conditionValue: 5, pointsReward: 100, color: "#f1c40f", icon: "star" },
        { name: "Expert Recommandé", slug: "expert-recommande", description: "Avoir 20 avis positifs", conditionType: "reviews_count", conditionValue: 20, pointsReward: 75, color: "#e67e22", icon: "thumbs-up" },
        { name: "Super Prestataire", slug: "super-prestataire", description: "Avoir 5 services actifs", conditionType: "services_count", conditionValue: 5, pointsReward: 30, color: "#9b59b6", icon: "briefcase" },
        { name: "Urgencier", slug: "urgencier", description: "Compléter 5 services urgents", conditionType: "urgent_jobs", conditionValue: 5, pointsReward: 60, color: "#e74c3c", icon: "zap" },
      ]);
    }
    // Seed categories
    const existingCats = await db.query.categories.findMany();
    if (existingCats.length === 0) {
      await db.insert(categories).values([
        { name: "Plomberie", slug: "plomberie", icon: "droplet", color: "#3498db", displayOrder: 1 },
        { name: "Électricité", slug: "electricite", icon: "zap", color: "#f1c40f", displayOrder: 2 },
        { name: "Menuiserie", slug: "menuiserie", icon: "trees", color: "#8B4513", displayOrder: 3 },
        { name: "Peinture", slug: "peinture", icon: "paintbrush", color: "#e74c3c", displayOrder: 4 },
        { name: "Jardinage", slug: "jardinage", icon: "leaf", color: "#2ecc71", displayOrder: 5 },
        { name: "Nettoyage", slug: "nettoyage", icon: "sparkles", color: "#1abc9c", displayOrder: 6 },
        { name: "Déménagement", slug: "demenagement", icon: "truck", color: "#e67e22", displayOrder: 7 },
        { name: "Informatique", slug: "informatique", icon: "laptop", color: "#9b59b6", displayOrder: 8 },
        { name: "Climatisation", slug: "climatisation", icon: "wind", color: "#00bcd4", displayOrder: 9 },
        { name: "Construction", slug: "construction", icon: "hard-hat", color: "#795548", displayOrder: 10 },
      ]);
    }
    return { success: true };
  }),
});

