import { Link } from "react-router";
import { MapPin, Phone, Mail, Instagram, Facebook } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="container py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 font-bold text-xl text-white mb-4">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0D9488] to-[#14B8A6] flex items-center justify-center text-white text-sm">L</div>
            Lmawqef Pocket
          </div>
          <p className="text-sm text-slate-400">
            La plateforme de confiance qui connecte les clients avec les meilleurs professionnels au Maroc.
          </p>
        </div>
        <div>
          <h4 className="font-semibold text-white mb-4">Liens rapides</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/marketplace" className="hover:text-[#14B8A6] transition-colors">Services</Link></li>
            <li><Link to="/workers" className="hover:text-[#14B8A6] transition-colors">Professionnels</Link></li>
            <li><Link to="/annonces" className="hover:text-[#14B8A6] transition-colors">Annonces</Link></li>
            <li><Link to="/abonnements" className="hover:text-[#14B8A6] transition-colors">Abonnements</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-white mb-4">Support</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/contact" className="hover:text-[#14B8A6] transition-colors">Contact</Link></li>
            <li><Link to="/insurance" className="hover:text-[#14B8A6] transition-colors">Lmawqef Protect</Link></li>
            <li><Link to="/faq" className="hover:text-[#14B8A6] transition-colors">FAQ</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-white mb-4">Contact</h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center gap-2"><MapPin className="w-4 h-4" /> Casablanca, Maroc</li>
            <li className="flex items-center gap-2"><Phone className="w-4 h-4" /> +212 5XX-XXXXXX</li>
            <li className="flex items-center gap-2"><Mail className="w-4 h-4" /> contact@lmawqef.ma</li>
          </ul>
          <div className="flex gap-3 mt-4">
            <a href="#" className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"><Instagram className="w-4 h-4" /></a>
            <a href="#" className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"><Facebook className="w-4 h-4" /></a>
          </div>
        </div>
      </div>
      <div className="border-t border-slate-800 py-6 text-center text-sm text-slate-500">
        © 2025 Lmawqef Pocket. Tous droits réservés.
      </div>
    </footer>
  );
}
