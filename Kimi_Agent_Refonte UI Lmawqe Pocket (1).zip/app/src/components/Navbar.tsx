import { Link, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, MessageSquare, Bell, Shield, Crown, User } from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const { data: unreadMessages } = trpc.message.getUnreadCount.useQuery(undefined, { enabled: isAuthenticated });
  const { data: unreadNotifications } = trpc.notification.getUnreadCount.useQuery(undefined, { enabled: isAuthenticated });

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-bold text-xl text-[#0D9488]">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0D9488] to-[#14B8A6] flex items-center justify-center text-white text-sm">L</div>
          Lmawqef Pocket
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <Link to="/marketplace" className="hover:text-[#0D9488] transition-colors">Services</Link>
          <Link to="/workers" className="hover:text-[#0D9488] transition-colors">Professionnels</Link>
          <Link to="/annonces" className="hover:text-[#0D9488] transition-colors">Annonces</Link>
          <Link to="/abonnements" className="hover:text-[#0D9488] transition-colors">Abonnements</Link>
          <Link to="/leaderboard" className="hover:text-[#0D9488] transition-colors">Classement</Link>
        </nav>

        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <button onClick={() => navigate("/messages")} className="relative p-2 rounded-lg hover:bg-slate-100">
                <MessageSquare className="w-5 h-5 text-slate-600" />
                {!!unreadMessages && <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">{unreadMessages}</span>}
              </button>
              <button onClick={() => navigate("/notifications")} className="relative p-2 rounded-lg hover:bg-slate-100">
                <Bell className="w-5 h-5 text-slate-600" />
                {!!unreadNotifications && <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">{unreadNotifications}</span>}
              </button>
              {user?.role === "admin" || user?.role === "superadmin" ? (
                <button onClick={() => navigate("/admin")} className="p-2 rounded-lg hover:bg-slate-100">
                  <Shield className="w-5 h-5 text-slate-600" />
                </button>
              ) : null}
              <button onClick={() => navigate("/dashboard")} className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100">
                {user?.avatar ? <img src={user.avatar} className="w-7 h-7 rounded-full" alt="" /> : <User className="w-5 h-5" />}
                <span className="text-sm font-medium text-slate-700">{user?.name || "Profil"}</span>
                {user?.isFeatured && <Crown className="w-4 h-4 text-amber-500" />}
              </button>
              <Button variant="ghost" size="sm" onClick={logout}>Déconnexion</Button>
            </>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate("/login")}>Connexion</Button>
              <Button size="sm" className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate("/register")}>Inscription</Button>
            </>
          )}
        </div>

        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon"><Menu className="w-5 h-5" /></Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72">
            <div className="flex flex-col gap-4 mt-6">
              <Link to="/marketplace" className="text-sm font-medium text-slate-700">Services</Link>
              <Link to="/workers" className="text-sm font-medium text-slate-700">Professionnels</Link>
              <Link to="/annonces" className="text-sm font-medium text-slate-700">Annonces</Link>
              <Link to="/abonnements" className="text-sm font-medium text-slate-700">Abonnements</Link>
              <Link to="/leaderboard" className="text-sm font-medium text-slate-700">Classement</Link>
              {isAuthenticated ? (
                <>
                  <Link to="/dashboard" className="text-sm font-medium text-slate-700">Dashboard</Link>
                  <Link to="/messages" className="text-sm font-medium text-slate-700">Messages {unreadMessages ? `(${unreadMessages})` : ""}</Link>
                  <Link to="/notifications" className="text-sm font-medium text-slate-700">Notifications {unreadNotifications ? `(${unreadNotifications})` : ""}</Link>
                  <Button variant="ghost" onClick={logout}>Déconnexion</Button>
                </>
              ) : (
                <>
                  <Button variant="ghost" onClick={() => navigate("/login")}>Connexion</Button>
                  <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate("/register")}>Inscription</Button>
                </>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
