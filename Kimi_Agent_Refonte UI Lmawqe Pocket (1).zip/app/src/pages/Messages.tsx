import { useState, useEffect, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Send, ArrowLeft } from "lucide-react";

export default function Messages() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const selectedUserId = searchParams.get("user");
  const [newMessage, setNewMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: conversations } = trpc.message.getConversations.useQuery();
  const { data: messages, refetch } = trpc.message.getConversation.useQuery(
    { otherUserId: Number(selectedUserId) },
    { enabled: !!selectedUserId }
  );

  const sendMessage = trpc.message.sendMessage.useMutation({
    onSuccess: () => {
      setNewMessage("");
      refetch();
    },
  });

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  // Polling
  useEffect(() => {
    if (!selectedUserId) return;
    const interval = setInterval(() => refetch(), 3000);
    return () => clearInterval(interval);
  }, [selectedUserId, refetch]);

  if (!user) return <div className="container py-20 text-center">Connectez-vous pour accéder aux messages.</div>;

  return (
    <div className="container py-8 h-[calc(100vh-8rem)]">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full">
        <Card className="md:col-span-1 overflow-hidden flex flex-col">
          <CardContent className="p-4 flex-1 overflow-auto">
            <h2 className="font-bold text-lg mb-4">Conversations</h2>
            <div className="space-y-2">
              {conversations?.map((conv) => {
                const partner = conv.lastMsg.senderId === user.id ? conv.lastMsg.receiver : conv.lastMsg.sender;
                return (
                  <div
                    key={conv.partnerId}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${String(conv.partnerId) === selectedUserId ? "bg-teal-50 border border-[#0D9488]" : "hover:bg-slate-50"}`}
                    onClick={() => navigate(`/messages?user=${conv.partnerId}`)}
                  >
                    <div className="font-medium text-sm">{partner?.name || "Utilisateur"}</div>
                    <div className="text-xs text-slate-500 truncate">{conv.lastMsg.content}</div>
                  </div>
                );
              }) || <p className="text-sm text-slate-500">Aucune conversation.</p>}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 overflow-hidden flex flex-col">
          {selectedUserId ? (
            <>
              <div className="p-4 border-b flex items-center gap-3">
                <button onClick={() => navigate("/messages")} className="md:hidden"><ArrowLeft className="w-5 h-5" /></button>
                <div className="font-semibold">
                  {messages?.[0]?.senderId === user.id ? messages[0]?.receiver?.name : messages?.[0]?.sender?.name}
                </div>
              </div>
              <div className="flex-1 overflow-auto p-4 space-y-3" ref={scrollRef}>
                {messages?.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.senderId === user.id ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[70%] px-4 py-2 rounded-2xl text-sm ${msg.senderId === user.id ? "bg-[#0D9488] text-white" : "bg-slate-100 text-slate-900"}`}>
                      {msg.content}
                      <div className={`text-[10px] mt-1 ${msg.senderId === user.id ? "text-teal-100" : "text-slate-400"}`}>
                        {new Date(msg.createdAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                  </div>
                )) || <p className="text-center text-slate-400 mt-10">Démarrez la conversation...</p>}
              </div>
              <div className="p-4 border-t flex gap-2">
                <Input placeholder="Écrivez un message..." value={newMessage} onChange={(e) => setNewMessage(e.target.value)} onKeyDown={(e) => e.key === "Enter" && newMessage.trim() && sendMessage.mutate({ receiverId: Number(selectedUserId), content: newMessage })} />
                <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white" disabled={!newMessage.trim() || sendMessage.isPending} onClick={() => sendMessage.mutate({ receiverId: Number(selectedUserId), content: newMessage })}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              Sélectionnez une conversation pour commencer
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
