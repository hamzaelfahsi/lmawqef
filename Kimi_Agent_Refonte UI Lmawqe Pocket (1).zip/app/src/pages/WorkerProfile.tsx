import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, Shield, Crown, MessageSquare, Award } from "lucide-react";

export default function WorkerProfile() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("services");
  const { data: profile } = trpc.user.getProfile.useQuery({ id: Number(id) });
  const { data: services } = trpc.service.listServices.useQuery({ limit: 50 });
  const { data: availability } = trpc.user.getAvailability.useQuery({ userId: Number(id) });

  if (!profile) return <div className="container py-20 text-center">Chargement...</div>;

  const workerServices = services?.filter((s) => s.workerId === profile.id) || [];
  const days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

  return (
    <div className="container py-8">
      <div className="h-32 md:h-48 rounded-2xl bg-gradient-to-r from-[#0D9488] to-[#14B8A6] mb-16 relative" />
      <div className="relative -mt-24 mb-8 flex flex-col md:flex-row items-start md:items-end gap-6 px-4">
        <div className="w-28 h-28 rounded-full bg-white p-1 shadow-lg">
          {profile.avatar ? (
            <img src={profile.avatar} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            <div className="w-full h-full rounded-full bg-slate-200 flex items-center justify-center text-3xl font-bold text-slate-500">
              {profile.name?.charAt(0) || "?"}
            </div>
          )}
        </div>
        <div className="flex-1 pb-2">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl md:text-3xl font-bold">{profile.name}</h1>
            {profile.isVerified && <Shield className="w-6 h-6 text-[#0D9488]" />}
            {profile.isFeatured && <Crown className="w-6 h-6 text-amber-500" />}
          </div>
          <p className="text-slate-500">{profile.profession} • {profile.city}</p>
          <div className="flex items-center gap-4 mt-2 text-sm">
            <span className="flex items-center gap-1 text-amber-500 font-medium"><Star className="w-4 h-4 fill-current" /> {profile.rating}</span>
            <span>{profile.reviewCount} avis</span>
            <span>{profile.completedJobs} missions</span>
            {profile.level && (
              <span className="flex items-center gap-1 text-[#0D9488]"><Award className="w-4 h-4" /> {profile.level.name}</span>
            )}
          </div>
        </div>
        <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={() => navigate(`/messages?user=${profile.id}`)}>
          <MessageSquare className="w-4 h-4 mr-2" /> Contacter
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
        <TabsList className="bg-slate-100">
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="availability">Disponibilités</TabsTrigger>
          <TabsTrigger value="badges">Badges</TabsTrigger>
        </TabsList>
        <TabsContent value="services" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {workerServices.map((service) => (
              <Card key={service.id} className="cursor-pointer hover:shadow-lg transition-all" onClick={() => navigate(`/service/${service.id}`)}>
                <div className="h-40 bg-slate-200 relative">
                  {service.images?.[0] ? (
                    <img src={service.images[0].imageUrl} alt="" className="w-full h-full object-cover" />
                  ) : <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">Pas d'image</div>}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold">{service.title}</h3>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold">{service.price} MAD</span>
                    <span className="text-xs text-slate-500">{service.city}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="portfolio" className="mt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {profile.portfolioItems?.map((item) => (
              <div key={item.id} className="rounded-xl overflow-hidden bg-slate-200 aspect-square relative group">
                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-sm font-medium">
                  {item.title}
                </div>
              </div>
            )) || <p className="text-slate-500">Aucun portfolio pour le moment.</p>}
          </div>
        </TabsContent>
        <TabsContent value="availability" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {availability?.map((slot) => (
              <Card key={slot.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <div className="font-semibold">{days[slot.dayOfWeek]}</div>
                    <div className="text-sm text-slate-500">{slot.startTime} - {slot.endTime}</div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-medium ${slot.isAvailable ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                    {slot.isAvailable ? "Disponible" : "Indisponible"}
                  </div>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucune disponibilité configurée.</p>}
          </div>
        </TabsContent>
        <TabsContent value="badges" className="mt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {profile.userBadges?.map((ub) => (
              <Card key={ub.badge.id}>
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center text-white" style={{ backgroundColor: ub.badge.color }}>
                    <Award className="w-6 h-6" />
                  </div>
                  <div className="font-semibold text-sm">{ub.badge.name}</div>
                  <div className="text-xs text-slate-500">+{ub.badge.pointsReward} pts</div>
                </CardContent>
              </Card>
            )) || <p className="text-slate-500">Aucun badge pour le moment.</p>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
