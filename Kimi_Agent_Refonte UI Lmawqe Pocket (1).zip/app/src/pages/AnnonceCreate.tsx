import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { ArrowLeft, Zap, DollarSign } from "lucide-react";

export default function AnnonceCreate() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [form, setForm] = useState({ title: "", description: "", categoryId: "", city: "", budget: "", isUrgent: false });
  const { data: categories } = trpc.service.listCategories.useQuery();
  const utils = trpc.useUtils();
  const createMutation = trpc.annonce.createAnnonce.useMutation({
    onSuccess: (data) => {
      if (data.needsPayment) {
        navigate("/payment?type=annonce&id=" + data.id);
      } else {
        utils.annonce.listMyAnnonces.invalidate();
        navigate("/annonces");
      }
    },
  });

  if (!isAuthenticated) return <div className="container py-20 text-center">Connectez-vous pour publier une annonce.</div>;

  return (
    <div className="container py-8 max-w-2xl">
      <button onClick={() => navigate("/annonces")} className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 mb-6">
        <ArrowLeft className="w-4 h-4" /> Retour
      </button>
      <Card>
        <CardHeader>
          <CardTitle>Publier une annonce</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Titre</Label>
            <Input placeholder="Ex: Cherche plombier urgent..." value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea placeholder="Décrivez votre besoin en détail..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Catégorie</Label>
              <Select value={form.categoryId} onValueChange={(v) => setForm({ ...form, categoryId: v })}>
                <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                <SelectContent>
                  {categories?.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Ville</Label>
              <Input placeholder="Casablanca" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Budget (MAD)</Label>
              <Input type="number" placeholder="500" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} />
            </div>
            <div className="flex items-center gap-2 pt-6">
              <input type="checkbox" id="urgent" checked={form.isUrgent} onChange={(e) => setForm({ ...form, isUrgent: e.target.checked })} className="w-4 h-4" />
              <Label htmlFor="urgent" className="flex items-center gap-1 text-red-500 cursor-pointer"><Zap className="w-4 h-4" /> Service urgent</Label>
            </div>
          </div>
          <div className="bg-amber-50 p-3 rounded-lg text-sm text-amber-700 flex items-center gap-2">
            <DollarSign className="w-4 h-4" /> Les 5 premières annonces sont gratuites. Ensuite 20 MAD par annonce.
          </div>
          <Button className="w-full bg-[#0D9488] hover:bg-[#0F766E] text-white" disabled={createMutation.isPending} onClick={() => createMutation.mutate({ title: form.title, description: form.description, categoryId: Number(form.categoryId), city: form.city, budget: form.budget ? Number(form.budget) : undefined, isUrgent: form.isUrgent })}>
            {createMutation.isPending ? "Publication..." : "Publier l'annonce"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
