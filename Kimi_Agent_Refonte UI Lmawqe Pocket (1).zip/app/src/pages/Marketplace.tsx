import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, MapPin, Star, Zap } from "lucide-react";

export default function Marketplace() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [city, setCity] = useState(searchParams.get("city") || "");
  const [categoryId, setCategoryId] = useState(searchParams.get("category") || "all");

  const { data: categories } = trpc.service.listCategories.useQuery();
  const { data: services } = trpc.service.listServices.useQuery({
    search: search || undefined,
    city: city || undefined,
    categoryId: categoryId && categoryId !== "all" ? parseInt(categoryId) : undefined,
    limit: 24,
  });

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (city) params.set("city", city);
    if (categoryId && categoryId !== "all") params.set("category", categoryId);
    setSearchParams(params);
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Marketplace des services</h1>
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
          <Input className="pl-10" placeholder="Rechercher un service..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="w-full md:w-48 relative">
          <MapPin className="absolute left-3 top-2.5 w-5 h-5 text-slate-400" />
          <Input className="pl-10" placeholder="Ville" value={city} onChange={(e) => setCity(e.target.value)} />
        </div>
        <div className="w-full md:w-48">
          <Select value={categoryId} onValueChange={setCategoryId}>
            <SelectTrigger><SelectValue placeholder="Catégorie" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les catégories</SelectItem>
              {categories?.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button className="bg-[#0D9488] hover:bg-[#0F766E] text-white" onClick={handleSearch}>Rechercher</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {services?.map((service) => (
          <Card key={service.id} className="overflow-hidden hover:shadow-lg transition-all cursor-pointer" onClick={() => navigate(`/service/${service.id}`)}>
            <div className="h-40 bg-slate-200 relative">
              {service.images?.[0] ? (
                <img src={service.images[0].imageUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-400">Pas d'image</div>
              )}
              {service.isUrgent && (
                <div className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                  <Zap className="w-3 h-3" /> Urgent
                </div>
              )}
            </div>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-[#0D9488] bg-teal-50 px-2 py-1 rounded">{service.category?.name}</span>
                <span className="text-xs text-slate-400">{service.city}</span>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2 line-clamp-1">{service.title}</h3>
              <div className="flex items-center justify-between">
                <span className="font-bold text-lg text-slate-900">{service.price} MAD</span>
                <span className="text-xs text-slate-500">{service.priceType === "hourly" ? "/heure" : service.priceType === "quote" ? "Sur devis" : "fixe"}</span>
              </div>
              <div className="flex items-center gap-2 mt-3 pt-3 border-t">
                <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold">
                  {service.worker?.name?.charAt(0) || "?"}
                </div>
                <span className="text-sm text-slate-600">{service.worker?.name}</span>
                {service.worker?.rating && (
                  <span className="ml-auto flex items-center gap-1 text-xs text-amber-500 font-medium">
                    <Star className="w-3 h-3 fill-current" /> {service.worker.rating}
                  </span>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
