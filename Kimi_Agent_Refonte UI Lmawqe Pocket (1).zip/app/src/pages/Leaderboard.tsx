import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award, Crown, Star } from "lucide-react";

const rankIcons = [Trophy, Medal, Award];
const rankColors = ["#FFD700", "#C0C0C0", "#CD7F32"];

export default function Leaderboard() {
  const { data: leaders } = trpc.user.getLeaderboard.useQuery({ limit: 20 });

  return (
    <div className="container py-8 max-w-3xl">
      <h1 className="text-3xl font-bold text-center mb-2">Classement des professionnels</h1>
      <p className="text-center text-slate-500 mb-8">Les meilleurs prestataires du mois selon points et réputation</p>

      <div className="space-y-3">
        {leaders?.map((user, index) => {
          const RankIcon = rankIcons[index] || Star;
          const color = rankColors[index] || "#0D9488";
          return (
            <Card key={user.id} className={`overflow-hidden ${index < 3 ? "border-l-4" : ""}`} style={{ borderLeftColor: index < 3 ? color : "transparent" }}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shrink-0" style={{ backgroundColor: color }}>
                  {index < 3 ? <RankIcon className="w-5 h-5" /> : index + 1}
                </div>
                <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-sm shrink-0">
                  {user.name?.charAt(0) || "?"}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold truncate">{user.name}</span>
                    {user.isFeatured && <Crown className="w-4 h-4 text-amber-500 shrink-0" />}
                  </div>
                  <div className="text-sm text-slate-500">{user.profession} • {user.city}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-bold text-[#0D9488]">{user.points} pts</div>
                  <div className="text-xs text-slate-400">{user.completedJobs} jobs</div>
                </div>
                {user.level && (
                  <Badge style={{ backgroundColor: user.level.color + "20", color: user.level.color, borderColor: user.level.color }} variant="outline">
                    {user.level.name}
                  </Badge>
                )}
              </CardContent>
            </Card>
          );
        }) || <p className="text-center text-slate-500 py-10">Aucun professionnel enregistré.</p>}
      </div>
    </div>
  );
}
