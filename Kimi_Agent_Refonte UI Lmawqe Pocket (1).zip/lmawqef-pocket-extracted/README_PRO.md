# Lmawqef Pocket PRO

## Nouvelles fonctionnalites PRO

### 1. Chat en temps reel
- Interface de messagerie avec liste de conversations
- Messages instantanes avec polling (3 secondes)
- Notifications automatiques pour nouveaux messages
- Indicateurs de lecture

### 2. Systeme d'Annonces Payantes
- 3 types : Recrutement, Demande de service, Offre de service
- 20 MAD par annonce
- 5 annonces gratuites pour les nouveaux utilisateurs
- Duree de 30 jours par defaut (configurable par admin)
- Upload d'images pour les annonces

### 3. Abonnements PRO
- Plans pour Entreprises (illimite ou limite)
- Plans pour Auto-Entrepreneurs (100 annonces/mois)
- Plans pour Freelances (20-50 annonces/mois)
- Paiement en ligne simule (CMI compatible)
- Activation automatique apres paiement

### 4. Upload d'Images
- Photo de profil
- Portfolio professionnel (plusieurs images)
- Images de services (plusieurs par service)
- Images d'annonces

### 5. Geolocalisation
- Detection automatique de position (GPS)
- Champs latitude/longitude dans le profil
- Pret pour integration Google Maps

### 6. Notifications System
- Notifications pour reservations, messages, avis
- Badge de compteur en temps reel
- Page dediee pour l'historique des notifications

### 7. Dashboards Professionnels
- **Worker** : Stats, graphiques, reservations, revenus
- **Entreprise** : Gestion des employes, services, annonces
- **Client** : Reservations, favoris, historique

### 8. Panel Admin Avance
- Dashboard avec statistiques globales
- Gestion des utilisateurs (activer/desactiver/admin)
- Gestion des services et annonces
- Gestion des abonnements et plans
- Gestion des paiements et revenus
- Configuration des parametres (prix, annonces gratuites, duree)
- Gestion des droits administrateurs (permissions granulaires)
- Gestion multi-admin avec differents niveaux d'acces

### 9. Inscription Professionnelle
- **Entreprise** : Nom societe, RC, ICE
- **Auto-Entrepreneur** : Statut, competences
- **Freelance** : Portfolio, competences

### 10. Paiement en Ligne
- Simulation de paiement CMI (Carte bancaire, mobile money, virement)
- Reference unique par transaction
- Historique des paiements dans l'admin

## Installation

1. Extraire le ZIP
2. Installer les dependances : `pip install flask flask-sqlalchemy werkzeug`
3. Lancer l'application : `python app.py`
4. Ouvrir http://localhost:5000

## Connexion par defaut
- Admin : username `admin`, password `admin123`
- La base de donnees SQLite est creee automatiquement

## Configuration Admin
- Le premier admin peut acceder au panel et configurer :
  - Prix des annonces (defaut: 20 MAD)
  - Nombre d'annonces gratuites (defaut: 5)
  - Duree des annonces (defaut: 30 jours)
  - Plans d'abonnement
  - Droits des autres administrateurs
