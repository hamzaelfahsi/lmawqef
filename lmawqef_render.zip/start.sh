#!/bin/bash
# Script de démarrage rapide Lmawqef Pocket

echo "=========================================="
echo "  Lmawqef Pocket - Démarrage rapide"
echo "=========================================="

# Vérifier Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 n'est pas installé. Veuillez l'installer d'abord."
    exit 1
fi

# Créer l'environnement virtuel s'il n'existe pas
if [ ! -d "venv" ]; then
    echo "📦 Création de l'environnement virtuel..."
    python3 -m venv venv
fi

# Activer l'environnement virtuel
echo "🔌 Activation de l'environnement virtuel..."
source venv/bin/activate

# Installer les dépendances
echo "📥 Installation des dépendances..."
pip install -q -r requirements.txt

# Créer les dossiers nécessaires
mkdir -p instance uploads

# Lancer l'application
echo "🚀 Lancement de Lmawqef Pocket..."
echo "   URL: http://localhost:5000"
echo "   Admin: admin@lmawqef.ma / admin123"
echo "   Client: client@lmawqef.ma / client123"
echo "   Worker: worker@lmawqef.ma / worker123"
echo "=========================================="

python run.py
