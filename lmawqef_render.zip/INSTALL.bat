@echo off
chcp 65001 >nul
cls
echo ==========================================
echo   Lmawqef Pocket - Installation Windows
echo ==========================================
echo.

REM Verifier Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python n'est pas trouve !
    echo    Verifiez que Python est installe et ajoute au PATH.
    pause
    exit /b 1
)

echo ✅ Python detecte :
python --version
echo.

REM Crer l'environnement virtuel
if not exist "venv" (
    echo 📦 Creation de l'environnement virtuel...
    python -m venv venv
    if errorlevel 1 (
        echo ❌ Erreur lors de la creation du venv
        pause
        exit /b 1
    )
    echo ✅ Environnement virtuel cree
) else (
    echo ℹ️  Environnement virtuel deja present
)
echo.

REM Activer l'environnement virtuel
echo 🔌 Activation de l'environnement virtuel...
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo ❌ Erreur lors de l'activation du venv
    echo    Essayez de lancer ce script en tant qu'administrateur
    pause
    exit /b 1
)
echo ✅ Environnement active
echo.

REM Creer les dossiers necessaires
if not exist "instance" mkdir instance
if not exist "instance\uploads" mkdir instance\uploads
if not exist "app\static\icons" mkdir app\static\icons
if not exist "app\static\screenshots" mkdir app\static\screenshots
echo ✅ Dossiers crees
echo.

REM Installer les dependances
echo 📥 Installation des dependances (2-3 minutes)...
echo    Ne fermez pas cette fenetre...
pip install --upgrade pip -q
pip install -r requirements.txt
if errorlevel 1 (
    echo ❌ Erreur lors de l'installation des dependances
    pause
    exit /b 1
)
echo ✅ Dependances installees
echo.

REM Lancer l'application
echo ==========================================
echo 🚀 Lancement de Lmawqef Pocket !
echo ==========================================
echo.
echo    📍 Ouvrez votre navigateur et allez sur :
echo    http://localhost:5000
echo.
echo    🔑 Comptes de demo :
echo      Admin    : admin@lmawqef.ma / admin123
echo      Client   : client@lmawqef.ma / client123
echo      Worker   : worker@lmawqef.ma / worker123
echo      Entreprise : enterprise@lmawqef.ma / enterprise123
echo.
echo    ⛔ Pour arreter : appuyez sur Ctrl + C
echo ==========================================
echo.

python run.py

REM Desactiver l'environnement a l'arret
call venv\Scripts\deactivate.bat
pause
