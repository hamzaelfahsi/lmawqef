from app.utils.translations import _

def calculate_match_score(worker, client_city=None, client_budget=None, required_category=None, preferred_date=None):
    """
    Calculate a match score (0-100) for a worker against client requirements.
    Returns dict with score, breakdown, and recommendation level.
    """
    score = 0.0
    breakdown = {}
    
    # 1. Proximity (0-25 points)
    proximity_score = 0
    if client_city and worker.city:
        if client_city.lower() == worker.city.lower():
            proximity_score = 25
        elif client_city.lower() in worker.city.lower() or worker.city.lower() in client_city.lower():
            proximity_score = 15
    else:
        proximity_score = 10  # default if no city info
    score += proximity_score
    breakdown['proximity'] = proximity_score
    
    # 2. Rating (0-25 points)
    rating_score = 0
    avg_rating = worker.average_rating()
    if avg_rating >= 4.5:
        rating_score = 25
    elif avg_rating >= 4.0:
        rating_score = 20
    elif avg_rating >= 3.5:
        rating_score = 15
    elif avg_rating >= 3.0:
        rating_score = 10
    elif avg_rating > 0:
        rating_score = 5
    else:
        rating_score = 8  # New worker with no ratings yet
    score += rating_score
    breakdown['rating'] = rating_score
    
    # 3. Responsiveness (0-20 points)
    resp_score = 0
    # Based on average response time (mock calculation from bookings)
    from app.models import Booking, Service
    services = Service.query.filter_by(worker_id=worker.id).all()
    service_ids = [s.id for s in services]
    if service_ids:
        completed = Booking.query.filter(Booking.service_id.in_(service_ids), Booking.status=='completed').count()
        accepted = Booking.query.filter(Booking.service_id.in_(service_ids), Booking.status=='accepted').count()
    else:
        completed = 0
        accepted = 0
    total = completed + accepted + 1
    acceptance_rate = (completed + accepted) / total
    resp_score = min(20, int(acceptance_rate * 20))
    score += resp_score
    breakdown['responsiveness'] = resp_score
    
    # 4. Category match (0-15 points)
    cat_score = 0
    if required_category:
        from app.models import Service
        has_category = Service.query.filter_by(worker_id=worker.id).filter(
            Service.category.ilike(f'%{required_category}%')
        ).first()
        if has_category:
            cat_score = 15
        else:
            cat_score = 3  # Worker doesn't have exact category but might be related
    else:
        cat_score = 10
    score += cat_score
    breakdown['category_match'] = cat_score
    
    # 5. Price compatibility (0-15 points)
    price_score = 0
    if client_budget:
        # Get worker's average price
        from app.models import Service
        services = Service.query.filter_by(worker_id=worker.id).all()
        if services:
            avg_price = sum(s.price for s in services) / len(services)
            if avg_price <= client_budget:
                price_score = 15
            elif avg_price <= client_budget * 1.2:
                price_score = 10
            elif avg_price <= client_budget * 1.5:
                price_score = 5
            else:
                price_score = 2
        else:
            price_score = 8
    else:
        price_score = 10
    score += price_score
    breakdown['price'] = price_score
    
    # Recommendation level
    if score >= 85:
        level = 'excellent'
    elif score >= 70:
        level = 'good'
    elif score >= 55:
        level = 'average'
    else:
        level = 'low'
    
    return round(score, 1), breakdown
