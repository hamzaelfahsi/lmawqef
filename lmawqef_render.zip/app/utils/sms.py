from flask import current_app
from app.extensions import db
from app.models import SMSLog
import random, string

def send_sms(user, message, template_name=None):
    """Simulated SMS sender. In production, integrate with Twilio, Africa's Talking, or local Moroccan provider."""
    log = SMSLog(
        user_id=user.id,
        phone=user.phone,
        message=message,
        template_name=template_name,
        status='sent',
        provider='simulation',
        external_ref='SIM' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)),
        cost=0.35  # MAD per SMS simulation
    )
    db.session.add(log)
    db.session.commit()
    return {'success': True, 'log_id': log.id, 'external_ref': log.external_ref}

def send_booking_sms(booking, event_type):
    """Send SMS notifications for booking events."""
    templates = {
        'new_request': 'Nouvelle demande de reservation #{bid} sur Lmawqef. Connectez-vous pour la consulter.',
        'accepted': 'Votre reservation #{bid} a ete acceptee. Le prestataire arrivera le {date}.',
        'rejected': 'Votre reservation #{bid} a ete refusee. Trouvez un autre prestataire sur Lmawqef.',
        'reminder': 'Rappel: Votre prestation #{bid} est prevue demain a {time}.',
        'completed': 'Votre prestation #{bid} est terminee. Laissez un avis sur Lmawqef!'
    }
    msg = templates.get(event_type, '').format(
        bid=booking.id,
        date=booking.scheduled_date or '',
        time=booking.scheduled_time or ''
    )
    if not msg:
        return
    # Notify client
    if booking.client and booking.client.phone:
        send_sms(booking.client, msg, template_name=event_type)
    # Notify worker
    if event_type == 'new_request' and booking.service and booking.service.worker and booking.service.worker.phone:
        worker_msg = f"Nouvelle demande de {booking.client.full_name} sur Lmawqef. Reservation #{booking.id}."
        send_sms(booking.service.worker, worker_msg, template_name='new_request_worker')
