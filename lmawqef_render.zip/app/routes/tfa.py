from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.extensions import db
from app.utils.translations import _
from app.utils.helpers import login_required
from app.models import User
import base64, hmac, hashlib, struct, time, secrets, qrcode, io
from flask import Response

tfa_bp = Blueprint('tfa', __name__)

def generate_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode('utf-8')

def get_totp_token(secret, interval=30):
    key = base64.b32decode(secret, casefold=True)
    counter = struct.pack('>Q', int(time.time() // interval))
    mac = hmac.new(key, counter, hashlib.sha1).digest()
    offset = mac[-1] & 0x0f
    code = struct.unpack('>I', mac[offset:offset + 4])[0] & 0x7fffffff
    return str(code)[-6:].zfill(6)

def get_provisioning_uri(secret, email, issuer='Lmawqef'):
    return f'otpauth://totp/{issuer}:{email}?secret={secret}&issuer={issuer}'

@tfa_bp.route('/admin/2fa/setup')
@login_required
def setup_2fa():
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('main.index'))
    if not user.otp_secret:
        user.otp_secret = generate_secret()
        db.session.commit()
    uri = get_provisioning_uri(user.otp_secret, user.email)
    # Generate QR code
    qr = qrcode.make(uri)
    buf = io.BytesIO()
    qr.save(buf, format='PNG')
    buf.seek(0)
    qr_b64 = base64.b64encode(buf.getvalue()).decode()
    return render_template('admin/setup_2fa.html', secret=user.otp_secret, qr_b64=qr_b64)

@tfa_bp.route('/admin/2fa/verify', methods=['POST'])
@login_required
def verify_2fa_setup():
    user = User.query.get(session['user_id'])
    code = request.form.get('code', '')
    if not user.otp_secret or not code:
        flash('Invalid', 'danger')
        return redirect(url_for('tfa.setup_2fa'))
    expected = get_totp_token(user.otp_secret)
    if code == expected:
        user.is_2fa_enabled = True
        db.session.commit()
        flash('2FA enabled successfully', 'success')
        return redirect(url_for('admin.admin_panel'))
    flash('Invalid code', 'danger')
    return redirect(url_for('tfa.setup_2fa'))

@tfa_bp.route('/admin/2fa/disable', methods=['POST'])
@login_required
def disable_2fa():
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('main.index'))
    user.is_2fa_enabled = False
    user.otp_secret = None
    db.session.commit()
    flash('2FA disabled', 'success')
    return redirect(url_for('admin.admin_panel'))
