from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, make_response, abort, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import os, json, random, string, urllib.request, ssl
from app.extensions import db
from app.utils.translations import get_language, set_language, _
from app.utils.helpers import login_required, admin_required, save_uploaded_file
from app.constants import MOROCCAN_CITIES, CATEGORIES
from app.models import (
    User, Service, ServiceImage, PortfolioItem, Review, Booking,
    Commission, Devis, Message, Notification, Annonce, AnnonceOffer, Payment, Invoice,
    SubscriptionPlan, AppConfig, ContactMessage, AdminRole, Level, Badge, UserBadge,
    Availability, Category, WalletTransaction, IdentityVerification, Favorite,
    WorkerLocation, allowed_file
)

services_bp = Blueprint('services', __name__)

@services_bp.route('/services')
def services():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    city = request.args.get('city', '')
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    is_urgent = request.args.get('urgent', '')
    query = Service.query.filter_by(is_active=True)
    if search:
        query = query.filter(db.or_(Service.title.contains(search), Service.description.contains(search)))
    if category: query = query.filter_by(category=category)
    if city: query = query.filter_by(city=city)
    if min_price is not None: query = query.filter(Service.price >= min_price)
    if max_price is not None: query = query.filter(Service.price <= max_price)
    if is_urgent: query = query.filter_by(is_urgent=True)
    services = query.order_by(Service.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('services.html', services=services, search=search, category=category, city=city,
                         min_price=min_price, max_price=max_price, is_urgent=is_urgent,
                         categories=CATEGORIES, cities=MOROCCAN_CITIES)

@services_bp.route('/service/<int:id>')
def service_detail(id):
    service = Service.query.get_or_404(id)
    service.views_count += 1
    db.session.commit()
    reviews = Review.query.filter_by(worker_id=service.worker_id).order_by(Review.created_at.desc()).all()
    related = Service.query.filter(Service.category == service.category, Service.id != service.id).limit(4).all()
    has_booked = False
    if 'user_id' in session:
        has_booked = Booking.query.filter_by(client_id=session['user_id'], service_id=service.id).first() is not None
    return render_template('service_detail.html', service=service, reviews=reviews,
                         related_services=related, has_booked=has_booked)

@services_bp.route('/service/add', methods=['GET', 'POST'])
@login_required
def add_service():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise'] and user.worker_subtype not in ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']:
        flash(_('workers_only'), 'danger')
        return redirect(url_for('main.index'))
    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        description = request.form.get('description')
        price = request.form.get('price')
        city = request.form.get('city')
        address = request.form.get('address')
        is_urgent = request.form.get('is_urgent') == 'on'
        if not all([title, category, description, price, city]):
            flash('All required.', 'danger')
            return redirect(url_for('services.add_service'))
        try: price = float(price)
        except ValueError:
            flash('Invalid price.', 'danger')
            return redirect(url_for('services.add_service'))
        config = AppConfig.get()
        final_price = price * config.urgency_multiplier if is_urgent else price
        # Fiverr-style packages
        basic_price = float(request.form.get('basic_price', price))
        basic_delivery = int(request.form.get('basic_delivery_days', 1) or 1)
        basic_desc = request.form.get('basic_description', '')
        basic_incl = request.form.get('basic_includes', '')
        std_price = float(request.form.get('standard_price', 0) or 0)
        std_delivery = int(request.form.get('standard_delivery_days', 3) or 3)
        std_desc = request.form.get('standard_description', '')
        std_incl = request.form.get('standard_includes', '')
        prem_price = float(request.form.get('premium_price', 0) or 0)
        prem_delivery = int(request.form.get('premium_delivery_days', 7) or 7)
        prem_desc = request.form.get('premium_description', '')
        prem_incl = request.form.get('premium_includes', '')
        active_pkg = request.form.get('active_package', 'basic')
        # FAQ & Tags
        gig_tags = request.form.get('gig_tags', '')
        gig_faq = request.form.get('gig_faq', '')
        video_url = request.form.get('video_url', '')
        requirements = request.form.get('requirements', '')

        service = Service(title=title, category=category, description=description,
                        price=final_price, city=city, worker_id=session['user_id'],
                        address=address, is_urgent=is_urgent,
                        basic_price=basic_price, basic_delivery_days=basic_delivery,
                        basic_description=basic_desc, basic_includes=basic_incl,
                        standard_price=std_price, standard_delivery_days=std_delivery,
                        standard_description=std_desc, standard_includes=std_incl,
                        premium_price=prem_price, premium_delivery_days=prem_delivery,
                        premium_description=prem_desc, premium_includes=prem_incl,
                        active_package=active_pkg, gig_tags=gig_tags, gig_faq=gig_faq,
                        video_url=video_url, requirements=requirements)
        db.session.add(service)
        db.session.flush()
        if 'images' in request.files:
            files = request.files.getlist('images')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'services')
                    if img_path:
                        db.session.add(ServiceImage(service_id=service.id, filename=img_path))
        if 'main_image' in request.files:
            file = request.files['main_image']
            if file and file.filename:
                img_path = save_uploaded_file(file, 'services')
                if img_path: service.image = img_path
        db.session.commit()
        flash('Service ajoute avec packages!', 'success')
        return redirect(url_for('services.my_services'))
    return render_template('add_service.html', categories=CATEGORIES, cities=MOROCCAN_CITIES)

@services_bp.route('/service/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_service(id):
    service = Service.query.get_or_404(id)
    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('services.my_services'))
    if request.method == 'POST':
        service.title = request.form.get('title')
        service.category = request.form.get('category')
        service.description = request.form.get('description')
        service.price = float(request.form.get('price'))
        service.city = request.form.get('city')
        service.address = request.form.get('address')
        service.is_active = request.form.get('is_active') == 'on'
        if 'images' in request.files:
            files = request.files.getlist('images')
            for file in files:
                if file and file.filename:
                    img_path = save_uploaded_file(file, 'services')
                    if img_path:
                        db.session.add(ServiceImage(service_id=service.id, filename=img_path))
        db.session.commit()
        flash('Updated!', 'success')
        return redirect(url_for('services.my_services'))
    return render_template('edit_service.html', service=service, categories=CATEGORIES, cities=MOROCCAN_CITIES)

@services_bp.route('/service/delete/<int:id>', methods=['POST'])
@login_required
def delete_service(id):
    service = Service.query.get_or_404(id)
    if service.worker_id != session['user_id']:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('services.my_services'))
    db.session.delete(service)
    db.session.commit()
    flash('Deleted.', 'success')
    return redirect(url_for('services.my_services'))

@services_bp.route('/my-services')
@login_required
def my_services():
    user = User.query.get(session['user_id'])
    if user.user_type not in ['worker', 'entreprise'] and user.worker_subtype not in ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']:
        flash(_('workers_only'), 'danger')
        return redirect(url_for('main.index'))
    services = Service.query.filter_by(worker_id=session['user_id']).order_by(Service.created_at.desc()).all()
    return render_template('my_services.html', services=services)

@services_bp.route('/admin/services')
@admin_required
def admin_services():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    query = Service.query
    if search:
        query = query.filter(db.or_(Service.title.contains(search), Service.description.contains(search)))
    services = query.order_by(Service.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin_services.html', services=services, search=search)

@services_bp.route('/admin/services/delete/<int:id>', methods=['POST'])
@admin_required
def admin_delete_service(id):
    service = Service.query.get_or_404(id)
    db.session.delete(service)
    db.session.commit()
    flash('Deleted.', 'success')
    return redirect(url_for('admin.admin_services'))

@services_bp.route('/service/<int:service_id>/quote', methods=['GET', 'POST'])
def auto_quote(service_id):
    service = Service.query.get_or_404(service_id)
    if request.method == 'POST':
        answers = request.form.to_dict()
        base_price = service.basic_price or service.price
        multiplier = 1.0
        for key, val in answers.items():
            if 'urgent' in key and val == 'on':
                multiplier += 0.5
            if 'surface' in key:
                try: multiplier += (float(val) / 10) * 0.1
                except: pass
            if 'etage' in key:
                try: multiplier += int(val) * 0.1
                except: pass
        final_price = round(base_price * multiplier, 2)
        return jsonify({
            'base_price': base_price, 'multiplier': round(multiplier, 2),
            'final_price': final_price, 'service_title': service.title
        })
    return render_template('auto_quote.html', service=service)

@services_bp.route('/upload/service-image/<int:service_id>', methods=['POST'])
@login_required
def upload_service_image(service_id):
    service = Service.query.get_or_404(service_id)
    if service.worker_id != session['user_id'] and not session.get('is_admin'):
        flash('Non autorise.', 'danger')
        return redirect(url_for('services.my_services'))
    if 'images' not in request.files:
        flash('Aucun fichier selectionne.', 'danger')
        return redirect(url_for('services.edit_service', id=service_id))
    files = request.files.getlist('images')
    for file in files:
        if file and file.filename != '' and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            name, ext = os.path.splitext(filename)
            filename = f"svc_{service_id}_{int(datetime.utcnow().timestamp())}_{name}{ext}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'services', filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            file.save(filepath)
            img = ServiceImage(service_id=service_id, filename=f"uploads/services/{filename}")
            db.session.add(img)
    db.session.commit()
    flash('Images ajoutees avec succes!', 'success')
    return redirect(url_for('services.edit_service', id=service_id))

