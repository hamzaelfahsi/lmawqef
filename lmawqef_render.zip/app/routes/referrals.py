from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from app.extensions import db
from app.utils.translations import get_language, _
from app.utils.helpers import login_required
from app.models import User, ReferralLog, Notification
import random, string

referrals_bp = Blueprint('referrals', __name__)

def generate_referral_code():
    while True:
        code = 'LMQ' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        if not User.query.filter_by(referral_code=code).first():
            return code

@referrals_bp.route('/referrals')
@login_required
def referrals():
    user = User.query.get(session['user_id'])
    if not user.referral_code:
        user.referral_code = generate_referral_code()
        db.session.commit()
    logs = ReferralLog.query.filter_by(referrer_id=user.id).order_by(ReferralLog.created_at.desc()).all()
    total_earned = sum(r.reward_amount for r in logs if r.status == 'credited')
    return render_template('referrals.html', user=user, logs=logs, total_earned=total_earned)

@referrals_bp.route('/referrals/invite', methods=['POST'])
@login_required
def invite():
    user = User.query.get(session['user_id'])
    if not user.referral_code:
        user.referral_code = generate_referral_code()
        db.session.commit()
    method = request.form.get('method', 'link')
    link = request.url_root + 'register?ref=' + user.referral_code
    if method == 'whatsapp':
        text = f"Rejoins Lmawqef Pocket avec mon code et gagne 50 DH sur ton wallet ! {link}"
        return redirect(f"https://wa.me/?text={text.replace(' ', '%20')}")
    elif method == 'email':
        flash(_('referral_email_sent'), 'success')
    return redirect(url_for('referrals.referrals'))

@referrals_bp.route('/r/<code>')
def referral_redirect(code):
    referrer = User.query.filter_by(referral_code=code).first()
    if referrer:
        session['ref_code'] = code
    return redirect(url_for('auth.register'))

def process_referral(new_user):
    """Called after successful registration."""
    ref_code = session.pop('ref_code', None)
    if not ref_code:
        return
    referrer = User.query.filter_by(referral_code=ref_code).first()
    if not referrer or referrer.id == new_user.id:
        return
    new_user.referred_by = referrer.id
    reward = 50.0  # MAD
    log = ReferralLog(
        referrer_id=referrer.id,
        referred_id=new_user.id,
        reward_amount=reward,
        status='credited'
    )
    db.session.add(log)
    referrer.wallet_balance += reward
    referrer.referral_credits_earned += reward
    referrer.referral_count += 1
    referrer.points += 25
    db.session.commit()
    notif = Notification(
        user_id=referrer.id,
        title=_('notif_referral_title'),
        message=_('notif_referral_body').format(name=new_user.full_name, amount=reward),
        type='success',
        link='/referrals'
    )
    db.session.add(notif)
    db.session.commit()
