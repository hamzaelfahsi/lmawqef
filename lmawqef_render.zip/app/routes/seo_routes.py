from flask import Blueprint, Response, render_template, request
from app.extensions import db
from app.models import Service, User
from app.constants import MOROCCAN_CITIES, CATEGORIES

seo_bp = Blueprint('seo', __name__)

@seo_bp.route('/sitemap.xml')
def sitemap():
    from flask import request
    base = request.url_root
    urls = [base, base + 'services', base + 'workers', base + 'annonces']
    for svc in Service.query.filter_by(is_active=True).all():
        urls.append(base + f'service/{svc.id}')
    # Add SEO landing pages
    for city in MOROCCAN_CITIES:
        urls.append(base + f'lp/{city.lower().replace(" ", "-")}')
        for cat in CATEGORIES:
            urls.append(base + f'lp/{city.lower().replace(" ", "-")}/{cat.lower().replace(" ", "-")}')
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    for u in urls:
        xml += f'<url><loc>{u}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>\n'
    xml += '</urlset>'
    return Response(xml, mimetype='application/xml')

@seo_bp.route('/robots.txt')
def robots():
    return Response('User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: /sitemap.xml\n', mimetype='text/plain')

@seo_bp.route('/lp/<city>')
def landing_city(city):
    city_name = city.replace('-', ' ').title()
    if city_name not in MOROCCAN_CITIES:
        city_name = city.title()
    workers = User.query.filter(
        User.user_type.in_(['worker', 'entreprise']),
        User.city.ilike(f'%{city_name}%'),
        User.is_active == True
    ).order_by(User.is_featured.desc(), User.points.desc()).limit(12).all()
    top_categories = []
    for cat in CATEGORIES[:8]:
        count = Service.query.filter_by(category=cat).join(User).filter(
            User.city.ilike(f'%{city_name}%')
        ).count()
        if count > 0:
            top_categories.append({'name': cat, 'count': count})
    return render_template('landing_seo.html',
                           city=city_name,
                           category=None,
                           workers=workers,
                           categories=top_categories,
                           is_city_page=True)

@seo_bp.route('/lp/<city>/<category>')
def landing_city_category(city, category):
    city_name = city.replace('-', ' ').title()
    cat_name = category.replace('-', ' ').title()
    workers = User.query.filter(
        User.user_type.in_(['worker', 'entreprise']),
        User.city.ilike(f'%{city_name}%'),
        User.is_active == True
    ).join(Service).filter(Service.category.ilike(f'%{cat_name}%')).order_by(
        User.is_featured.desc(), User.points.desc()
    ).limit(12).all()
    # Similar workers in other cities
    similar = User.query.filter(
        User.user_type.in_(['worker', 'entreprise']),
        User.is_active == True
    ).join(Service).filter(Service.category.ilike(f'%{cat_name}%')).order_by(
        User.points.desc()
    ).limit(4).all()
    return render_template('landing_seo.html',
                           city=city_name,
                           category=cat_name,
                           workers=workers,
                           similar=similar,
                           categories=None,
                           is_city_page=False)
