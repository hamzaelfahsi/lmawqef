from flask import Blueprint, render_template, session, jsonify
from app.extensions import db
from app.utils.helpers import login_required
from app.models import User, Booking, Service, Review, Payment, WalletTransaction, SMSLog, Dispute, Notification
from sqlalchemy import func
from datetime import datetime, timedelta
import calendar

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/admin/analytics')
@login_required
def admin_analytics():
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        from flask import redirect, url_for, flash
        flash('Unauthorized', 'danger')
        return redirect(url_for('main.index'))
    
    # KPI Cards
    total_users = User.query.count()
    total_workers = User.query.filter(User.user_type.in_(['worker', 'artisan', 'freelance', 'auto_entrepreneur', 'entreprise'])).count()
    total_clients = User.query.filter_by(user_type='client').count()
    total_bookings = Booking.query.count()
    bookings_this_month = Booking.query.filter(Booking.created_at >= datetime.utcnow().replace(day=1)).count()
    total_revenue = db.session.query(func.sum(Payment.amount)).filter(Payment.status == 'completed').scalar() or 0
    avg_rating = db.session.query(func.avg(Review.rating)).scalar() or 0
    
    # Monthly booking trend (last 6 months)
    months = []
    bookings_per_month = []
    revenue_per_month = []
    for i in range(5, -1, -1):
        d = datetime.utcnow().replace(day=1) - timedelta(days=i*30)
        label = calendar.month_abbr[d.month]
        months.append(label)
        count = Booking.query.filter(
            db.extract('month', Booking.created_at) == d.month,
            db.extract('year', Booking.created_at) == d.year
        ).count()
        bookings_per_month.append(count)
        rev = db.session.query(func.sum(Payment.amount)).filter(
            Payment.status == 'completed',
            db.extract('month', Payment.created_at) == d.month,
            db.extract('year', Payment.created_at) == d.year
        ).scalar() or 0
        revenue_per_month.append(round(rev, 2))
    
    # Top cities
    top_cities = db.session.query(User.city, func.count(User.id)).filter(
        User.user_type.in_((['worker', 'artisan', 'freelance', 'auto_entrepreneur', 'entreprise']))
    ).group_by(User.city).order_by(func.count(User.id).desc()).limit(8).all()
    
    # Top categories
    top_categories = db.session.query(Service.category, func.count(Service.id)).group_by(
        Service.category
    ).order_by(func.count(Service.id).desc()).limit(8).all()
    
    # Disputes status
    dispute_stats = {
        'open': Dispute.query.filter_by(status='open').count(),
        'resolved': Dispute.query.filter_by(status='resolved').count(),
        'total': Dispute.query.count()
    }
    
    # User growth (last 7 days)
    user_growth = []
    for i in range(6, -1, -1):
        d = datetime.utcnow().date() - timedelta(days=i)
        count = User.query.filter(
            db.func.date(User.created_at) == d
        ).count()
        user_growth.append({'date': d.strftime('%d/%m'), 'count': count})
    
    # SMS stats
    sms_sent = SMSLog.query.filter_by(status='sent').count()
    sms_cost = db.session.query(func.sum(SMSLog.cost)).scalar() or 0
    
    return render_template('admin/analytics.html',
                           total_users=total_users,
                           total_workers=total_workers,
                           total_clients=total_clients,
                           total_bookings=total_bookings,
                           bookings_this_month=bookings_this_month,
                           total_revenue=total_revenue,
                           avg_rating=round(avg_rating, 2),
                           months=months,
                           bookings_per_month=bookings_per_month,
                           revenue_per_month=revenue_per_month,
                           top_cities=top_cities,
                           top_categories=top_categories,
                           dispute_stats=dispute_stats,
                           user_growth=user_growth,
                           sms_sent=sms_sent,
                           sms_cost=sms_cost)

@analytics_bp.route('/admin/analytics/api/realtime')
@login_required
def realtime_stats():
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'error': 'Unauthorized'})
    
    today = datetime.utcnow().date()
    bookings_today = Booking.query.filter(db.func.date(Booking.created_at) == today).count()
    users_today = User.query.filter(db.func.date(User.created_at) == today).count()
    revenue_today = db.session.query(func.sum(Payment.amount)).filter(
        Payment.status == 'completed',
        db.func.date(Payment.created_at) == today
    ).scalar() or 0
    
    return jsonify({
        'bookings_today': bookings_today,
        'users_today': users_today,
        'revenue_today': round(revenue_today, 2),
        'active_workers': User.query.filter_by(is_active=True, user_type='worker').count(),
        'pending_verifications': User.query.filter_by(verification_status='submitted').count()
    })
