from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from app.extensions import db
from app.utils.translations import _
from app.utils.helpers import login_required
from app.models import User, Booking, Milestone, Notification, WalletTransaction
from datetime import datetime

milestones_bp = Blueprint('milestones', __name__)

MILESTONE_TEMPLATES = {
    'renovation': [
        {'title': 'Acompte', 'percent': 30, 'description': 'Versement initial à la signature'},
        {'title': 'Mi-parcours', 'percent': 40, 'description': 'Paiement à la moitié du chantier'},
        {'title': 'Solde', 'percent': 30, 'description': 'Paiement final après réception'},
    ],
    'it_project': [
        {'title': 'Lancement', 'percent': 25, 'description': 'Démarrage du projet'},
        {'title': 'Prototype', 'percent': 35, 'description': 'Livraison du prototype'},
        {'title': 'Final', 'percent': 40, 'description': 'Livraison finale et tests'},
    ],
    'default': [
        {'title': 'Acompte', 'percent': 50, 'description': 'Paiement initial'},
        {'title': 'Solde', 'percent': 50, 'description': 'Paiement final'},
    ]
}

@milestones_bp.route('/booking/<int:booking_id>/milestones')
@login_required
def view_milestones(booking_id):
    user = User.query.get(session['user_id'])
    booking = Booking.query.get_or_404(booking_id)
    if booking.client_id != user.id and booking.service.worker_id != user.id and not user.is_admin:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('main.index'))
    milestones = Milestone.query.filter_by(booking_id=booking_id).order_by(Milestone.percent.asc()).all()
    return render_template('milestones.html', booking=booking, milestones=milestones)

@milestones_bp.route('/booking/<int:booking_id>/milestones/create', methods=['POST'])
@login_required
def create_milestones(booking_id):
    user = User.query.get(session['user_id'])
    booking = Booking.query.get_or_404(booking_id)
    if booking.client_id != user.id:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if Milestone.query.filter_by(booking_id=booking_id).first():
        flash(_('milestones_already_exist'), 'warning')
        return redirect(url_for('milestones.view_milestones', booking_id=booking_id))
    
    template_key = request.form.get('template', 'default')
    template = MILESTONE_TEMPLATES.get(template_key, MILESTONE_TEMPLATES['default'])
    total = booking.final_price or booking.service.price if booking.service else 0
    
    for item in template:
        m = Milestone(
            booking_id=booking_id,
            title=item['title'],
            description=item['description'],
            amount=round(total * item['percent'] / 100, 2),
            percent=item['percent']
        )
        db.session.add(m)
    db.session.commit()
    flash(_('milestones_created'), 'success')
    return redirect(url_for('milestones.view_milestones', booking_id=booking_id))

@milestones_bp.route('/milestone/<int:id>/complete', methods=['POST'])
@login_required
def complete_milestone(id):
    user = User.query.get(session['user_id'])
    milestone = Milestone.query.get_or_404(id)
    booking = milestone.booking
    if milestone.status != 'pending':
        return jsonify({'success': False, 'error': 'Already completed'})
    # Both parties must confirm completion
    if user.id == booking.service.worker_id or user.id == booking.client_id:
        milestone.status = 'completed'
        milestone.completed_at = datetime.utcnow()
        db.session.commit()
        # Notify other party to release funds
        other_id = booking.client_id if user.id == booking.service.worker_id else booking.service.worker_id
        notif = Notification(
            user_id=other_id,
            title='Milestone completed',
            message=f'{user.full_name} has marked "{milestone.title}" as completed. Please confirm to release funds.',
            type='success',
            link=f'/booking/{booking.id}/milestones'
        )
        db.session.add(notif)
        db.session.commit()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Unauthorized'})

@milestones_bp.route('/milestone/<int:id>/release', methods=['POST'])
@login_required
def release_milestone(id):
    user = User.query.get(session['user_id'])
    milestone = Milestone.query.get_or_404(id)
    booking = milestone.booking
    if milestone.status != 'completed':
        return jsonify({'success': False, 'error': 'Not completed yet'})
    if user.id != booking.client_id:
        return jsonify({'success': False, 'error': 'Only client can release'})
    
    # Release funds to worker
    milestone.status = 'released'
    milestone.released_at = datetime.utcnow()
    booking.service.worker.wallet_balance += milestone.amount
    wt = WalletTransaction(
        user_id=booking.service.worker_id,
        amount=milestone.amount,
        type='earning',
        status='completed',
        description=f'Milestone: {milestone.title} (Booking #{booking.id})'
    )
    db.session.add(wt)
    db.session.commit()
    
    # Notify worker
    notif = Notification(
        user_id=booking.service.worker_id,
        title='Funds released',
        message=f'{milestone.amount} DH released for "{milestone.title}"',
        type='success'
    )
    db.session.add(notif)
    db.session.commit()
    return jsonify({'success': True, 'amount': milestone.amount})
