from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from app.extensions import db
from app.utils.translations import _
from app.utils.helpers import login_required
from app.models import User, Booking, Dispute, Notification, SMSLog
import json, uuid
from datetime import datetime

disputes_bp = Blueprint('disputes', __name__)

REASONS = [
    ('no_show', 'Le prestataire ne s\'est pas présenté'),
    ('incomplete_work', 'Travail incomplet ou non conforme'),
    ('overcharge', 'Facturation supérieure au prix convenu'),
    ('delay', 'Retard excessif non justifié'),
    ('damage', 'Dommages causés lors de la prestation'),
    ('other', 'Autre raison')
]

@disputes_bp.route('/disputes')
@login_required
def my_disputes():
    user = User.query.get(session['user_id'])
    if user.user_type == 'client':
        disputes = Dispute.query.filter_by(client_id=user.id).order_by(Dispute.created_at.desc()).all()
    else:
        disputes = Dispute.query.filter_by(worker_id=user.id).order_by(Dispute.created_at.desc()).all()
    return render_template('disputes.html', disputes=disputes, reasons=REASONS)

@disputes_bp.route('/dispute/create/<int:booking_id>', methods=['GET', 'POST'])
@login_required
def create_dispute(booking_id):
    user = User.query.get(session['user_id'])
    booking = Booking.query.get_or_404(booking_id)
    if booking.client_id != user.id:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('bookings.my_bookings'))
    if booking.status not in ['in_progress', 'completed', 'disputed']:
        flash(_('dispute_invalid_status'), 'warning')
        return redirect(url_for('bookings.my_bookings'))
    existing = Dispute.query.filter_by(booking_id=booking_id).first()
    if existing:
        return redirect(url_for('disputes.dispute_detail', id=existing.id))
    if request.method == 'POST':
        reason_key = request.form.get('reason')
        description = request.form.get('description', '')
        evidence = []
        for file in request.files.getlist('evidence'):
            if file and file.filename:
                ext = file.filename.rsplit('.', 1)[-1].lower()
                fname = f"evidence_{uuid.uuid4().hex[:12]}.{ext}"
                from werkzeug.utils import secure_filename
                from flask import current_app
                path = secure_filename(fname)
                file.save(current_app.config['UPLOAD_FOLDER'] + '/' + path)
                evidence.append(path)
        dispute = Dispute(
            booking_id=booking_id,
            client_id=user.id,
            worker_id=booking.service.worker_id,
            reason=dict(REASONS).get(reason_key, reason_key),
            description=description,
            evidence_paths=json.dumps(evidence) if evidence else None
        )
        booking.status = 'disputed'
        db.session.add(dispute)
        db.session.commit()
        # Notify worker
        notif = Notification(
            user_id=booking.service.worker_id,
            title=_('notif_dispute_title'),
            message=_('notif_dispute_body').format(booking_id=booking_id),
            type='warning',
            link=f'/disputes'
        )
        db.session.add(notif)
        db.session.commit()
        flash(_('dispute_created'), 'success')
        return redirect(url_for('disputes.dispute_detail', id=dispute.id))
    return render_template('create_dispute.html', booking=booking, reasons=REASONS)

@disputes_bp.route('/dispute/<int:id>')
@login_required
def dispute_detail(id):
    user = User.query.get(session['user_id'])
    dispute = Dispute.query.get_or_404(id)
    if dispute.client_id != user.id and dispute.worker_id != user.id and not user.is_admin:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('main.index'))
    evidence = json.loads(dispute.evidence_paths) if dispute.evidence_paths else []
    return render_template('dispute_detail.html', dispute=dispute, evidence=evidence, reasons=REASONS)

@disputes_bp.route('/dispute/<int:id>/reply', methods=['POST'])
@login_required
def reply_dispute(id):
    user = User.query.get(session['user_id'])
    dispute = Dispute.query.get_or_404(id)
    if dispute.status != 'open':
        return jsonify({'success': False, 'error': 'Dispute closed'})
    if dispute.client_id != user.id and dispute.worker_id != user.id:
        return jsonify({'success': False, 'error': 'Unauthorized'})
    # Add reply as a message-like system - using notification for now
    reply_text = request.form.get('reply', '')
    target_id = dispute.worker_id if user.id == dispute.client_id else dispute.client_id
    notif = Notification(
        user_id=target_id,
        title='Nouvelle réponse dans un litige',
        message=f'{user.full_name}: {reply_text[:80]}',
        type='warning',
        link=f'/dispute/{id}'
    )
    db.session.add(notif)
    db.session.commit()
    return jsonify({'success': True})

@disputes_bp.route('/admin/disputes')
@login_required
def admin_disputes():
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        flash(_('unauthorized'), 'danger')
        return redirect(url_for('main.index'))
    disputes = Dispute.query.order_by(Dispute.created_at.desc()).all()
    return render_template('admin/disputes.html', disputes=disputes)

@disputes_bp.route('/admin/dispute/<int:id>/resolve', methods=['POST'])
@login_required
def admin_resolve(id):
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False})
    dispute = Dispute.query.get_or_404(id)
    resolution = request.form.get('resolution')
    resolution_type = request.form.get('resolution_type')
    refund = request.form.get('refund_amount', type=float)
    dispute.resolution = resolution
    dispute.resolution_type = resolution_type
    dispute.refund_amount = refund
    dispute.status = 'resolved'
    dispute.resolved_by = user.id
    dispute.resolved_at = datetime.utcnow()
    # Process refund if applicable
    if resolution_type in ['refund_partial', 'refund_full'] and refund and refund > 0:
        dispute.booking.client.wallet_balance += refund
        # Create transaction log
        from app.models import WalletTransaction
        wt = WalletTransaction(
            user_id=dispute.client_id,
            amount=refund,
            type='refund',
            status='completed',
            description=f'Refund for dispute #{dispute.id}'
        )
        db.session.add(wt)
    dispute.booking.status = 'cancelled' if resolution_type == 'cancel' else 'completed'
    db.session.commit()
    # Notify both parties
    for uid in [dispute.client_id, dispute.worker_id]:
        notif = Notification(
            user_id=uid,
            title='Litige résolu',
            message=f'Le litige #{dispute.id} a été résolu: {resolution[:60]}',
            type='info',
            link=f'/dispute/{dispute.id}'
        )
        db.session.add(notif)
    db.session.commit()
    flash(_('dispute_resolved'), 'success')
    return redirect(url_for('disputes.admin_disputes'))
