from flask import Flask, render_template_string
from app.extensions import db
from app.utils.translations import get_translations, get_language, set_language
from app.utils.seo import SeoHelper
import os

def create_app(config_name='development'):
    app = Flask(__name__, instance_relative_config=True)
    
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'lmawqef-secret-key-change-in-production')
    # Use absolute path to avoid SQLite corruption from working directory changes
    instance_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'instance')
    os.makedirs(instance_path, exist_ok=True)
    db_path = os.path.join(os.path.abspath(instance_path), 'lmawqef_v6.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', f'sqlite:///{db_path}')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
    
    db.init_app(app)
    
    @app.context_processor
    def inject_globals():
        from datetime import datetime
        from flask import session
        from app.models import Message, Notification, User
        unread_messages = 0
        unread_notifications = 0
        current_user = None
        if 'user_id' in session:
            unread_messages = Message.query.filter_by(receiver_id=session['user_id'], is_read=False).count()
            unread_notifications = Notification.query.filter_by(user_id=session['user_id'], is_read=False).count()
            current_user = User.query.get(session['user_id'])
        return {
            '_': lambda key: get_translations(get_language()).get(key, key),
            'lang': get_language(),
            'seo': SeoHelper(),
            'now': datetime.utcnow(),
            'unread_messages': unread_messages,
            'unread_notifications': unread_notifications,
            'available_langs': {'fr': 'Français', 'ar': 'العربية', 'en': 'English'},
            'current_user': current_user
        }
    
    @app.before_request
    def before_request():
        from flask import session, request
        if 'lang' not in session:
            session['lang'] = request.accept_languages.best_match(['fr', 'ar', 'en']) or 'fr'
        if 'visited' not in session:
            session['visited'] = False
    
    # Import models to register them
    from app import models
    
    from .routes.main import main_bp
    from .routes.auth import auth_bp
    from .routes.services import services_bp
    from .routes.workers import workers_bp
    from .routes.annonces import annonces_bp
    from .routes.bookings import bookings_bp
    from .routes.payments import payments_bp
    from .routes.messages import messages_bp
    from .routes.admin import admin_bp
    from .routes.api import api_bp
    from .routes.seo_routes import seo_bp
    from .routes.referrals import referrals_bp
    from .routes.disputes import disputes_bp
    from .routes.analytics import analytics_bp
    from .routes.milestones import milestones_bp
    from .routes.tfa import tfa_bp
    
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(services_bp)
    app.register_blueprint(workers_bp)
    app.register_blueprint(annonces_bp)
    app.register_blueprint(bookings_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(messages_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(seo_bp)
    app.register_blueprint(referrals_bp)
    app.register_blueprint(disputes_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(milestones_bp)
    app.register_blueprint(tfa_bp)
    
    app.jinja_env.globals['zip'] = zip
    app.jinja_env.globals['max'] = max
    app.jinja_env.globals['min'] = min
    app.jinja_env.globals['range'] = range
    
    @app.errorhandler(404)
    def not_found(e):
        return render_template_string('<h1>Page not found</h1>'), 404
    
    with app.app_context():
        db.create_all()
        from app.utils.seed import create_default_data
        create_default_data()
    
    return app
