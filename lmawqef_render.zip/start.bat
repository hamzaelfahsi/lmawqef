@echo off
REM Script de demarrage rapide Lmawqef Pocket - Windows

echo ==========================================
echo   Lmawqef Pocket - Demarrage rapide
echo ==========================================

REM Verifier Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python n'est pas installe. Veuillez l'installer depuis python.org
    pause
    exit /b 1
)

REM Creer l'environnement virtuel s'il n'existe pas
if not exist "venv" (
    echo 📦 Creation de l'environnement virtuel...
    python -m venv venv
)

REM Activer l'environnement virtuel
echo 🔌 Activation de l'environnement virtuel...
call venv\Scripts\activate.bat

REM Installer les dependances
echo 📥 Installation des dependances...
pip install -q -r requirements.txt

REM Creer les dossiers necessaires
if not exist "instance" mkdir instance
if not exist "uploads" mkdir uploads

REM Lancer l'application
echo 🚀 Lancement de Lmawqef Pocket...
echo    URL: http://localhost:5000
echo    Admin: admin@lmawqef.ma / admin123
echo    Client: client@lmawqef.ma / client123
echo    Worker: worker@lmawqef.ma / worker123
echo ==========================================

python run.py
pause
