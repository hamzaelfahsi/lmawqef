from app import create_app
import os

app = create_app()

if __name__ == '__main__':
    # Render / production uses PORT env var
    port = int(os.environ.get('PORT', 5000))
    host = '0.0.0.0'
    # Default to False for production safety
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host=host, port=port, debug=debug)
