from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random, string
from app.extensions import db
from app.models import (
    User, Service, Booking, Payment, Invoice, Annonce, AnnonceOffer,
    Review, Message, Notification, SubscriptionPlan, AppConfig, Level, Badge, AdminRole,
    Commission, WalletTransaction
)

def generate_invoice_number():
    return 'FAC-' + datetime.utcnow().strftime('%Y%m%d') + '-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))




def create_default_data():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin', email='admin@lmawqef.ma',
            password_hash=generate_password_hash('admin123'),
            full_name='System Administrator', phone='0600000000',
            city='Rabat', user_type='client', is_admin=True
        )
        db.session.add(admin)
        role = AdminRole(user_id=1, can_manage_users=True, can_manage_services=True,
                        can_manage_bookings=True, can_manage_annonces=True,
                        can_manage_subscriptions=True, can_manage_payments=True,
                        can_manage_admins=True, can_edit_config=True, can_view_analytics=True)
        db.session.add(role)
        db.session.commit()
        print('Admin created: admin / admin123')
    plans = SubscriptionPlan.query.all()
    if not plans:
        default_plans = [
            SubscriptionPlan(name='Entreprise Premium', slug='entreprise-premium',
                           description='For workforce companies', price=500, duration_days=30,
                           annonce_limit=999, features='["Unlimited announces","Featured profile","Priority support","Analytics"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Entreprise Basic', slug='entreprise-basic',
                           description='Basic plan for companies', price=0, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Basic support"]',
                           target_type='entreprise'),
            SubscriptionPlan(name='Auto-Entrepreneur Pro', slug='auto-pro',
                           description='For self-employed professionals', price=150, duration_days=30,
                           annonce_limit=100, features='["100 announces/month","Portfolio showcase","Priority listing","Direct messages"]',
                           target_type='autoentrepreneur'),
            SubscriptionPlan(name='Freelance Starter', slug='freelance-starter',
                           description='For freelancers', price=0, duration_days=30,
                           annonce_limit=20, features='["20 announces/month","Basic profile"]',
                           target_type='freelance'),
            SubscriptionPlan(name='Freelance Pro', slug='freelance-pro',
                           description='Pro plan for freelancers', price=100, duration_days=30,
                           annonce_limit=50, features='["50 announces/month","Portfolio","Featured services"]',
                           target_type='freelance')
        ]
        for p in default_plans:
            db.session.add(p)
        db.session.commit()
        print('Subscription plans created')
    config = AppConfig.query.first()
    if not config:
        config = AppConfig()
        db.session.add(config)
        db.session.commit()
        print('App config created')
    # Create default levels
    levels = Level.query.all()
    if not levels:
        default_levels = [
            Level(name='Novice', min_points=0, max_points=99, icon='fa-seedling', color='#84cc16', benefits='Basic profile'),
            Level(name='Apprenti', min_points=100, max_points=499, icon='fa-leaf', color='#22c55e', benefits='Portfolio access'),
            Level(name='Professionnel', min_points=500, max_points=1999, icon='fa-star', color='#0d9488', benefits='Priority listing'),
            Level(name='Expert', min_points=2000, max_points=4999, icon='fa-gem', color='#3b82f6', benefits='Featured services'),
            Level(name='Maitre', min_points=5000, max_points=9999, icon='fa-crown', color='#f59e0b', benefits='Analytics dashboard'),
            Level(name='Legende', min_points=10000, max_points=None, icon='fa-trophy', color='#ef4444', benefits='All premium features')
        ]
        for l in default_levels:
            db.session.add(l)
        db.session.commit()
        print('Levels created')
    # Create default badges
    badges = Badge.query.all()
    if not badges:
        default_badges = [
            Badge(name='Premier Service', slug='first-service', description='Complete your first service',
                  icon='fa-handshake', color='#0d9488', condition_type='bookings_count', condition_value=1, points_reward=50),
            Badge(name='Worker Actif', slug='active-worker', description='Complete 10 services',
                  icon='fa-briefcase', color='#3b82f6', condition_type='bookings_count', condition_value=10, points_reward=200),
            Badge(name='Top Rated', slug='top-rated', description='Achieve 4.5+ average rating',
                  icon='fa-star', color='#f59e0b', condition_type='rating', condition_value=5, points_reward=300),
            Badge(name='Critique Acclame', slug='popular-reviews', description='Receive 25 reviews',
                  icon='fa-comments', color='#8b5cf6', condition_type='reviews_count', condition_value=25, points_reward=250),
            Badge(name='Portfolio Pro', slug='portfolio-pro', description='Add 5 portfolio items',
                  icon='fa-images', color='#ec4899', condition_type='services_count', condition_value=5, points_reward=150),
            Badge(name='Rapidite Flash', slug='flash-response', description='Respond within 1 hour average',
                  icon='fa-bolt', color='#eab308', condition_type='response_time', condition_value=60, points_reward=200),
        ]
        db.session.commit()
        print('Badges created')
    
    # ==================== RICH DEMO DATA ====================
    # Create diverse worker types across Morocco
    all_worker_subtypes = ['artisan', 'freelancer', 'auto_entrepreneur', 'entreprise']
    
    if User.query.filter(User.user_type.in_(['worker','entreprise','freelancer','auto_entrepreneur'])).count() < 20:
        
        # ===== ARTISANS (Traditional craftsmen) =====
        artisan_data = [
            # Casablanca
            {'username':'youssef.casa', 'full_name':'Youssef Benali', 'email':'youssef@casa.ma', 
             'password':'worker123', 'city':'Casablanca', 'worker_subtype':'artisan',
             'profession_title':'Électricien Certifié | Installations Industrielles',
             'profession':'Électricien', 'skills':'Électricité, Installation tableau, Dépannage, Domotique',
             'description':'Électricien certifié avec 8 ans d\'expérience à Casablanca. Spécialisé en installations industrielles et domotique.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Intermédiaire',
             'education':'BTS Électrotechnique::ISTA Casablanca::2016',
             'certifications':'Certifié Électricien::ONEE::2019',
             'response_time_hours':3, 'phone':'0611111111', 'points':980, 'rating_avg':4.7},
            {'username':'fatima.casa', 'full_name':'Fatima Zahra', 'email':'fatima@casa.ma',
             'password':'worker123', 'city':'Casablanca', 'worker_subtype':'artisan',
             'profession_title':'Peintre Décoratrice | Design Intérieur',
             'profession':'Peintre', 'skills':'Peinture, Décoration, Papier peint, Enduit',
             'description':'Peintre décoratrice passionnée. Transformez votre intérieur avec des couleurs harmonieuses et des finitions impeccables.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Peinture::CFP Casablanca::2017',
             'certifications':'Certificat Décoration::École des Beaux-Arts::2020',
             'response_time_hours':4, 'phone':'0622222222', 'points':750, 'rating_avg':4.5},
            # Rabat
            {'username':'omar.rabat', 'full_name':'Omar El Idrissi', 'email':'omar@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'worker_subtype':'artisan',
             'profession_title':'Menuisier Ébéniste | Sur Mesure',
             'profession':'Menuisier', 'skills':'Menuiserie, Ébénisterie, Placard, Cuisine',
             'description':'Menuisier ébéniste spécialisé en meubles sur mesure. Qualité artisanale et finitions haut de gamme à Rabat.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'BTS Bois::OFPPT Rabat::2015',
             'certifications':'Maître Artisan::Chambre Artisanat Rabat::2018',
             'response_time_hours':5, 'phone':'0633333333', 'points':1100, 'rating_avg':4.8},
            {'username':'nadia.rabat', 'full_name':'Nadia Bennani', 'email':'nadia@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'worker_subtype':'artisan',
             'profession_title':'Jardinière Paysagiste | Espaces Verts',
             'profession':'Jardinier', 'skills':'Jardinage, Paysagisme, Entretien, Arrosage automatique',
             'description':'Jardinière paysagiste créative. Conception et entretien de jardins résidentiels et espaces verts professionnels.',
             'languages':'Français:Natif, Arabe:Natif, Espagnol:Intermédiaire',
             'education':'Bac Pro Horticulture::Lycée Agricole Rabat::2018',
             'certifications':'Certificat Paysagisme::Institut Agronomique::2021',
             'response_time_hours':6, 'phone':'0644444444', 'points':620, 'rating_avg':4.6},
            # Marrakech
            {'username':'karim.marrakech', 'full_name':'Karim Alaoui', 'email':'karim@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'worker_subtype':'artisan',
             'profession_title':'Plombier Traditionnel | Riads & Villas',
             'profession':'Plombier', 'skills':'Plomberie, Chauffe-eau, Zellige, Hammam',
             'description':'Plombier spécialisé dans les riads et villas de luxe à Marrakech. Expert en installations hammam traditionnel.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Plomberie::CFP Marrakech::2014',
             'certifications':'Expert Hammam::Association Plombiers Marrakech::2019',
             'response_time_hours':2, 'phone':'0655555555', 'points':1350, 'rating_avg':4.9},
            {'username':'amina.marrakech', 'full_name':'Amina Lamsyeh', 'email':'amina@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'worker_subtype':'artisan',
             'profession_title':'Coiffeuse à Domicile | Mariages & Soirées',
             'profession':'Coiffeuse', 'skills':'Coiffure, Maquillage, Chignon, Tresse',
             'description':'Coiffeuse professionnelle à domicile. Spécialisée en chignons de mariage, maquillage et coiffures de soirée.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'CAP Coiffure::Salon Prestige Marrakech::2016',
             'certifications':'Maquillage Professionnel::École Beauté Marrakech::2019',
             'response_time_hours':4, 'phone':'0666666666', 'points':890, 'rating_avg':4.7},
            # Fès
            {'username':'hassan.fes', 'full_name':'Hassan El Amrani', 'email':'hassan@fes.ma',
             'password':'worker123', 'city':'Fes', 'worker_subtype':'artisan',
             'profession_title':'Mosaïste Zellige | Art Traditionnel',
             'profession':'Mosaïste', 'skills':'Zellige, Mosaïque, Restauration, Décoration',
             'description':'Mosaïste maître artisan spécialisé en zellige traditionnel de Fès. Restauration de monuments historiques.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Formation Artisanale::Dar El Magana Fès::2010',
             'certifications':'Maître Zellige::UNESCO Patrimoine::2015',
             'response_time_hours':8, 'phone':'0677777777', 'points':1800, 'rating_avg':4.9},
            {'username':'samira.fes', 'full_name':'Samira Boudaoud', 'email':'samira@fes.ma',
             'password':'worker123', 'city':'Fes', 'worker_subtype':'artisan',
             'profession_title':'Couturière | Caftans & Tenues Traditionnelles',
             'profession':'Couturière', 'skills':'Couture, Broderie, Caftan, Retouche',
             'description':'Couturière experte en caftans traditionnels de Fès. Broderie fine et créations sur mesure pour occasions spéciales.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Formation Couture::Maison Caftan Fès::2012',
             'certifications':'Brodeuse Professionnelle::Chambre Artisanat Fès::2017',
             'response_time_hours':5, 'phone':'0688888888', 'points':720, 'rating_avg':4.6},
        ]
        
        # ===== FREELANCERS =====
        freelancer_data = [
            {'username':'tech.casa', 'full_name':'Ahmed Berrada', 'email':'ahmed.tech@casa.ma',
             'password':'worker123', 'city':'Casablanca', 'worker_subtype':'freelancer',
             'profession_title':'Développeur Full Stack | Web & Mobile',
             'profession':'Développeur', 'skills':'React, Node.js, Python, Flutter, Firebase',
             'description':'Développeur full stack passionné. Création d\'applications web et mobiles sur mesure pour startups et entreprises.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'Licence Informatique::FSAC::2019',
             'certifications':'AWS Certified Developer::Amazon::2022',
             'response_time_hours':2, 'phone':'0601000001', 'points':1250, 'rating_avg':4.9},
            {'username':'design.rabat', 'full_name':'Leila Kamal', 'email':'leila.design@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'worker_subtype':'freelancer',
             'profession_title':'Designer Graphique | Branding & UI/UX',
             'profession':'Designer', 'skills':'Photoshop, Illustrator, Figma, After Effects, Branding',
             'description':'Designer créative spécialisée en identité visuelle et interface utilisateur. Donnez vie à votre marque avec style.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Intermédiaire',
             'education':'Diplôme Design::École Supérieure des Beaux-Arts::2018',
             'certifications':'Adobe Certified Expert::Adobe::2021',
             'response_time_hours':3, 'phone':'0602000002', 'points':980, 'rating_avg':4.8},
            {'username':'redac.tanger', 'full_name':'Sofia Amrani', 'email':'sofia.redac@tanger.ma',
             'password':'worker123', 'city':'Tangier', 'worker_subtype':'freelancer',
             'profession_title':'Rédactrice Web SEO | Content Marketing',
             'profession':'Rédactrice', 'skills':'SEO, Copywriting, WordPress, Réseaux sociaux, Community Management',
             'description':'Rédactrice web et community manager. Contenus optimisés SEO, gestion de réseaux sociaux et stratégie digitale.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant, Espagnol:Courant',
             'education':'Master Communication::Université Tanger::2020',
             'certifications':'Certification SEO::Google::2022',
             'response_time_hours':4, 'phone':'0603000003', 'points':760, 'rating_avg':4.6},
            {'username':'photo.marrakech', 'full_name':'Younes El Fassi', 'email':'younes.photo@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'worker_subtype':'freelancer',
             'profession_title':'Photographe Professionnel | Événements & Corporate',
             'profession':'Photographe', 'skills':'Photographie, Retouche, Vidéo, Drone, Lightroom',
             'description':'Photographe professionnel basé à Marrakech. Mariages, événements corporate, reportages et photos immobilières.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Intermédiaire',
             'education':'CAP Photographie::Institut Spécialisé Marrakech::2017',
             'certifications':'Drone Pilot License::DGAC Maroc::2021',
             'response_time_hours':5, 'phone':'0604000004', 'points':890, 'rating_avg':4.7},
            {'username':'trad.fes', 'full_name':'Mounir Benali', 'email':'mounir.trad@fes.ma',
             'password':'worker123', 'city':'Fes', 'worker_subtype':'freelancer',
             'profession_title':'Traducteur Certifié | FR-AR-EN-ES',
             'profession':'Traducteur', 'skills':'Traduction, Interprétation, Relecture, Localisation, Sous-titrage',
             'description':'Traducteur professionnel agréé. Traduction juridique, technique et littéraire en 4 langues avec certification.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant, Espagnol:Courant',
             'education':'Master Traduction::Université Fès::2019',
             'certifications':'Traducteur Assermenté::Cour d\'Appel Fès::2021',
             'response_time_hours':3, 'phone':'0605000005', 'points':670, 'rating_avg':4.5},
        ]
        
        # ===== AUTO-ENTREPRENEURS =====
        autoent_data = [
            {'username':'coach.casa', 'full_name':'Nadia El Amrani', 'email':'nadia.coach@casa.ma',
             'password':'worker123', 'city':'Casablanca', 'worker_subtype':'auto_entrepreneur',
             'profession_title':'Coach Professionnelle | Développement Personnel',
             'profession':'Coach', 'skills':'Coaching, Leadership, Gestion du stress, Productivité, RH',
             'description':'Coach certifiée en développement personnel et professionnel. Accompagnement individuel et collectif des cadres et dirigeants.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'Master RH::ENCG Casablanca::2017',
             'certifications':'Coach Certifiée ICF::International Coach Federation::2020',
             'response_time_hours':4, 'phone':'0606000006', 'points':820, 'rating_avg':4.8},
            {'username':'compta.rabat', 'full_name':'Khalid Moussaoui', 'email':'khalid.compta@rabat.ma',
             'password':'worker123', 'city':'Rabat', 'worker_subtype':'auto_entrepreneur',
             'profession_title':'Expert-Comptable | Conseil Fiscal',
             'profession':'Comptable', 'skills':'Comptabilité, Fiscalité, Audit, Paie, Gestion financière',
             'description':'Expert-comptable et conseiller fiscal indépendant. Tenue comptable, déclarations fiscales et accompagnement création d\'entreprise.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'Expert-Comptable::OEC Maroc::2015',
             'certifications':'Commissaire aux Comptes::OEC::2018',
             'response_time_hours':2, 'phone':'0607000007', 'points':1150, 'rating_avg':4.9},
            {'username':'consulting.marrakech', 'full_name':'Hanae Filali', 'email':'hanae.consult@marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'worker_subtype':'auto_entrepreneur',
             'profession_title':'Consultante Marketing Digital | Growth Hacking',
             'profession':'Consultante', 'skills':'Marketing digital, SEO/SEA, Analytics, Social Ads, E-commerce',
             'description':'Consultante en marketing digital et stratégie de croissance. J\'aide les entreprises à accroître leur visibilité en ligne.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'Master Marketing::Université Cadi Ayyad::2019',
             'certifications':'Google Analytics Certified::Google::2021',
             'response_time_hours':3, 'phone':'0608000008', 'points':740, 'rating_avg':4.6},
            {'username':'training.tanger', 'full_name':'Rachid Bennani', 'email':'rachid.training@tanger.ma',
             'password':'worker123', 'city':'Tangier', 'worker_subtype':'auto_entrepreneur',
             'profession_title':'Formateur Professionnel | Soft Skills & IT',
             'profession':'Formateur', 'skills':'Formation, Pédagogie, Excel avancé, Management, Bureautique',
             'description':'Formateur professionnel indépendant. Formations en bureautique, management et compétences comportementales pour entreprises.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'Master Pédagogie::ENS Tanger::2016',
             'certifications':'Formateur Certifié::OFPPPT::2019',
             'response_time_hours':5, 'phone':'0609000009', 'points':580, 'rating_avg':4.5},
            {'username':'avocat.agadir', 'full_name':'Yasmine Lahlou', 'email':'yasmine.avocat@agadir.ma',
             'password':'worker123', 'city':'Agadir', 'worker_subtype':'auto_entrepreneur',
             'profession_title':'Avocate | Droit des Affaires & Immobilier',
             'profession':'Avocate', 'skills':'Droit des affaires, Droit immobilier, Contrats, Médiation, Conseil juridique',
             'description':'Avocate indépendante spécialisée en droit des affaires et immobilier. Rédaction de contrats, conseil et accompagnement juridique.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Intermédiaire',
             'education':'Master Droit::Université Ibn Zohr::2018',
             'certifications':'Avocate au Barreau::Barreau Agadir::2020',
             'response_time_hours':6, 'phone':'0610000010', 'points':920, 'rating_avg':4.7},
        ]
        
        # ===== ENTREPRISES =====
        entreprise_data = [
            {'username':'btp.casa', 'full_name':'Maroc BTP Pro SARL', 'email':'contact@btppro.casa.ma',
             'password':'worker123', 'city':'Casablanca', 'worker_subtype':'entreprise',
             'profession_title':'Entreprise de Bâtiment | Construction & Rénovation',
             'profession':'BTP', 'skills':'Construction, Rénovation, Gros oeuvre, Second oeuvre, Maçonnerie',
             'description':'Entreprise de bâtiment certifiée ISO 9001. Construction neuve, rénovation complète et travaux structuraux à Casablanca.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'','certifications':'ISO 9001::AFNOR::2021',
             'response_time_hours':4, 'phone':'0611000011', 'points':2100, 'rating_avg':4.8,
             'company_name':'Maroc BTP Pro SARL', 'rc_number':'RC-123456', 'ice_number':'001234567800089'},
            {'username':'clean.rabat', 'full_name':'CleanPro Services SARL', 'email':'contact@cleanpro.rabat.ma',
             'password':'worker123', 'city':'Rabat', 'worker_subtype':'entreprise',
             'profession_title':'Société de Nettoyage | Industriel & Domestique',
             'profession':'Nettoyage', 'skills':'Nettoyage industriel, Désinfection, Vitres, Moquettes, Javelage',
             'description':'Société de nettoyage professionnelle. Nettoyage de bureaux, immeubles, industries et désinfection post-construction.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'','certifications':'Certification Hygiène::Ministère Santé::2020',
             'response_time_hours':2, 'phone':'0612000012', 'points':1680, 'rating_avg':4.7,
             'company_name':'CleanPro Services SARL', 'rc_number':'RC-234567', 'ice_number':'002345678900089'},
            {'username':'demenage.marrakech', 'full_name':'Atlas Déménagement SARL', 'email':'contact@atlasdem.marrakech.ma',
             'password':'worker123', 'city':'Marrakech', 'worker_subtype':'entreprise',
             'profession_title':'Déménageur Professionnel | National & International',
             'profession':'Déménagement', 'skills':'Déménagement, Transport, Emballage, Stockage, Montage',
             'description':'Entreprise de déménagement avec flotte de camions et équipe professionnelle. Déménagements locaux et internationaux.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'','certifications':'Transporteur Agréé::Ministère Transport::2019',
             'response_time_hours':3, 'phone':'0613000013', 'points':1450, 'rating_avg':4.6,
             'company_name':'Atlas Déménagement SARL', 'rc_number':'RC-345678', 'ice_number':'003456789000089'},
            {'username':'it.tanger', 'full_name':'Tanger IT Solutions SARL', 'email':'contact@tangerit.tanger.ma',
             'password':'worker123', 'city':'Tangier', 'worker_subtype':'entreprise',
             'profession_title':'SSII | Intégration & Infogérance Informatique',
             'profession':'Informatique', 'skills':'Réseau, Sécurité IT, Cloud, Maintenance, Développement',
             'description':'Société de services informatiques. Infogérance, installation réseau, cybersécurité et développement sur mesure pour PME.',
             'languages':'Français:Natif, Arabe:Natif, Anglais:Courant',
             'education':'','certifications':'Microsoft Partner::Microsoft::2022',
             'response_time_hours':1, 'phone':'0614000014', 'points':1890, 'rating_avg':4.9,
             'company_name':'Tanger IT Solutions SARL', 'rc_number':'RC-456789', 'ice_number':'004567890000089'},
            {'username':'security.fes', 'full_name':'Sécurité Fès Plus SARL', 'email':'contact@securitefes.fes.ma',
             'password':'worker123', 'city':'Fes', 'worker_subtype':'entreprise',
             'profession_title':'Agence de Sécurité | Gardiennage & Surveillance',
             'profession':'Sécurité', 'skills':'Gardiennage, Surveillance, Alarme, Vidéosurveillance, Rondes',
             'description':'Agence de sécurité agréée. Gardiennage d\'immeubles, surveillance événementielle et installation de systèmes de sécurité.',
             'languages':'Français:Natif, Arabe:Natif',
             'education':'','certifications':'Agrément Sécurité::Ministère Intérieur::2020',
             'response_time_hours':2, 'phone':'0615000015', 'points':1320, 'rating_avg':4.8,
             'company_name':'Sécurité Fès Plus SARL', 'rc_number':'RC-567890', 'ice_number':'005678901000089'},
        ]
        
        # Combine all worker data
        all_worker_data = artisan_data + freelancer_data + autoent_data + entreprise_data
        
        created_workers = []
        for wd in all_worker_data:
            w = User.query.filter_by(username=wd['username']).first()
            if not w:
                w = User(
                    username=wd['username'], full_name=wd['full_name'], email=wd['email'],
                    password_hash=generate_password_hash(wd['password']),
                    user_type=wd.get('user_type', 'worker'),
                    worker_subtype=wd.get('worker_subtype'),
                    city=wd['city'], profession_title=wd.get('profession_title'),
                    skills=wd.get('skills'),
                    description=wd.get('description'), languages=wd.get('languages'),
                    education=wd.get('education'), certifications=wd.get('certifications'),
                    response_time_hours=wd.get('response_time_hours', 24),
                    money_back_guarantee=True, phone=wd.get('phone'),
                    points=wd.get('points', 0),
                    is_active=True,
                    company_name=wd.get('company_name'),
                    rc_number=wd.get('rc_number'),
                    ice_number=wd.get('ice_number')
                )
                db.session.add(w)
                db.session.flush()
                lvl = Level.query.filter(Level.min_points <= w.points).order_by(Level.min_points.desc()).first()
                if lvl: w.level_id = lvl.id
                created_workers.append(w)
        db.session.commit()
        print(f'{len(created_workers)} demo workers created (artisans, freelancers, auto-entrepreneurs, entreprises)')
        
        # ===== SERVICES =====
        services_data = [
            # Artisan services
            ('youssef.casa', [
                {'title':'Installation Électrique Complète', 'description':'Installation tableau électrique, mise aux normes, éclairage LED pour appartements et villas.', 'price':2500, 'category':'Électricité', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':2, 'standard_price':2500, 'standard_delivery_days':3, 'premium_price':4000, 'premium_delivery_days':5},
                {'title':'Dépannage Électrique Urgent', 'description':'Intervention urgente 24/7 pour pannes électriques, court-circuit, fusibles grillés.', 'price':300, 'category':'Électricité', 'city':'Casablanca', 'is_urgent':True,
                 'basic_price':200, 'basic_delivery_days':1, 'standard_price':300, 'standard_delivery_days':1, 'premium_price':500, 'premium_delivery_days':1},
            ]),
            ('fatima.casa', [
                {'title':'Peinture Intérieure Complète', 'description':'Peinture intérieure appartement ou villa. Préparation, enduit, peinture premium.', 'price':3500, 'category':'Peinture', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':3, 'standard_price':3500, 'standard_delivery_days':5, 'premium_price':5500, 'premium_delivery_days':7},
                {'title':'Décoration Murale & Papier Peint', 'description':'Pose papier peint, stickers décoratifs, peinture artistique murale.', 'price':1500, 'category':'Peinture', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':800, 'basic_delivery_days':2, 'standard_price':1500, 'standard_delivery_days':3, 'premium_price':2500, 'premium_delivery_days':5},
            ]),
            ('omar.rabat', [
                {'title':'Cuisine sur Mesure', 'description':'Conception et fabrication de cuisine équipée sur mesure. Plans 3D inclus.', 'price':15000, 'category':'Menuiserie', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':10000, 'basic_delivery_days':10, 'standard_price':15000, 'standard_delivery_days':15, 'premium_price':22000, 'premium_delivery_days':20},
                {'title':'Placard & Dressing', 'description':'Placard et dressing sur mesure. Organisation optimale de l\'espace.', 'price':5000, 'category':'Menuiserie', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':3000, 'basic_delivery_days':5, 'standard_price':5000, 'standard_delivery_days':7, 'premium_price':8000, 'premium_delivery_days':10},
            ]),
            ('karim.marrakech', [
                {'title':'Installation Hammam Traditionnel', 'description':'Installation complète hammam marocain traditionnel avec zellige et tadelakt.', 'price':25000, 'category':'Plomberie', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':18000, 'basic_delivery_days':15, 'standard_price':25000, 'standard_delivery_days':20, 'premium_price':35000, 'premium_delivery_days':30},
                {'title':'Réparation Fuite & Chauffe-eau', 'description':'Réparation toutes fuites d\'eau, remplacement chauffe-eau, débouchage.', 'price':400, 'category':'Plomberie', 'city':'Marrakech', 'is_urgent':True,
                 'basic_price':250, 'basic_delivery_days':1, 'standard_price':400, 'standard_delivery_days':1, 'premium_price':700, 'premium_delivery_days':2},
            ]),
            ('hassan.fes', [
                {'title':'Zellige Traditionnel de Fès', 'description':'Pose zellige artisanal traditionnel de Fès. Motifs géométriques authentiques.', 'price':800, 'category':'Mosaïque', 'city':'Fes', 'is_urgent':False,
                 'basic_price':500, 'basic_delivery_days':3, 'standard_price':800, 'standard_delivery_days':5, 'premium_price':1200, 'premium_delivery_days':7},
                {'title':'Restauration Zellige Ancien', 'description':'Restauration de zellige ancien dans riads et monuments. Conservation patrimoine.', 'price':3000, 'category':'Mosaïque', 'city':'Fes', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':7, 'standard_price':3000, 'standard_delivery_days':10, 'premium_price':5000, 'premium_delivery_days':15},
            ]),
            # Freelancer services
            ('tech.casa', [
                {'title':'Développement Site Web Vitrine', 'description':'Création de site web vitrine professionnel responsive avec CMS. Design personnalisé.', 'price':6000, 'category':'IT & Technology', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':3500, 'basic_delivery_days':7, 'standard_price':6000, 'standard_delivery_days':14, 'premium_price':10000, 'premium_delivery_days':21},
                {'title':'Application Mobile Flutter', 'description':'Développement d\'application mobile iOS/Android avec Flutter et Firebase.', 'price':15000, 'category':'IT & Technology', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':10000, 'basic_delivery_days':20, 'standard_price':15000, 'standard_delivery_days':30, 'premium_price':25000, 'premium_delivery_days':45},
                {'title':'API Backend & Base de Données', 'description':'Conception et développement d\'API REST/GraphQL avec Node.js/Python et base SQL/NoSQL.', 'price':8000, 'category':'IT & Technology', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':5000, 'basic_delivery_days':10, 'standard_price':8000, 'standard_delivery_days':15, 'premium_price':12000, 'premium_delivery_days':25},
            ]),
            ('design.rabat', [
                {'title':'Identité Visuelle Complète', 'description':'Création de logo, charte graphique, cartes de visite et supports de communication.', 'price':4000, 'category':'Marketing & Design', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':2500, 'basic_delivery_days':7, 'standard_price':4000, 'standard_delivery_days':12, 'premium_price':7000, 'premium_delivery_days':20},
                {'title':'UI/UX Design Application', 'description':'Design d\'interface utilisateur et expérience utilisateur pour web/mobile. Maquettes Figma.', 'price':7000, 'category':'Marketing & Design', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':4000, 'basic_delivery_days':10, 'standard_price':7000, 'standard_delivery_days':18, 'premium_price':12000, 'premium_delivery_days':28},
                {'title':'Motion Design & Vidéo', 'description':'Création de vidéos explicatives, animations et habillages motion design.', 'price':5000, 'category':'Marketing & Design', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':3000, 'basic_delivery_days':5, 'standard_price':5000, 'standard_delivery_days':10, 'premium_price':8000, 'premium_delivery_days':15},
            ]),
            ('redac.tanger', [
                {'title':'Rédaction Web SEO (10 articles)', 'description':'Rédaction de 10 articles optimisés SEO pour votre blog ou site e-commerce.', 'price':3000, 'category':'Marketing & Design', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':5, 'standard_price':3000, 'standard_delivery_days':10, 'premium_price':5000, 'premium_delivery_days':15},
                {'title':'Gestion Réseaux Sociaux (1 mois)', 'description':'Community management complet : création de contenu, planification, modération et reporting.', 'price':2500, 'category':'Marketing & Design', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':1, 'standard_price':2500, 'standard_delivery_days':30, 'premium_price':4000, 'premium_delivery_days':30},
            ]),
            ('photo.marrakech', [
                {'title':'Shooting Photo Mariage', 'description':'Couverture photo complète de votre mariage. Album premium et photos retouchées.', 'price':8000, 'category':'Photography & Events', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':5000, 'basic_delivery_days':15, 'standard_price':8000, 'standard_delivery_days':25, 'premium_price':15000, 'premium_delivery_days':35},
                {'title':'Reportage Corporate', 'description':'Photos professionnelles pour entreprise : portraits, locaux, événements, produits.', 'price':3500, 'category':'Photography & Events', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':5, 'standard_price':3500, 'standard_delivery_days':10, 'premium_price':6000, 'premium_delivery_days':15},
                {'title':'Vidéo Immobilière Drone', 'description':'Vidéo promotionnelle de votre bien immobilier avec prise de vue drone et montage.', 'price':4500, 'category':'Photography & Events', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':2500, 'basic_delivery_days':3, 'standard_price':4500, 'standard_delivery_days':7, 'premium_price':7000, 'premium_delivery_days':12},
            ]),
            ('trad.fes', [
                {'title':'Traduction Juridique Certifiée', 'description':'Traduction assermentée de documents juridiques et administratifs FR-AR-EN.', 'price':500, 'category':'Legal & Accounting', 'city':'Fes', 'is_urgent':False,
                 'basic_price':300, 'basic_delivery_days':2, 'standard_price':500, 'standard_delivery_days':4, 'premium_price':800, 'premium_delivery_days':2},
                {'title':'Localisation Site Web', 'description':'Traduction et adaptation culturelle complète de votre site web et application.', 'price':6000, 'category':'Legal & Accounting', 'city':'Fes', 'is_urgent':False,
                 'basic_price':3500, 'basic_delivery_days':10, 'standard_price':6000, 'standard_delivery_days':18, 'premium_price':10000, 'premium_delivery_days':25},
            ]),
            # Auto-entrepreneur services
            ('coach.casa', [
                {'title':'Coaching Individuel (5 séances)', 'description':'Accompagnement personnalisé en développement personnel et professionnel. 5 séances d\'1h.', 'price':3000, 'category':'Health & Wellness', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':30, 'standard_price':3000, 'standard_delivery_days':30, 'premium_price':5000, 'premium_delivery_days':30},
                {'title':'Atelier Leadership Équipe', 'description':'Formation collective sur le leadership, la communication et la gestion d\'équipe.', 'price':5000, 'category':'Health & Wellness', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':3000, 'basic_delivery_days':7, 'standard_price':5000, 'standard_delivery_days':14, 'premium_price':8000, 'premium_delivery_days':21},
            ]),
            ('compta.rabat', [
                {'title':'Tenue Comptable Mensuelle', 'description':'Enregistrement comptable, lettrage, rapprochement bancaire et reporting mensuel.', 'price':1500, 'category':'Legal & Accounting', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':1000, 'basic_delivery_days':30, 'standard_price':1500, 'standard_delivery_days':30, 'premium_price':2500, 'premium_delivery_days':30},
                {'title':'Création Société & Conseil', 'description':'Accompagnement complet dans la création de votre société : choix forme juridique, dossier, immatriculation.', 'price':3000, 'category':'Legal & Accounting', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':7, 'standard_price':3000, 'standard_delivery_days':14, 'premium_price':5000, 'premium_delivery_days':21},
                {'title':'Déclaration Fiscale Annuelle', 'description':'Établissement et dépôt de votre déclaration fiscale annuelle (IR/IS) avec optimisation.', 'price':1200, 'category':'Legal & Accounting', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':800, 'basic_delivery_days':5, 'standard_price':1200, 'standard_delivery_days':10, 'premium_price':2000, 'premium_delivery_days':7},
            ]),
            ('consulting.marrakech', [
                {'title':'Audit Marketing Digital', 'description':'Audit complet de votre présence digitale avec recommandations stratégiques et plan d\'action.', 'price':4000, 'category':'Marketing & Design', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':2500, 'basic_delivery_days':7, 'standard_price':4000, 'standard_delivery_days':14, 'premium_price':7000, 'premium_delivery_days':21},
                {'title':'Campagne Ads (1 mois)', 'description':'Création et gestion de campagnes publicitaires Google Ads & Meta Ads avec suivi ROI.', 'price':3500, 'category':'Marketing & Design', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':30, 'standard_price':3500, 'standard_delivery_days':30, 'premium_price':6000, 'premium_delivery_days':30},
            ]),
            ('training.tanger', [
                {'title':'Formation Excel Avancé', 'description':'Formation pratique sur Excel : tableaux croisés, macros, formules avancées. Groupe 5-10 personnes.', 'price':2500, 'category':'Education & Tutoring', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':2, 'standard_price':2500, 'standard_delivery_days':2, 'premium_price':4000, 'premium_delivery_days':2},
                {'title':'Formation Management', 'description':'Formation en management et gestion d\'équipe pour nouveaux managers. Certificat de participation.', 'price':4000, 'category':'Education & Tutoring', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':2500, 'basic_delivery_days':1, 'standard_price':4000, 'standard_delivery_days':1, 'premium_price':6000, 'premium_delivery_days':1},
            ]),
            ('avocat.agadir', [
                {'title':'Rédaction Contrat Commercial', 'description':'Rédaction et révision de contrats commerciaux, CGV et conditions de vente.', 'price':2000, 'category':'Legal & Accounting', 'city':'Agadir', 'is_urgent':False,
                 'basic_price':1200, 'basic_delivery_days':3, 'standard_price':2000, 'standard_delivery_days':7, 'premium_price':3500, 'premium_delivery_days':5},
                {'title':'Conseil Juridique Immobilier', 'description':'Accompagnement dans vos transactions immobilières : due diligence, rédaction promesse, acte authentique.', 'price':3000, 'category':'Legal & Accounting', 'city':'Agadir', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':5, 'standard_price':3000, 'standard_delivery_days':10, 'premium_price':5000, 'premium_delivery_days':7},
            ]),
            # Entreprise services
            ('btp.casa', [
                {'title':'Construction Villa Neuve (100m²)', 'description':'Construction clé en main de votre villa. Gros oeuvre, second oeuvre et finitions.', 'price':450000, 'category':'Construction & Renovation', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':400000, 'basic_delivery_days':180, 'standard_price':450000, 'standard_delivery_days':240, 'premium_price':550000, 'premium_delivery_days':300},
                {'title':'Rénovation Appartement Complet', 'description':'Rénovation complète d\'appartement : démolition, plomberie, électricité, sols, peinture.', 'price':80000, 'category':'Construction & Renovation', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':50000, 'basic_delivery_days':30, 'standard_price':80000, 'standard_delivery_days':45, 'premium_price':120000, 'premium_delivery_days':60},
                {'title':'Extension & Surélévation', 'description':'Extension ou surélévation de votre habitation. Étude structure, permis et travaux.', 'price':120000, 'category':'Construction & Renovation', 'city':'Casablanca', 'is_urgent':False,
                 'basic_price':80000, 'basic_delivery_days':45, 'standard_price':120000, 'standard_delivery_days':60, 'premium_price':180000, 'premium_delivery_days':90},
            ]),
            ('clean.rabat', [
                {'title':'Nettoyage Bureau Hebdomadaire', 'description':'Service de nettoyage régulier pour bureaux : sols, vitres, sanitaires, poubelles.', 'price':2000, 'category':'Cleaning & Housekeeping', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':7, 'standard_price':2000, 'standard_delivery_days':7, 'premium_price':3000, 'premium_delivery_days':7},
                {'title':'Nettoyage Post-Chantier', 'description':'Nettoyage complet après travaux : dépoussiérage, enlèvement résidus, vitres, sols.', 'price':3500, 'category':'Cleaning & Housekeeping', 'city':'Rabat', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':2, 'standard_price':3500, 'standard_delivery_days':3, 'premium_price':5000, 'premium_delivery_days':5},
                {'title':'Désinfection Complète', 'description':'Désinfection professionnelle des locaux par nébulisation. Idéal pour bureaux, commerces et horeca.', 'price':1500, 'category':'Cleaning & Housekeeping', 'city':'Rabat', 'is_urgent':True,
                 'basic_price':1000, 'basic_delivery_days':1, 'standard_price':1500, 'standard_delivery_days':1, 'premium_price':2500, 'premium_delivery_days':2},
            ]),
            ('demenage.marrakech', [
                {'title':'Déménagement Local', 'description':'Déménagement dans la région de Marrakech. Emballage, transport, déballage et montage.', 'price':2500, 'category':'Transport & Logistics', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':1500, 'basic_delivery_days':1, 'standard_price':2500, 'standard_delivery_days':1, 'premium_price':4000, 'premium_delivery_days':2},
                {'title':'Déménagement National', 'description':'Déménagement longue distance vers n\'importe quelle ville du Maroc. Assurance incluse.', 'price':8000, 'category':'Transport & Logistics', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':5000, 'basic_delivery_days':3, 'standard_price':8000, 'standard_delivery_days':5, 'premium_price':12000, 'premium_delivery_days':7},
                {'title':'Stockage Garde-Meuble', 'description':'Location d\'espace de stockage sécurisé et surveillé. Accès 7j/7.', 'price':1500, 'category':'Transport & Logistics', 'city':'Marrakech', 'is_urgent':False,
                 'basic_price':1000, 'basic_delivery_days':30, 'standard_price':1500, 'standard_delivery_days':30, 'premium_price':2500, 'premium_delivery_days':30},
            ]),
            ('it.tanger', [
                {'title':'Infogérance Informatique', 'description':'Maintenance préventive et curative de votre parc informatique. Support 7j/7.', 'price':5000, 'category':'IT & Technology', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':3000, 'basic_delivery_days':30, 'standard_price':5000, 'standard_delivery_days':30, 'premium_price':8000, 'premium_delivery_days':30},
                {'title':'Installation Réseau & Sécurité', 'description':'Installation complète réseau : câblage, switchs, firewall, WiFi entreprise et VPN.', 'price':15000, 'category':'IT & Technology', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':10000, 'basic_delivery_days':7, 'standard_price':15000, 'standard_delivery_days':14, 'premium_price':25000, 'premium_delivery_days':21},
                {'title':'Audit Cybersécurité', 'description':'Audit complet de votre système d\'information : vulnérabilités, conformité, recommandations.', 'price':12000, 'category':'IT & Technology', 'city':'Tangier', 'is_urgent':False,
                 'basic_price':8000, 'basic_delivery_days':10, 'standard_price':12000, 'standard_delivery_days':20, 'premium_price':20000, 'premium_delivery_days':30},
            ]),
            ('security.fes', [
                {'title':'Gardiennage Immeuble', 'description':'Service de gardiennage pour immeubles et résidences. Agents formés et équipés.', 'price':5000, 'category':'Urgent Services', 'city':'Fes', 'is_urgent':False,
                 'basic_price':3500, 'basic_delivery_days':30, 'standard_price':5000, 'standard_delivery_days':30, 'premium_price':8000, 'premium_delivery_days':30},
                {'title':'Installation Système Sécurité', 'description':'Installation caméras, alarme, contrôle d\'accès et télésurveillance. Devis personnalisé.', 'price':8000, 'category':'Urgent Services', 'city':'Fes', 'is_urgent':False,
                 'basic_price':5000, 'basic_delivery_days':3, 'standard_price':8000, 'standard_delivery_days':7, 'premium_price':15000, 'premium_delivery_days':14},
                {'title':'Sécurité Événementielle', 'description':'Agents de sécurité pour événements, mariages, salons et concerts. Staff qualifié.', 'price':3000, 'category':'Urgent Services', 'city':'Fes', 'is_urgent':False,
                 'basic_price':2000, 'basic_delivery_days':1, 'standard_price':3000, 'standard_delivery_days':1, 'premium_price':5000, 'premium_delivery_days':1},
            ]),
        ]
        
        created_services = []
        for username, svcs in services_data:
            worker = User.query.filter_by(username=username).first()
            if worker:
                for sd in svcs:
                    s = Service.query.filter_by(title=sd['title'], worker_id=worker.id).first()
                    if not s:
                        s = Service(
                            title=sd['title'], description=sd['description'], price=sd['price'],
                            category=sd['category'], city=sd['city'], worker_id=worker.id,
                            is_active=True, is_urgent=sd.get('is_urgent', False),
                            basic_price=sd.get('basic_price', sd['price']),
                            basic_delivery_days=sd.get('basic_delivery_days', 1),
                            standard_price=sd.get('standard_price', sd['price']*1.5),
                            standard_delivery_days=sd.get('standard_delivery_days', 3),
                            premium_price=sd.get('premium_price', sd['price']*2),
                            premium_delivery_days=sd.get('premium_delivery_days', 7),
                            active_package='standard', views_count=random.randint(20, 150),
                            gig_tags=sd['category'].lower()+','+sd['city'].lower()
                        )
                        db.session.add(s)
                        db.session.flush()
                        created_services.append(s)
        db.session.commit()
        print(f'{len(created_services)} demo services created')
        
        # Create demo clients
        clients_data = [
            {'username':'client.casa', 'full_name':'Saad El Amrani', 'email':'saad@client.ma', 'password':'client123', 'city':'Casablanca', 'phone':'0711111111'},
            {'username':'client.rabat', 'full_name':'Latifa Benjelloun', 'email':'latifa@client.ma', 'password':'client123', 'city':'Rabat', 'phone':'0722222222'},
            {'username':'client.marrakech', 'full_name':'Reda Filali', 'email':'reda@client.ma', 'password':'client123', 'city':'Marrakech', 'phone':'0733333333'},
            {'username':'client.fes', 'full_name':'Imane Chafik', 'email':'imane@client.ma', 'password':'client123', 'city':'Fes', 'phone':'0744444444'},
            {'username':'client.tanger', 'full_name':'Yassine Berrada', 'email':'yassine@client.ma', 'password':'client123', 'city':'Tangier', 'phone':'0755555555'},
            {'username':'client.agadir', 'full_name':'Sara Moussaoui', 'email':'sara@client.ma', 'password':'client123', 'city':'Agadir', 'phone':'0766666666'},
        ]
        created_clients = []
        for cd in clients_data:
            c = User.query.filter_by(username=cd['username']).first()
            if not c:
                c = User(username=cd['username'], full_name=cd['full_name'], email=cd['email'],
                         password_hash=generate_password_hash(cd['password']), user_type='client',
                         city=cd['city'], is_active=True, phone=cd.get('phone'))
                db.session.add(c)
                db.session.flush()
                created_clients.append(c)
        db.session.commit()
        print(f'{len(created_clients)} demo clients created')
        
        # Create PAID bookings with invoices and reviews
        if created_clients and created_services:
            for i, client in enumerate(created_clients):
                # Book 3-4 services per client
                selected_services = random.sample(created_services, min(random.randint(3, 4), len(created_services)))
                for svc in selected_services:
                    # Create booking
                    b = Booking(service_id=svc.id, client_id=client.id, status='completed',
                                message=f'Reservation pour {svc.title}', 
                                created_at=datetime.utcnow()-timedelta(days=random.randint(1, 60)))
                    db.session.add(b)
                    db.session.flush()
                    
                    # Create payment
                    amount = svc.standard_price or svc.price
                    ref = 'LMQ' + ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=10))
                    p = Payment(user_id=client.id, amount=amount, type='service', reference=ref,
                                description=f'Paiement: {svc.title}', status='completed',
                                completed_at=datetime.utcnow()-timedelta(days=random.randint(0, 10)))
                    db.session.add(p)
                    db.session.flush()
                    
                    # Create invoice
                    tva_rate = 20.0
                    amount_ht = round(amount / (1 + tva_rate/100), 2)
                    amount_tva = round(amount - amount_ht, 2)
                    inv = Invoice(
                        payment_id=p.id, user_id=client.id, worker_id=svc.worker_id,
                        invoice_number=generate_invoice_number(),
                        amount_ht=amount_ht, tva_rate=tva_rate, amount_tva=amount_tva,
                        amount_ttc=amount, description=f'Facture: {svc.title}',
                        status='paid', paid_at=p.completed_at, booking_id=b.id,
                        items=f'[{{"label":"{svc.title}","qty":1,"unit_price":{amount},"total":{amount}}}]'
                    )
                    db.session.add(inv)
                    
                    # Create review for most bookings
                    if random.random() > 0.2:
                        worker = User.query.get(svc.worker_id)
                        comments_pool = [
                            'Excellent travail, très professionnel !',
                            'Intervention rapide et soignée. Merci !',
                            'Très satisfait du résultat. Je recommande.',
                            'Service impeccable, prix juste.',
                            'Prestataire ponctuel et efficace. À refaire !',
                            'Qualité exceptionnelle, délais respectés.',
                            'Communication fluide et travail soigné.',
                            'Super expérience, je referai appel à lui.',
                        ]
                        r = Review(worker_id=svc.worker_id, client_id=client.id,
                                   rating=random.choice([4, 5]),
                                   comment=random.choice(comments_pool))
                        db.session.add(r)
            db.session.commit()
            print(f'PAID bookings with invoices and reviews created successfully')
        
        # Create diverse annonces
        annonces_data = [
            {'title':'Cherche électricien urgent Casa', 'description':'Panne électrique dans mon appartement, besoin d\'intervention rapide.', 'category':'Électricité', 'city':'Casablanca', 'price':300, 'author':'client.casa'},
            {'title':'Installation éclairage LED boutique', 'description':'Cherche électricien pour installer éclairage LED dans ma boutique.', 'category':'Électricité', 'city':'Casablanca', 'price':2000, 'author':'client.casa'},
            {'title':'Peinture salon 40m2', 'description':'Besoin de peindre mon salon, couleur blanche mate.', 'category':'Peinture', 'city':'Casablanca', 'price':3500, 'author':'client.rabat'},
            {'title':'Papier peint chambre', 'description':'Installation papier peint dans 2 chambres.', 'category':'Peinture', 'city':'Rabat', 'price':1500, 'author':'client.rabat'},
            {'title':'Placard dressing sur mesure', 'description':'Cherche menuisier pour dressing sur mesure 3 portes.', 'category':'Menuiserie', 'city':'Rabat', 'price':6000, 'author':'client.rabat'},
            {'title':'Cuisine équipée complète', 'description':'Installation cuisine équipée dans nouvel appartement.', 'category':'Menuiserie', 'city':'Rabat', 'price':18000, 'author':'client.casa'},
            {'title':'Fuite sous évier urgent', 'description':'Fuite importante sous l\'évier, inondation imminente !', 'category':'Plomberie', 'city':'Marrakech', 'price':400, 'author':'client.marrakech'},
            {'title':'Installation chauffe-eau neuf', 'description':'Remplacement chauffe-eau 100L, fourniture et pose.', 'category':'Plomberie', 'city':'Marrakech', 'price':2500, 'author':'client.marrakech'},
            {'title':'Zellige salle de bain', 'description':'Pose zellige 5m2 dans salle de bain riad.', 'category':'Mosaïque', 'city':'Fes', 'price':5000, 'author':'client.fes'},
            {'title':'Restauration zellige ancien', 'description':'Restauration zellige dégradé dans patio riad.', 'category':'Mosaïque', 'city':'Fes', 'price':8000, 'author':'client.fes'},
            {'title':'Création site e-commerce', 'description':'Besoin d\'un développeur pour site e-commerce sous Shopify/WooCommerce.', 'category':'IT & Technology', 'city':'Casablanca', 'price':15000, 'author':'client.casa'},
            {'title':'Logo et charte graphique', 'description':'Création logo moderne pour startup fintech.', 'category':'Marketing & Design', 'city':'Rabat', 'price':5000, 'author':'client.rabat'},
            {'title':'Traduction contrat FR-EN', 'description':'Traduction assermentée d\'un contrat de distribution.', 'category':'Legal & Accounting', 'city':'Tangier', 'price':800, 'author':'client.tanger'},
            {'title':'Nettoyage fin de bail', 'description':'Grand nettoyage appartement 80m2 avant état des lieux.', 'category':'Cleaning & Housekeeping', 'city':'Agadir', 'price':1200, 'author':'client.agadir'},
            {'title':'Déménagement Casa-Rabat', 'description':'Déménagement d\'un appartement 3 pièces avec emballage.', 'category':'Transport & Logistics', 'city':'Casablanca', 'price':3500, 'author':'client.casa'},
        ]
        
        for ad in annonces_data:
            author = User.query.filter_by(username=ad['author']).first()
            if author:
                a = Annonce.query.filter_by(title=ad['title']).first()
                if not a:
                    a = Annonce(title=ad['title'], description=ad['description'],
                                category=ad['category'], city=ad['city'], price=ad['price'],
                                author_id=author.id, type='demande_service')
                    db.session.add(a)
        db.session.commit()
        print(f'{len(annonces_data)} demo annonces created')
        
        # Create demo messages between workers and clients
        messages_data = [
            ('youssef.casa', 'client.casa', 'Bonjour, êtes-vous disponible demain pour une intervention électrique ?', True),
            ('client.casa', 'youssef.casa', 'Oui, je suis disponible vers 14h. Quelle est l\'adresse ?', False),
            ('youssef.casa', 'client.casa', 'Parfait, je serai là à 14h précises. Merci !', True),
            ('karim.marrakech', 'client.marrakech', 'J\'ai une fuite sous mon évier, pouvez-vous venir rapidement ?', True),
            ('client.marrakech', 'karim.marrakech', 'Oui c\'est urgent, je suis à la Médina près de la porte Bab Agnaou.', False),
            ('hassan.fes', 'client.fes', 'Bonjour, je peux voir votre patio pour évaluer le zellige ?', True),
            ('client.fes', 'hassan.fes', 'Oui bien sûr, venez quand vous voulez cette semaine.', False),
            ('tech.casa', 'client.casa', 'Bonjour, j\'ai bien reçu votre cahier des charges. Je vous envoie un devis sous 24h.', True),
            ('client.casa', 'tech.casa', 'Merci, j\'attends votre retour avec impatience.', False),
            ('design.rabat', 'client.rabat', 'Voici les 3 propositions de logo. Quelle direction préférez-vous ?', True),
            ('coach.casa', 'client.casa', 'Votre première séance de coaching est confirmée pour lundi 10h.', True),
            ('btp.casa', 'client.casa', 'Nous pouvons démarrer les travaux la semaine prochaine. Le planning est prêt.', True),
        ]
        for sender_u, receiver_u, content, is_read in messages_data:
            sender = User.query.filter_by(username=sender_u).first()
            receiver = User.query.filter_by(username=receiver_u).first()
            if sender and receiver:
                m = Message.query.filter_by(sender_id=sender.id, receiver_id=receiver.id, content=content).first()
                if not m:
                    db.session.add(Message(sender_id=sender.id, receiver_id=receiver.id,
                                          content=content, is_read=is_read))
        db.session.commit()
        print('Demo messages created')
        
    # Print summary
    print('\n========== DEMO DATA SUMMARY ==========')
    print(f'Artisans: {User.query.filter_by(worker_subtype="artisan").count()}')
    print(f'Freelancers: {User.query.filter_by(worker_subtype="freelancer").count()}')
    print(f'Auto-Entrepreneurs: {User.query.filter_by(worker_subtype="auto_entrepreneur").count()}')
    print(f'Entreprises: {User.query.filter_by(worker_subtype="entreprise").count()}')
    print(f'Clients: {User.query.filter_by(user_type="client").count()}')
    print(f'Services: {Service.query.count()}')
    print(f'Annonces: {Annonce.query.count()}')
    print(f'Bookings: {Booking.query.count()}')
    print(f'PAID Bookings: {Booking.query.filter_by(status="completed").count()}')
    print(f'Payments: {Payment.query.count()}')
    print(f'Invoices: {Invoice.query.count()}')
    print(f'Reviews: {Review.query.count()}')
    print(f'Messages: {Message.query.count()}')
    print('======================================\n')

    # ==================== NAMED ACCOUNTS + CASH SIMULATIONS ====================
    
    # 1. Create named accounts
    named_accounts = [
        {'username':'client1', 'full_name':'Said El Amrani', 'email':'client1@lmawqef.ma',
         'password':'client123', 'user_type':'client', 'city':'Casablanca', 'phone':'0711111111'},
        {'username':'entreprise1', 'full_name':'BTP Construction Plus SARL', 'email':'entreprise1@lmawqef.ma',
         'password':'entreprise123', 'user_type':'entreprise', 'worker_subtype':'entreprise',
         'city':'Casablanca', 'phone':'0722222222', 'profession_title':'Entreprise BTP | Construction & Rénovation',
         'profession':'BTP', 'skills':'Gros oeuvre, Second oeuvre, Rénovation, Maçonnerie',
         'description':'Entreprise de construction et rénovation à Casablanca. Plus de 15 ans d\'expérience dans le bâtiment.',
         'company_name':'BTP Construction Plus SARL', 'rc_number':'RC-999001', 'ice_number':'009990010000089'},
        {'username':'freelancer1', 'full_name':'Youssef Bennani', 'email':'freelancer1@lmawqef.ma',
         'password':'freelancer123', 'user_type':'worker', 'worker_subtype':'freelancer',
         'city':'Rabat', 'phone':'0733333333', 'profession_title':'Développeur Web Full Stack',
         'profession':'Développeur', 'skills':'React, Node.js, Python, Django, Flutter',
         'description':'Développeur full stack passionné avec 6 ans d\'expérience. Spécialisé dans les applications web et mobiles.'},
    ]
    
    for acc in named_accounts:
        u = User.query.filter_by(username=acc['username']).first()
        if not u:
            u = User(
                username=acc['username'],
                full_name=acc['full_name'],
                email=acc['email'],
                password_hash=generate_password_hash(acc['password']),
                user_type=acc.get('user_type', 'client'),
                worker_subtype=acc.get('worker_subtype'),
                city=acc['city'],
                phone=acc.get('phone'),
                profession_title=acc.get('profession_title'),
                skills=acc.get('skills'),
                description=acc.get('description'),
                company_name=acc.get('company_name'),
                rc_number=acc.get('rc_number'),
                ice_number=acc.get('ice_number'),
                is_active=True,
                points=500 if acc['user_type'] != 'client' else 0,
                wallet_balance=5000.0 if acc['user_type'] == 'client' else 0.0
            )
            db.session.add(u)
            db.session.flush()
            lvl = Level.query.filter(Level.min_points <= u.points).order_by(Level.min_points.desc()).first()
            if lvl: u.level_id = lvl.id
            print(f"Created named account: {acc['username']} / {acc['password']}")
    db.session.commit()
    
    # 2. Create a service for freelancer1
    freelancer1 = User.query.filter_by(username='freelancer1').first()
    entreprise1 = User.query.filter_by(username='entreprise1').first()
    client1 = User.query.filter_by(username='client1').first()
    
    if freelancer1 and Service.query.filter_by(worker_id=freelancer1.id).count() == 0:
        svc = Service(
            title='Création Site E-commerce Professionnel',
            description='Développement complet de votre boutique en ligne avec panier, paiement et dashboard admin.',
            price=8000, category='IT & Technology', city='Rabat',
            worker_id=freelancer1.id, is_active=True, is_urgent=False,
            basic_price=5000, basic_delivery_days=14,
            standard_price=8000, standard_delivery_days=21,
            premium_price=15000, premium_delivery_days=35,
            active_package='standard'
        )
        db.session.add(svc)
        db.session.commit()
        print(f"Created service for freelancer1: {svc.title}")
    
    # 3. Create a service for entreprise1
    if entreprise1 and Service.query.filter_by(worker_id=entreprise1.id).count() == 0:
        svc2 = Service(
            title='Rénovation Complète Appartement',
            description='Rénovation complète : plomberie, électricité, peinture, sols et finitions. Clé en main.',
            price=45000, category='Construction & Renovation', city='Casablanca',
            worker_id=entreprise1.id, is_active=True, is_urgent=False,
            basic_price=35000, basic_delivery_days=30,
            standard_price=45000, standard_delivery_days=45,
            premium_price=65000, premium_delivery_days=60,
            active_package='standard'
        )
        db.session.add(svc2)
        db.session.commit()
        print(f"Created service for entreprise1: {svc2.title}")
    
    # 4. Simulate CASH bookings with negotiations
    # Booking 1: client1 books freelancer1 - CASH after service - price negotiated
    service_fl = Service.query.filter_by(worker_id=freelancer1.id).first() if freelancer1 else None
    service_ent = Service.query.filter_by(worker_id=entreprise1.id).first() if entreprise1 else None
    
    if client1 and service_fl:
        # Check if booking already exists
        existing = Booking.query.filter_by(client_id=client1.id, service_id=service_fl.id).first()
        if not existing:
            b1 = Booking(
                client_id=client1.id,
                service_id=service_fl.id,
                message='J\'ai besoin d\'un site e-commerce pour ma boutique de vêtements traditionnels. Budget serré, pouvez-vous faire 7000 MAD ?',
                status='completed',
                payment_method='cash',
                cash_payment_timing='after_service',
                payment_status='paid',
                negotiated_price=7000,
                client_proposed_price=7000,
                worker_proposed_price=8000,
                price_negotiation_status='agreed',
                commission_amount=700,
                created_at=datetime.utcnow() - timedelta(days=15),
                updated_at=datetime.utcnow() - timedelta(days=2)
            )
            db.session.add(b1)
            db.session.flush()
            
            # Commission
            db.session.add(Commission(worker_id=freelancer1.id, booking_id=b1.id, amount=700, rate_percent=10))
            
            # Invoice
            tva = 20.0
            amount_ht = round(7000 / 1.20, 2)
            inv1 = Invoice(
                user_id=client1.id, worker_id=freelancer1.id,
                payment_id=None, invoice_number='INV-CASH-001',
                amount_ht=amount_ht, tva_rate=tva,
                amount_tva=round(7000 - amount_ht, 2),
                amount_ttc=7000, description=f'Facture: {service_fl.title} (Paiement en espèces)',
                status='paid', paid_at=datetime.utcnow() - timedelta(days=2),
                booking_id=b1.id,
                items=f'[{{"label":"{service_fl.title}","qty":1,"unit_price":7000,"total":7000}}]'
            )
            db.session.add(inv1)
            
            # Review
            db.session.add(Review(
                worker_id=freelancer1.id, client_id=client1.id,
                rating=5, comment='Excellent travail ! Le site est magnifique et le paiement en espèces était pratique. Je recommande vivement.'
            ))
            
            # Notification
            db.session.add(Notification(
                user_id=freelancer1.id,
                title='Réservation payée en espèces',
                message=f'{client1.full_name} a confirmé le paiement en espèces de 7000 MAD pour "{service_fl.title}"',
                type='success'
            ))
            db.session.commit()
            print('Created CASH booking 1: client1 -> freelancer1 (7000 MAD, after service)')
    
    # Booking 2: client1 books entreprise1 - CASH with escrow
    if client1 and service_ent:
        existing2 = Booking.query.filter_by(client_id=client1.id, service_id=service_ent.id).first()
        if not existing2:
            b2 = Booking(
                client_id=client1.id,
                service_id=service_ent.id,
                message='Rénovation complète de mon appartement de 80m2 à Casa Centre. Je propose 40000 MAD au lieu de 45000.',
                status='accepted',
                payment_method='cash',
                cash_payment_timing='escrow',
                payment_status='pending',
                negotiated_price=40000,
                client_proposed_price=40000,
                worker_proposed_price=45000,
                price_negotiation_status='pending',  # Still negotiating
                commission_amount=4000,
                created_at=datetime.utcnow() - timedelta(days=5),
                updated_at=datetime.utcnow() - timedelta(days=3)
            )
            db.session.add(b2)
            db.session.flush()
            
            db.session.add(Commission(worker_id=entreprise1.id, booking_id=b2.id, amount=4000, rate_percent=10))
            
            # Notification for negotiation
            db.session.add(Notification(
                user_id=entreprise1.id,
                title='Nouvelle proposition de prix',
                message=f'{client1.full_name} propose 40000 MAD pour "{service_ent.title}" (au lieu de 45000). Acceptez ou contre-proposez.',
                type='info'
            ))
            db.session.commit()
            print('Created CASH booking 2: client1 -> entreprise1 (40000 MAD proposed, escrow, negotiating)')
    
    # Booking 3: Another client with different worker - cash after service
    client2 = User.query.filter_by(username='client.casa').first()
    worker_youssef = User.query.filter_by(username='youssef.casa').first()
    service_elec = Service.query.filter_by(worker_id=worker_youssef.id).first() if worker_youssef else None
    
    if client2 and worker_youssef and service_elec:
        existing3 = Booking.query.filter_by(client_id=client2.id, service_id=service_elec.id).first()
        if not existing3:
            b3 = Booking(
                client_id=client2.id,
                service_id=service_elec.id,
                message='Installation électrique complète pour mon nouvel appartement. Je préfère payer en espèces après le travail.',
                status='completed',
                payment_method='cash',
                cash_payment_timing='after_service',
                payment_status='paid',
                negotiated_price=2200,
                client_proposed_price=2000,
                worker_proposed_price=2500,
                price_negotiation_status='agreed',
                commission_amount=220,
                created_at=datetime.utcnow() - timedelta(days=20),
                updated_at=datetime.utcnow() - timedelta(days=5)
            )
            db.session.add(b3)
            db.session.flush()
            
            db.session.add(Commission(worker_id=worker_youssef.id, booking_id=b3.id, amount=220, rate_percent=10))
            
            inv3 = Invoice(
                user_id=client2.id, worker_id=worker_youssef.id,
                payment_id=None, invoice_number='INV-CASH-002',
                amount_ht=round(2200/1.20, 2), tva_rate=20.0,
                amount_tva=round(2200 - round(2200/1.20, 2), 2),
                amount_ttc=2200, description=f'Facture: {service_elec.title} (Paiement en espèces)',
                status='paid', paid_at=datetime.utcnow() - timedelta(days=5),
                booking_id=b3.id,
                items=f'[{{"label":"{service_elec.title}","qty":1,"unit_price":2200,"total":2200}}]'
            )
            db.session.add(inv3)
            
            db.session.add(Review(
                worker_id=worker_youssef.id, client_id=client2.id,
                rating=4, comment='Très bon travail, installation propre. Paiement en espèces sans problème.'
            ))
            db.session.commit()
            print('Created CASH booking 3: client.casa -> youssef.casa (2200 MAD, after service)')
    
    # 5. Create more cash booking examples with different statuses
    client_rabat = User.query.filter_by(username='client.rabat').first()
    worker_omar = User.query.filter_by(username='omar.rabat').first()
    service_menu = Service.query.filter_by(worker_id=worker_omar.id).first() if worker_omar else None
    
    if client_rabat and worker_omar and service_menu:
        existing4 = Booking.query.filter_by(client_id=client_rabat.id, service_id=service_menu.id).first()
        if not existing4:
            b4 = Booking(
                client_id=client_rabat.id,
                service_id=service_menu.id,
                message='Dressing sur mesure pour ma chambre. Budget 4500 MAD.',
                status='accepted',
                payment_method='cash',
                cash_payment_timing='after_service',
                payment_status='pending',
                negotiated_price=4500,
                client_proposed_price=4500,
                price_negotiation_status='agreed',
                commission_amount=450,
                created_at=datetime.utcnow() - timedelta(days=3)
            )
            db.session.add(b4)
            db.session.flush()
            db.session.add(Commission(worker_id=worker_omar.id, booking_id=b4.id, amount=450, rate_percent=10))
            db.session.commit()
            print('Created CASH booking 4: client.rabat -> omar.rabat (4500 MAD, after service, pending payment)')
    
    # Print final summary with named accounts
    print('\n========== NAMED ACCOUNTS ==========')
    print('client1 / client123 (Client)')
    print('entreprise1 / entreprise123 (Entreprise BTP)')
    print('freelancer1 / freelancer123 (Freelancer Dev)')
    print('\n========== CASH BOOKINGS SUMMARY ==========')
    cash_bookings = Booking.query.filter_by(payment_method='cash').all()
    print(f'Total cash bookings: {len(cash_bookings)}')
    for cb in cash_bookings:
        svc = Service.query.get(cb.service_id)
        print(f'  - {cb.status} | {cb.cash_payment_timing} | {cb.negotiated_price} MAD | "{svc.title if svc else "N/A"}"')
    print('==========================================\n')


