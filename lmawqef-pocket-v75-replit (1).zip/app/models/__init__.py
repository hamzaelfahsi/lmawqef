from app.extensions import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import json

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)
    worker_subtype = db.Column(db.String(20), nullable=True)
    skills = db.Column(db.Text, nullable=True)
    description = db.Column(db.Text, nullable=True)
    avatar = db.Column(db.String(200), default='default-avatar.png')
    cover_photo = db.Column(db.String(200), nullable=True)
    profile_video_url = db.Column(db.String(300), nullable=True)
    profession_title = db.Column(db.String(150), nullable=True)
    # Fiverr-style fields
    languages = db.Column(db.Text, nullable=True)  # JSON: [{"language":"Français","level":"Natif"}]
    education = db.Column(db.Text, nullable=True)  # JSON: [{"degree":"","school":"","year":""}]
    certifications = db.Column(db.Text, nullable=True)  # JSON: [{"name":"","issuer":"","year":""}]
    response_time_hours = db.Column(db.Integer, default=24)
    money_back_guarantee = db.Column(db.Boolean, default=True)
    # Social links
    website_url = db.Column(db.String(300), nullable=True)
    linkedin_url = db.Column(db.String(300), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    address = db.Column(db.String(300), nullable=True)
    company_name = db.Column(db.String(150), nullable=True)
    rc_number = db.Column(db.String(50), nullable=True)
    ice_number = db.Column(db.String(50), nullable=True)
    # Gamification
    points = db.Column(db.Integer, default=0)
    level_id = db.Column(db.Integer, db.ForeignKey('levels.id'), nullable=True)
    response_time_avg = db.Column(db.Float, default=0)
    completion_rate = db.Column(db.Float, default=100.0)
    featured_until = db.Column(db.DateTime, nullable=True)
    is_featured = db.Column(db.Boolean, default=False)
    # Subscription
    subscription_plan_id = db.Column(db.Integer, db.ForeignKey('subscription_plans.id'), nullable=True)
    subscription_start = db.Column(db.DateTime, nullable=True)
    subscription_end = db.Column(db.DateTime, nullable=True)
    subscription_active = db.Column(db.Boolean, default=False)
    # Annonces counters
    free_announces_used = db.Column(db.Integer, default=0)
    announces_month_used = db.Column(db.Integer, default=0)
    announces_month_reset = db.Column(db.DateTime, default=datetime.utcnow)
    # Insurance
    insurance_active = db.Column(db.Boolean, default=False)
    insurance_expires = db.Column(db.DateTime, nullable=True)
    # Wallet
    wallet_balance = db.Column(db.Float, default=0.0)
    # Identity verification badge
    is_identity_verified = db.Column(db.Boolean, default=False)
    # GPS tracking (Uber-style)
    is_tracking_enabled = db.Column(db.Boolean, default=False)
    last_latitude = db.Column(db.Float, nullable=True)
    last_longitude = db.Column(db.Float, nullable=True)
    last_location_update = db.Column(db.DateTime, nullable=True)
    # Super Worker badge
    is_super_worker = db.Column(db.Boolean, default=False)
    # RTL preference
    prefers_rtl = db.Column(db.Boolean, default=False)
    # Relationships
    services = db.relationship('Service', backref='worker', lazy=True, cascade='all, delete-orphan')
    reviews_given = db.relationship('Review', foreign_keys='Review.client_id', backref='client', lazy=True)
    reviews_received = db.relationship('Review', foreign_keys='Review.worker_id', backref='reviewed_worker', lazy=True)
    bookings = db.relationship('Booking', foreign_keys='Booking.client_id', backref='client', lazy=True)
    portfolio_items = db.relationship('PortfolioItem', backref='user', lazy=True, cascade='all, delete-orphan')
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)
    notifications = db.relationship('Notification', backref='user', lazy=True, cascade='all, delete-orphan')
    annonces = db.relationship('Annonce', backref='author', lazy=True, cascade='all, delete-orphan')
    payments = db.relationship('Payment', backref='user', lazy=True)
    badges = db.relationship('UserBadge', backref='user', lazy=True, cascade='all, delete-orphan')
    devis_list = db.relationship('Devis', backref='worker_user', lazy=True, cascade='all, delete-orphan')
    commissions = db.relationship('Commission', backref='worker_comm', lazy=True)
    availability_slots = db.relationship('Availability', backref='user_avail', lazy=True, cascade='all, delete-orphan')

    def average_rating(self):
        reviews = Review.query.filter_by(worker_id=self.id).all()
        if not reviews: return 0
        return round(sum(r.rating for r in reviews) / len(reviews), 1)

    def review_count(self):
        return Review.query.filter_by(worker_id=self.id).count()

    def has_active_subscription(self):
        if not self.subscription_active or not self.subscription_end: return False
        return datetime.utcnow() < self.subscription_end

    def get_monthly_annonce_limit(self):
        if self.has_active_subscription() and self.subscription_plan:
            return self.subscription_plan.annonce_limit
        return 0

    def get_announce_price(self):
        config = AppConfig.get()
        if self.has_active_subscription() and self.subscription_plan.price == 0:
            return 0
        return config.annonce_price

    def can_post_free_announce(self):
        config = AppConfig.get()
        return self.free_announces_used < config.free_announces_new_user

    def can_post_monthly_announce(self):
        if self.announces_month_reset < datetime.utcnow() - timedelta(days=30):
            self.announces_month_used = 0
            self.announces_month_reset = datetime.utcnow()
            db.session.commit()
        limit = self.get_monthly_annonce_limit()
        return self.announces_month_used < limit and limit > 0

    def get_level(self):
        if self.level_id:
            return Level.query.get(self.level_id)
        # Auto-assign based on points
        level = Level.query.filter(Level.min_points <= self.points).order_by(Level.min_points.desc()).first()
        if level and self.level_id != level.id:
            self.level_id = level.id
            db.session.commit()
        return level

    def get_badges_list(self):
        return Badge.query.join(UserBadge).filter(UserBadge.user_id == self.id).all()


class Service(db.Model):
    __tablename__ = 'services'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    city = db.Column(db.String(50), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    image = db.Column(db.String(200), default='default-service.jpg')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    address = db.Column(db.String(300), nullable=True)
    views_count = db.Column(db.Integer, default=0)
    is_urgent = db.Column(db.Boolean, default=False)
    urgency_multiplier = db.Column(db.Float, default=1.0)
    # Fiverr-style Gig fields
    gig_tags = db.Column(db.Text, nullable=True)
    gig_faq = db.Column(db.Text, nullable=True)
    video_url = db.Column(db.String(300), nullable=True)
    requirements = db.Column(db.Text, nullable=True)
    # Packages (Fiverr style: Basic/Standard/Premium)
    basic_price = db.Column(db.Float, default=0)
    basic_delivery_days = db.Column(db.Integer, default=1)
    basic_description = db.Column(db.Text, nullable=True)
    basic_includes = db.Column(db.Text, nullable=True)
    standard_price = db.Column(db.Float, default=0)
    standard_delivery_days = db.Column(db.Integer, default=3)
    standard_description = db.Column(db.Text, nullable=True)
    standard_includes = db.Column(db.Text, nullable=True)
    premium_price = db.Column(db.Float, default=0)
    premium_delivery_days = db.Column(db.Integer, default=7)
    premium_description = db.Column(db.Text, nullable=True)
    premium_includes = db.Column(db.Text, nullable=True)
    active_package = db.Column(db.String(20), default='basic')
    bookings = db.relationship('Booking', backref='service', lazy=True, cascade='all, delete-orphan')
    images = db.relationship('ServiceImage', backref='service', lazy=True, cascade='all, delete-orphan')


class ServiceImage(db.Model):
    __tablename__ = 'service_images'
    id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    filename = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortfolioItem(db.Model):
    __tablename__ = 'portfolio_items'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    filename = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    commission_amount = db.Column(db.Float, default=0)
    commission_paid = db.Column(db.Boolean, default=False)
    insurance_used = db.Column(db.Boolean, default=False)
    devis_id = db.Column(db.Integer, db.ForeignKey('devis.id'), nullable=True)
    # Scheduling
    scheduled_date = db.Column(db.Date, nullable=True)
    scheduled_time = db.Column(db.String(10), nullable=True)
    scheduled_end_time = db.Column(db.String(10), nullable=True)
    # Escrow / confirmation
    escrow_status = db.Column(db.String(20), default='none')  # none, held, released, refunded
    client_confirmed = db.Column(db.Boolean, default=False)
    worker_confirmed = db.Column(db.Boolean, default=False)
    confirmed_at = db.Column(db.DateTime, nullable=True)
    # Before/After photos
    before_photo = db.Column(db.String(200), nullable=True)
    after_photo = db.Column(db.String(200), nullable=True)
    # Worker en route (GPS)
    worker_started_at = db.Column(db.DateTime, nullable=True)
    worker_arrived_at = db.Column(db.DateTime, nullable=True)
    # ==================== PRICE NEGOTIATION ====================
    # Negotiated price (final agreed price)
    negotiated_price = db.Column(db.Float, nullable=True)
    # Price proposed by client
    client_proposed_price = db.Column(db.Float, nullable=True)
    # Price proposed by worker
    worker_proposed_price = db.Column(db.Float, nullable=True)
    # Negotiation status: pending, client_accepted, worker_accepted, agreed, rejected
    price_negotiation_status = db.Column(db.String(20), default='pending')
    # ==================== PAYMENT METHOD ====================
    # Payment method: 'app' (in-app wallet), 'cash' (physical cash)
    payment_method = db.Column(db.String(20), default='app')
    # For cash payments: 'escrow' (block via app), 'after_service' (pay after completion)
    cash_payment_timing = db.Column(db.String(20), default='after_service')
    # Final payment status
    payment_status = db.Column(db.String(20), default='pending')  # pending, paid, refunded


class Commission(db.Model):
    __tablename__ = 'commissions'
    id = db.Column(db.Integer, primary_key=True)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    rate_percent = db.Column(db.Float, default=10.0)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    paid_at = db.Column(db.DateTime, nullable=True)


class Devis(db.Model):
    __tablename__ = 'devis'
    id = db.Column(db.Integer, primary_key=True)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    client_name = db.Column(db.String(100), nullable=False)
    client_email = db.Column(db.String(120), nullable=False)
    client_phone = db.Column(db.String(20), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    items = db.Column(db.Text, nullable=False)
    total_ht = db.Column(db.Float, nullable=False)
    tva_rate = db.Column(db.Float, default=20.0)
    total_ttc = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='draft')  # draft, sent, signed, accepted, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until = db.Column(db.DateTime, nullable=True)
    # Electronic signatures
    worker_signature = db.Column(db.Text, nullable=True)  # base64 PNG
    worker_signed_at = db.Column(db.DateTime, nullable=True)
    client_signature = db.Column(db.Text, nullable=True)  # base64 PNG
    client_signed_at = db.Column(db.DateTime, nullable=True)
    bookings = db.relationship('Booking', backref='devis_ref', lazy=True)


class Message(db.Model):
    __tablename__ = 'messages'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)


class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50), default='info')
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    link = db.Column(db.String(300), nullable=True)


class Annonce(db.Model):
    __tablename__ = 'annonces'
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(30), nullable=False)
    category = db.Column(db.String(50), nullable=True)
    city = db.Column(db.String(50), nullable=True)
    price = db.Column(db.Float, nullable=True)
    is_paid = db.Column(db.Boolean, default=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id'), nullable=True)
    image = db.Column(db.String(200), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    views_count = db.Column(db.Integer, default=0)


class AnnonceOffer(db.Model):
    __tablename__ = 'annonce_offers'
    id = db.Column(db.Integer, primary_key=True)
    annonce_id = db.Column(db.Integer, db.ForeignKey('annonces.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    proposed_price = db.Column(db.Float, nullable=True)
    estimated_days = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # Relationships
    annonce = db.relationship('Annonce', backref='offers')
    worker = db.relationship('User', backref='annonce_offers')


class Payment(db.Model):
    __tablename__ = 'payments'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), default='MAD')
    type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='pending')
    reference = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    # Escrow fields
    is_escrow = db.Column(db.Boolean, default=False)
    escrow_status = db.Column(db.String(20), default='none')  # none, held, released, refunded
    released_at = db.Column(db.DateTime, nullable=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)


class Invoice(db.Model):
    __tablename__ = 'invoices'
    id = db.Column(db.Integer, primary_key=True)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)  # client
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # prestataire (optionnel)
    invoice_number = db.Column(db.String(50), unique=True, nullable=False)
    amount_ht = db.Column(db.Float, default=0)
    tva_rate = db.Column(db.Float, default=20.0)
    amount_tva = db.Column(db.Float, default=0)
    amount_ttc = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='issued')  # issued, paid, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    paid_at = db.Column(db.DateTime, nullable=True)
    # Lien vers le booking si paiement de service
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=True)
    # Ligne items JSON
    items = db.Column(db.Text, nullable=True)
    payment = db.relationship('Payment', backref='invoice', uselist=False)
    client = db.relationship('User', foreign_keys=[user_id], backref='invoices_received')
    worker = db.relationship('User', foreign_keys=[worker_id], backref='invoices_issued')


class SubscriptionPlan(db.Model):
    __tablename__ = 'subscription_plans'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    annonce_limit = db.Column(db.Integer, default=0)
    features = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    target_type = db.Column(db.String(30), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    subscribers = db.relationship('User', backref='subscription_plan', lazy=True)


class AppConfig(db.Model):
    __tablename__ = 'app_config'
    id = db.Column(db.Integer, primary_key=True)
    annonce_price = db.Column(db.Float, default=20.0)
    free_announces_new_user = db.Column(db.Integer, default=5)
    annonce_duration_days = db.Column(db.Integer, default=30)
    contact_email = db.Column(db.String(120), default='info@lmawqef.ma')
    contact_phone = db.Column(db.String(20), default='+212 5XX-XXXXXX')
    commission_rate = db.Column(db.Float, default=10.0)
    insurance_price = db.Column(db.Float, default=50.0)
    featured_profile_price = db.Column(db.Float, default=100.0)
    urgency_multiplier = db.Column(db.Float, default=1.5)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    @staticmethod
    def get():
        config = AppConfig.query.first()
        if not config:
            config = AppConfig()
            db.session.add(config)
            db.session.commit()
        return config


class ContactMessage(db.Model):
    __tablename__ = 'contact_messages'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)


class AdminRole(db.Model):
    __tablename__ = 'admin_roles'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    can_manage_users = db.Column(db.Boolean, default=True)
    can_manage_services = db.Column(db.Boolean, default=True)
    can_manage_bookings = db.Column(db.Boolean, default=True)
    can_manage_annonces = db.Column(db.Boolean, default=True)
    can_manage_subscriptions = db.Column(db.Boolean, default=True)
    can_manage_payments = db.Column(db.Boolean, default=True)
    can_manage_admins = db.Column(db.Boolean, default=False)
    can_edit_config = db.Column(db.Boolean, default=False)
    can_view_analytics = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref='admin_role')


# ==================== GAMIFICATION ====================

class Level(db.Model):
    __tablename__ = 'levels'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    min_points = db.Column(db.Integer, nullable=False)
    max_points = db.Column(db.Integer, nullable=True)
    icon = db.Column(db.String(50), default='fa-star')
    color = db.Column(db.String(20), default='#0d9488')
    benefits = db.Column(db.Text, nullable=True)


class Badge(db.Model):
    __tablename__ = 'badges'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=False)
    icon = db.Column(db.String(50), default='fa-award')
    color = db.Column(db.String(20), default='#f59e0b')
    condition_type = db.Column(db.String(50), nullable=False)
    condition_value = db.Column(db.Integer, nullable=False)
    points_reward = db.Column(db.Integer, default=0)


class UserBadge(db.Model):
    __tablename__ = 'user_badges'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    badge_id = db.Column(db.Integer, db.ForeignKey('badges.id'), nullable=False)
    earned_at = db.Column(db.DateTime, default=datetime.utcnow)
    badge = db.relationship('Badge', backref='earned_by')


class Availability(db.Model):
    __tablename__ = 'availability'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.String(10), nullable=False)
    end_time = db.Column(db.String(10), nullable=False)
    is_available = db.Column(db.Boolean, default=True)


# ==================== CATEGORIES & CITIES ====================

class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

CATEGORIES = [
    'IT & Technology', 'Construction & Renovation', 'Cleaning & Housekeeping',
    'Transport & Logistics', 'Plumbing & Electrical', 'Carpentry & Woodwork',
    'Painting & Decoration', 'Gardening & Landscaping', 'Automotive & Mechanics',
    'Education & Tutoring', 'Health & Wellness', 'Photography & Events',
    'Legal & Accounting', 'Marketing & Design', 'Urgent Services', 'Other'
]

MOROCCAN_CITIES = [
    'Casablanca', 'Rabat', 'Marrakech', 'Fes', 'Tangier',
    'Agadir', 'Oujda', 'Kenitra', 'Tetouan', 'Safi',
    'El Jadida', 'Nador', 'Khouribga', 'Beni Mellal', 'Mohammedia',
    'Laayoune', 'Dakhla', 'Essaouira', 'Taza', 'Settat',
    'Berrechid', 'Khemisset', 'Ouarzazate', 'Al Hoceima', 'Errachidia',
    'Meknes', 'Sale', 'Sidi Slimane', 'Guelmim', 'Tiznit',
    'Taroudant', 'Kalaat M Gouna', 'Ifrane', 'Sefrou', 'Azrou',
    'Berkane', 'Taourirt', 'Inezgane', 'Ait Melloul', 'Lqliaa',
    'Midelt', 'Jerada', 'Fkih Ben Salah', 'Youssoufia', 'Sidi Bennour',
    'Oued Zem', 'Bouznika', 'Sidi Kacem', 'Martil', 'Fnideq',
    'Temara', 'Skhirat', 'Benslimane', 'Biougra', 'Ahfir',
    'Zagora', 'Chefchaouen', 'Larache', 'Ksar El Kebir', 'Tan-Tan',
    'Smara', 'Boujdour', 'Sidi Ifni', 'Tata', 'Zemamra',
    'Guercif', 'Had Kourt', 'Sidi Yahya', 'Bir Jdid', 'Ain El Aouda'
]

ANNONCE_TYPES = [
    ('recrutement', 'Recrutement de profils'),
    ('demande_service', 'Demande de service'),
    ('offre_service', 'Offre de service')
]

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# ==================== HELPERS ====================

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file, folder):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        filename = f"{name}_{int(datetime.utcnow().timestamp())}{ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], folder, filename)
        file.save(filepath)
        return f"uploads/{folder}/{filename}"
    return None

def generate_reference():
    return 'LMQ' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

def generate_invoice_number():
    return 'FAC-' + datetime.utcnow().strftime('%Y%m%d') + '-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def check_and_award_badges(user):
    """Check all badges and award if conditions met"""
    all_badges = Badge.query.all()
    for badge in all_badges:
        already_has = UserBadge.query.filter_by(user_id=user.id, badge_id=badge.id).first()
        if already_has:
            continue
        earned = False
        if badge.condition_type == 'bookings_count':
            count = Booking.query.join(Service).filter(Service.worker_id == user.id).count()
            if count >= badge.condition_value:
                earned = True
        elif badge.condition_type == 'reviews_count':
            count = Review.query.filter_by(worker_id=user.id).count()
            if count >= badge.condition_value:
                earned = True
        elif badge.condition_type == 'rating':
            avg = user.average_rating()
            if avg >= badge.condition_value:
                earned = True
        elif badge.condition_type == 'services_count':
            count = Service.query.filter_by(worker_id=user.id).count()
            if count >= badge.condition_value:
                earned = True
        elif badge.condition_type == 'points':
            if user.points >= badge.condition_value:
                earned = True
        elif badge.condition_type == 'response_time':
            if user.response_time_avg > 0 and user.response_time_avg <= badge.condition_value:
                earned = True

        if earned:
            ub = UserBadge(user_id=user.id, badge_id=badge.id)
            db.session.add(ub)
            user.points += badge.points_reward
            db.session.commit()
            # Notify user
            notif = Notification(
                user_id=user.id,
                title=f'Badge debloque: {badge.name}!',
                message=f'Felicitations! Vous avez gagne le badge "{badge.name}" (+{badge.points_reward} points)',
                type='success',
                link='/my-profile'
            )
            db.session.add(notif)
            db.session.commit()

# ==================== DECORATORS ====================


class WalletTransaction(db.Model):
    __tablename__ = 'wallet_transactions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # deposit, withdrawal, payment, refund
    payment_method = db.Column(db.String(30), nullable=True)  # cmi, inwi_money, orange_money, iam_money
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    reference = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    user = db.relationship('User', backref='wallet_transactions')

class IdentityVerification(db.Model):
    __tablename__ = 'identity_verifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    cin_front = db.Column(db.String(200), nullable=True)  # path to scanned CIN front
    cin_back = db.Column(db.String(200), nullable=True)
    selfie = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, verified, rejected
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    verified_at = db.Column(db.DateTime, nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    user = db.relationship('User', backref='identity_verification', uselist=False)

class Favorite(db.Model):
    __tablename__ = 'favorites'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', foreign_keys=[user_id], backref='favorites')
    worker = db.relationship('User', foreign_keys=[worker_id], backref='favorited_by')

class WorkerLocation(db.Model):
    __tablename__ = 'worker_locations'
    id = db.Column(db.Integer, primary_key=True)
    worker_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    accuracy = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    worker = db.relationship('User', backref='location_history')

